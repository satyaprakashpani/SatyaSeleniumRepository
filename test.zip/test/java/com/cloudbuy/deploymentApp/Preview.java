package com.cloudbuy.deploymentApp;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.cloudbuy.deploymentApp.CaptureVideo;



public class Preview extends DriverSetUp {
	CommonLib cLib =new CommonLib();
	CaptureVideo vcLib=new CaptureVideo();
	/*This will open browser and deployment application  */
	//Test
	@BeforeClass
	public void configBeforeClass() {
		//Start video recording
		try {
			vcLib.startRecording();
		} catch (Exception videoException) {
			videoException.printStackTrace();
			System.out.println("Problem in video recording");
		}
		try{
		setDriver("https://deployment.ukplc.corp");
		System.out.println("Inside before Class--> "+getDriver().getTitle());
		}catch(Exception e){
			e.printStackTrace();
			if(getDriver().getTitle().equals("Server Error")){
				
				cLib.createDialogbox("Deployment Error -: ","Unable to access deployment App "
				+"due to Server Error");
				getDriver().navigate().refresh();
			}
		}
	}
	
	/*Login to deployment application with valid credential */
	@BeforeMethod
	public void configMethod(){
		try{
			cLib.loginToDepllomentApp(getDriver(), "satyaprakash.pani", "Kila@86!");
			if(getDriver().findElement(By.xpath("//h1[contains(text(),'Applications')]")).getText().
					equals("")){
				System.out.println("Logged in to tha app");
			}
		}catch(Exception e){
				if(getDriver().getTitle().equals("Server Error")){
					cLib.createDialogbox("Deployment Error : ","Unable to access deployment App" 
					+"due to Server Error");
					getDriver().close();
				}
		}
	}
	
	
	/*All deployment steps scripted under Test annotation*/
	@Test
	public void DeployPreviewTest(){
		try{
			
			System.out.println("href->"+getDriver().findElement(By.linkText("Preview")).getAttribute("href"));
			Thread.sleep(10000);//application response is not same so need to wait long time to synchronise
			System.out.println("href after wait-->"+getDriver().findElement(By.linkText("Preview")).
					getAttribute("href"));
			
			/*Click on Preview if Preview link is enabled*/
			if(getDriver().findElement(By.linkText("Preview")).isEnabled()){
				System.out.println("Preview Link is enabled");
				WebElement preview = getDriver().findElement(By.xpath("//a[@href='/applications/Preview']"));
				System.out.println("preview loc: "+preview.getLocation());
				Actions act = new Actions(getDriver());
				act.click(preview).perform();
				System.out.println("Preview Clicked");
				}
			
			/*Click on Deployments tab*/
			if(cLib.WaitForPresenceOfElement("//div[@id='page']//a[@href='#deployments']", 
					getDriver(), 30).isEnabled()){
				cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//div[@id="
						+ "'page']//"	+ "a[@href='#deployments']")), 40);
				System.out.println("Deployment Clicked");
			}else{
				cLib.createDialogbox("Deployment Link Issue", "Deployment Link is not enabled");
			}
			
			cLib.WaitForPresenceOfElement("//tr[td[a[text()='Ash']]]/td[contains(text(),'Sites-and-"
					+ "ControlCentre')]", getDriver(), 30);
			
			String data=getDriver().findElement(By.xpath("//tr[td[a[text()='Ash']]]/td[contains(text(),"
					+ "'Sites-and-ControlCentre')]")).getText();
			System.out.println("Data-->"+data);
			cLib.writeDataToExcel("OldBuild", 1, 1, data); //Write previous build no to excel
			
			//Latest build selected
			cLib.select("//tr[td[a[text()='Ash']]]/td/form/select[@name='build']", 0, getDriver());
			System.out.println("Latest build selected");
			
			//Click on Deploy button
			cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//tr[td[a[text()="
					+ "'Ash']]]/td/form/button[text()='Deploy']")), 10);
			System.out.println("Cliclked on 'Deploy'");
			
			//Click on Continue button to deploy Preview on First server
			cLib.waitAndClickElement(getDriver(),getDriver().findElement(By.xpath("//button[text()="
				+ "'Continue']")),40);
			try{
				/*Wait till working button available*/
				if(cLib.WaitForPresenceOfElement("//button[contains(text(),'Working')]", getDriver(), 120).
						isDisplayed()){
					
					System.out.println("Working button available");
					String status = getDriver().findElement(By.xpath("//div[b[contains(text(),'Status')]]/"
							+ "following-sibling::div")).getText();
					System.out.println("Status-->"+status);
					/*Open a new window and open Account Lookup*/
					cLib.openNewWindow(getDriver());
					cLib.switchToNewWindow(getDriver());
					
					getDriver().navigate().to("http://satyaprakash.pani:Kila@86!@intranet/AccountLookUp/"
							+ "AccountLookUp.aspx");
					
					/*Search with ha.cms in Customer's User name field and click on Control Centre */
					getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					getDriver().findElement(By.xpath("//input[@id='element71167']")).sendKeys("ha.cms");
					getDriver().findElement(By.xpath("//span[@id='div71174']/li/span/input")).click();
					cLib.waitAndClickElement(getDriver(),getDriver().findElement(By.xpath("//a[contains"
							+ "(text(),'Control centre')]")), 10);
					
					getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					
					
					/*Open test link1 for highways */
					cLib.openUrlInNewTab(getDriver(), "http://preview1.ash.uk-plc.net/highways");
					/*Click on SHARE*/
					String text = getDriver().findElement(By.xpath("//div[@id='BoxInform']/ul/li/a"))
							.getText();
					cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//div[@id="
							+ "'BoxInform']/ul/li/a")), 40);
					System.out.println("text--> "+text);
					if(cLib.WaitForPresenceOfElement("//div[@id='PageTitle']/h1", getDriver(), 
							40).getText().equals(text)){
						System.out.println("No blocker SO test link "+getDriver().getCurrentUrl()+ "-->Pass");
					}else{
						cLib.createDialogbox("Error in Link Test1", "Getting Error while testing "+
								getDriver().getTitle()+"page");
					}
					
					
					/*Open test link2 for highways*/
					getDriver().navigate().to("http://preview1.ash.uk-plc.net/highways/functions.html");
					System.out.println(getDriver().getTitle()+" loaded");
					/*Click on General Counsel link*/
					cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//h5[contains"
							+ "(text(),'General Counsel')]")), 40);
					System.out.println("General Counsel clicked");
					cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//div[@id="
							+ "'ProcessTitle']/a[contains(text(),'General Counsel')]")), 40);
					System.out.println("Process ID clicked");
					
					if(!cLib.WaitForPresenceOfElement("//div[@class='ProcessContainer']//h1", getDriver(),
							40).getText().isEmpty()){
						System.out.println("You are in "+getDriver().findElement(By.xpath("//div[@class="
								+ "'ProcessContainer']/h1")).getText()+"page");
						System.out.println("No blocker SO test link "+getDriver().getCurrentUrl()+ "-->Pass");
					}else{
						cLib.createDialogbox("Error in Link Test1", "Getting Error while testing "+
								getDriver().getTitle()+"page");
					}
					
					
					/*Open test link3 for highways*/
					getDriver().navigate().to("http://preview1.ash.uk-plc.net/highways/knowledge-bank.html");
					
					cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//a[@href='/"
							+ "highways/inform/shared-services.html']")), 40);
					text = getDriver().findElement(By.xpath("//a[@href='/highways/inform/shared-services"
							+ ".html']")).getText();
					System.out.println("Text-->"+text);
					if(!getDriver().getTitle().contains("500")&& cLib.WaitForPresenceOfElement("//div[@id="
							+ "'PageTitle']/h1", getDriver(), 40).getText().equals(text)){
						System.out.println("You are in "+cLib.WaitForPresenceOfElement("//div[@id='PageTitle"
								+ "']/h1", getDriver(), 40).getText()+" page");
						System.out.println("No blocker SO test link "+getDriver().getCurrentUrl()+ "-->Pass");
					}else{
						cLib.createDialogbox("Link Test Error", "Getting Error while testing "+getDriver().
								getTitle()+"page");
					}
					
					/*Open test link4 for highways*/
					getDriver().navigate().to("http://preview1.ash.uk-plc.net/highways/people-network.html");
					/*Submit a post and delete the post*/
					cLib.WaitForPresenceOfElement("//input[@id='postTitle']", getDriver(), 40)
						.sendKeys("Testing Post");
					cLib.WaitForPresenceOfElement("//textarea[@id='postText']", getDriver(), 40)
						.sendKeys("Testing in Server1");
					cLib.WaitForPresenceOfElement("//input[@id='WallPostFormSubmit']", getDriver(), 40)
								.click();
					getDriver().manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
					cLib.WaitForPresenceOfElement("//div[div[contains(text(),'Testing Post')]]/span/div"
							+ "/a[contains(text(),'Delete')]", getDriver(), 40).click();
					System.out.println("Post Deleted");
					
					
					
					/*Open Account LookUp to login Control Centre for Abd*/
					getDriver().navigate().to("http://intranet/AccountLookUp/AccountLookUp.aspx");
					/*Search with Abd.administrator and click on ControlCentre*/
					getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					getDriver().findElement(By.xpath("//input[@id='element71167']")).sendKeys
						("Abd.administrator");
					getDriver().findElement(By.xpath("//span[@id='div71174']/li/span/input")).click();
					cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//a[contains"
							+ "(text(),'Control centre')]")), 10);
					getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					
					/*Open testlink1 for Abd*/
					cLib.openUrlInNewTab(getDriver(), "http://preview1.ash.uk-plc.net/abd");
					if(!getDriver().getTitle().contains("500")){
					getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
					/*Mouse hover on products*/
					cLib.mousehoverToAnElement(getDriver(), getDriver().findElement(By.xpath("//div[@id="
							+ "'NavigationBar']//a[contains(text(),'Products')]")));
					System.out.println("Mousehover complete");
					/*Click on a link*/
					if(!getDriver().getTitle().contains("500")){
					cLib.WaitForPresenceOfElement("//div[@id='NavigationBar']//a[contains(text(),'Products')]"
							+ "/following-sibling::ul/li[1]//a", getDriver(), 30).click();
						if(getDriver().getTitle().contains("500")){
							System.out.println("500 Error on testlink");
							cLib.createDialogbox("500 Error : ","Unable to search product");
							}
						}else{
							System.out.println("500 Error on testlink");
							cLib.createDialogbox("Link Test Error", "Getting Error while testing :"+getDriver().
									getTitle()+"page, Please report it and Click on 'OK' to continue");
						}
					System.out.println("Test link1 for ABD Passed");
					}else{
						System.out.println("500 Error on testlink");
						cLib.createDialogbox("Link Test Error", "Getting Error while testing :"+getDriver().
								getTitle()+"page, Please report it and Click on 'OK' to continue");
					}
					
					/*Open testlink2 for Abd*/
					getDriver().navigate().to("http://preview1.ash.uk-plc.net/abd/search.html?typeOfSearch="
							+ "Products&searchTer​m=cd127&x=0&y=0​​");
					if(!getDriver().getTitle().contains("500")){
						cLib.WaitForPresenceOfElement("//input[@id='errorSearchTerm']", getDriver(), 
								40).sendKeys("Test");
						cLib.WaitForPresenceOfElement("//input[@class='submit']", getDriver(), 15).click();
						if(getDriver().getTitle().contains("500")){
							System.out.println("500 Error on testlink");
						}
						System.out.println("Test link "+getDriver().getCurrentUrl()+" Passed");
					}
					
					
					/*Open testlink3 for Abd*/
					getDriver().navigate().to("http://preview1.ash.uk-plc.net/abd/site-search.html?"+
					"SearchString=sheep​​​");
					if(!getDriver().getTitle().contains("500")){
						cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//a[@href="
								+ "'/abd/anti-sheep-antibodies.html']")), 40);
						if(getDriver().getTitle().contains("500")){
							System.out.println("500 Error on testlink");
						}
						System.out.println("Test link "+getDriver().getCurrentUrl()+" Passed");
					}
					
					/*Open testlink4 for Abd*/
					getDriver().navigate().to("http://preview1.ash.uk-plc.net/abd/search.html?searchType="
							+ "BASIC&searchTerm=CD4&Filter1Name=SpecCI&Filter1Value=CD4&Filter2Name=targetOr"
							+ "Cross&Filter2Value=Mouse&filterCount=2");
					if(!getDriver().getTitle().contains("500")){
						getDriver().manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
						if(getDriver().findElement(By.xpath("//div[@id='countries']")).isDisplayed()){
							cLib.WaitForPresenceOfElement("//div[@id='countries']//div[@value='GB']",
									getDriver(), 30).click();
						}
						cLib.WaitForPresenceOfElement("//tr[@class='grey'][2]/td[@colspan='2']"
								+ "//input[@value='Add']", getDriver(), 40).click();
						cLib.WaitForPresenceOfElement("//a[contains(text(),'items')]", getDriver(), 40)
							.click();
						cLib.WaitForPresenceOfElement("//form[@id='basketForm']/div/div/a",getDriver(),
							40).click();
						if(cLib.WaitForPresenceOfElement("//form[@id='basketForm']/div[contains(text(),"
								+ "'Your basket is currently empty')]", getDriver(), 40).isDisplayed()){
							System.out.println("Cart is empty");
							System.out.println("There is no blockage So this link passed");
						}
					}else{
						System.out.println("500 Error on testlink");
						cLib.createDialogbox("Link Test Error", "Getting Error while testing :"+getDriver().
								getTitle()+"page, Please report it and Click on 'OK' to continue");
					}
					
					
					/*Open testlink5 for Abd*/
					getDriver().navigate().to("http://preview1.ash.uk-plc.net/abd/human-cd127-antibody-11590-"
							+ "hca144.html");
					if(!getDriver().getTitle().contains("500")){
						cLib.WaitForPresenceOfElement("//div[contains(text(),'UniProt')]/following-sibling::"
								+ "div/div[@class='ExtLinkSearch']/a", getDriver(), 40).click();
						if(getDriver().getTitle().contains("500")){
							System.out.println("500 Error in test link");
							}
						}
					
					/*Open testlink6 for Abd*/
					System.out.println("Navigating to test Link 6");
					String windowId=getDriver().getWindowHandle();
					getDriver().switchTo().window(windowId);
					getDriver().navigate().to("http://Preview1.ash.uk-plc.net/abd/drug-discovery.html");
					System.out.println("Navigated to test Link 6");
					if(!getDriver().getTitle().contains("500")){
						cLib.WaitForPresenceOfElement("//a[@href='/abd/anti-humira-antibodies.html']",
								getDriver(), 40).click();
						if(getDriver().getTitle().contains("500")){
							System.out.println("500 Error in test link");
							}else {
								System.out.println("No blockage...This test link passed");
							}
						}else{
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "+getDriver().
									getTitle()+"page");
						}
					
					/*Open testlink7 for Abd*/
					System.out.println("Navigating to test Link 7 for ABD");
					getDriver().navigate().to("http://preview1.ash.uk-plc.net/abd/anti-remicade-"
							+ "antibodies.html");
					System.out.println("Navigated to test Link 7 for ABD");
					if(!getDriver().getTitle().contains("500")){
						cLib.WaitForPresenceOfElement("//div[@id='LefthandMenu']//li[7]/a",getDriver(),40)
							.click();
						if(getDriver().getTitle().contains("500")){
							System.out.println("500 Error in test link");
							}else {
								System.out.println("No blockage...This test link passed and all abd links got"
										+ " passed");
							}
					}else{
						cLib.createDialogbox("Link Test Error", "Getting Error while testing "+getDriver().
								getTitle()+"page");
					}
					
					/*getDriver().navigate().to("http://intranet/AccountLookUp/AccountLookUp.aspx");
					getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					getDriver().findElement(By.xpath("//input[@id='element71171']")).sendKeys("1470469");
					getDriver().findElement(By.xpath("//span[@id='div71174']/li/span/input")).click();
					cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//a[contains
					(text(),'Control centre')]")), 10);
					getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					
					getDriver().navigate().to("http://preview1.ash.uk-plc.net/confederation-of-indian
					-industry/index.html");
					if(!getDriver().getTitle().contains("500")){
						cLib.WaitForPresenceOfElement("//div[@id='CategoryMenu']//a[@title='Manufacturing']",
								getDriver(), 40).click();
						if(!getDriver().getTitle().contains("500")){
							if(cLib.WaitForPresenceOfElement("//div[@id='MarketplaceClasses']//a[contains"
									+ "(text(),'Manufacturing')]", getDriver(), 40).isDisplayed()){
								System.out.println("No blockage...This test link1-CII passed");
							}
						}
					
					}else{
						System.out.println("Error");
						cLib.createDialogbox("Link Test Error", "Getting Error while testing "+getDriver().
								getTitle()+"page");
					}
					
					
					getDriver().navigate().to("http://preview1.ash.uk-plc.net/confederation-of-indian-
					industry/category/services.html");
					if(!getDriver().getTitle().contains("500")){
						cLib.WaitForPresenceOfElement("//div[@id='MarketplaceClasses']//div[contains(text(),"
								+ "'Banking')]", getDriver(), 40).click();
						if(!getDriver().getTitle().contains("500")){
							if(cLib.WaitForPresenceOfElement("//div[@id='MarketplaceClasses']//div[@class="
									+ "'ComapnyCategoryBreadcrumb']/a[contains(text(),'Banking')]"
									,getDriver(),40).isDisplayed()){
								System.out.println("No blockage...This test link2-CII passed");
							}
						}
					
					}else{
						System.out.println("Error");
						cLib.createDialogbox("Link Test Error", "Getting Error while testing "+getDriver().
								getTitle()+"page");
					}
					
					
					getDriver().navigate().to("http://preview1.ash.uk-plc.net/confederation-of-indian-
					industry/product-search.html");
					if(!getDriver().getTitle().contains("500")){
						cLib.WaitForPresenceOfElement("//div[@id='phraseElementRow']//input", getDriver(), 
								40).sendKeys("Test");
					getDriver().findElement(By.xpath("//input[@id='ProductSearchSubmit']")).click();
						if(!getDriver().getTitle().contains("500")){
							if(cLib.WaitForPresenceOfElement("//div[@id='CatalogueSearchResults']/div[2]/"
									+ "div[@class='ProductInfo']//a", getDriver(), 40).isDisplayed()){
								cLib.WaitForPresenceOfElement("//div[@id='CatalogueSearchResults']/div[2]/"
										+ "div[@class='ProductInfo']//a", getDriver(), 40).click();
								if(!getDriver().getTitle().contains("500")){
								System.out.println("No blockage...This test link3-CII passed");
								}
							}
						}
					
					}else{
						System.out.println("Error");
						cLib.createDialogbox("Link Test Error", "Getting Error while testing "+getDriver().
								getTitle()+"page");
					}
					
					getDriver().navigate().to("http://preview1.ash.uk-plc.net/confederation-of-indian
					-industry/category/technology.html");
					if(!getDriver().getTitle().contains("500")){
						cLib.WaitForPresenceOfElement("//div[@id='MarketplaceClasses']//div[contains(text(),"
								+ "'ICTE Manufacturing')]", getDriver(), 40).click();
						if(!getDriver().getTitle().contains("500")){
								if(!getDriver().getTitle().contains("500")){
								System.out.println("No blockage...This test link4-CII passed");
								}
							}
					}else{
						cLib.createDialogbox("Link Test Error", "Getting Error while testing "+getDriver().
								getTitle()+"page");
					}
					
					getDriver().navigate().to("http://preview1.ash.uk-plc.net/confederation-of-indian-
					industry/contact-us.html");
					if(!getDriver().getTitle().contains("500")){
						cLib.WaitForPresenceOfElement("//div[@id='HeaderHomeButton']//span[contains(text(),\
						'Home')]", getDriver(), 40).click();
						if(!getDriver().getTitle().contains("500")){
							
								if(cLib.WaitForPresenceOfElement("//div[@id='PageTitle']/h1[contains(text(),"
										+ "'About CII')]", getDriver(), 40).isDisplayed()){
								System.out.println("No blockage...This test link5-CII passed");
								}
							}
					}else{
						cLib.createDialogbox("Link Test Error", "Getting Error while testing "+getDriver().
								getTitle()+"page");
						System.out.println("Error");
					}
					
					
					getDriver().navigate().to("http://preview1.ash.uk-plc.net/confederation-of-indian
					-industry/basket/index.html");
					if(!getDriver().getTitle().contains("500")){
						if(cLib.WaitForPresenceOfElement("//div[@id='Basket']/h3[contains(text(),'Basket')]", 
								getDriver(), 40).isDisplayed()){
						if(!getDriver().getTitle().contains("500")){
							cLib.WaitForPresenceOfElement("//div[@id='HeaderHomeButton']//span[contains
							(text(),'Home')]", getDriver(), 40).click();
							if(!getDriver().getTitle().contains("500")){
								getDriver().close();
								System.out.println("No blockage...This test link6-CII passed");
								}
							}
						}
					}else{
						cLib.createDialogbox("Link Test Error", "Getting Error while testing "+getDriver().
								getTitle()+"page");
					}*/
				
					
					getDriver().switchTo().window(cLib.navigateToParentWindow(getDriver()));
					cLib.createDialogbox("Deployment Confirmation: ", "All test links got tested and working"
							+ " as per expected \n Please complete ticket related testing if any and click "
							+ "on 'OK' 'Working' button");
					
					
					cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//button[contains"
							+ "(text(),'Working')]")), 30);
					
					if(cLib.WaitForPresenceOfElement("//div[@id='page']//strong[contains(text(),'Success')]",
							getDriver(), 1800).isDisplayed()){
						cLib.createDialogbox("Success Message","Preview Deployed on Ash environment "
								+ "successfully with successful message : "+getDriver().findElement(By.
									xpath("//div[@id='page']//div[@class='alert alert-success']")).	getText());
					}else{
						cLib.createDialogbox("Failure Message", "Preview is unable to Deploy on Ash "
								+ "environment");
					}
				}else{
					cLib.createDialogbox("Deployment Error :",getDriver().findElement(By.xpath("//div[@c"
							+ "lass='alert alert-error']")).getText( ));
					getDriver().navigate().refresh();
				}
		
			}catch(Exception e){
				e.printStackTrace();
				if(getDriver().getTitle().equals("Server Error")){
					cLib.createDialogbox("Deployment Error : ","Unable to access deployment App "
					+"due to Server Error");
					System.out.println("Error");
					getDriver().get("https://deployment.ukplc.corp");
				}else if(getDriver().findElement(By.xpath("//div[@class='alert alert-error']")).isDisplayed()){
				System.out.println("Error --> "+getDriver().findElement(By.xpath("//div[@class='alert "
						+ "alert-error']")).getText());	
				}
				
			}
		}catch(Exception E){
			E.printStackTrace();
			if(getDriver().getTitle().equals("Server Error")){
				cLib.createDialogbox("Deployment Error : ","Unable to access deployment App" 
				+"due to Server Error");
				System.out.println("Error");
				getDriver().get("https://deployment.ukplc.corp");
			}/*else if(getDriver().findElement(By.xpath("//div[@class='alert alert-error']")).isDisplayed()){
			System.out.println("Error --> "+getDriver().findElement(By.xpath("//div[@class='alert "
					+ "alert-error']")).getText());	
			}*/
		}
	}
	
	
	
	@AfterClass
	public void configAfterClassMtd(){
		try {
			
			vcLib.stopRecording();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
