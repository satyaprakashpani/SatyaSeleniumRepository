package com.cloudbuy.deploymentApp;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class SitesOnCressex extends DriverSetUpCressx{
	CommonLib cLib =new CommonLib();
	CaptureVideo vcLib=new CaptureVideo();
	/*This will open browser and deployment application  */
	@BeforeClass
	public void configBeforeClass() {
		//Start video recording
		try {
			vcLib.startRecording();
		} catch (Exception videoException) {
			videoException.printStackTrace();
			System.out.println("Problem in video recording");
		}
		try{
			setDriver("https://deployment2.ukplc.corp");
			System.out.println("Inside beforeClass--> "+getDriver().getTitle());
			cLib.WaitForPresenceOfElement("//input[@id='login']", getDriver(), 20);
			}catch(Exception e){
				e.printStackTrace();
				if(getDriver().getTitle().equals("Server Error")){
					System.out.println("Inside Catch if Server error");
					cLib.createDialogbox("Deployment Error : ","Unable to access deployment App "
					+"due to Server Error");
					getDriver().navigate().refresh();
				}else{
					cLib.createDialogbox("Deployment Error : ","Unable to access deployment App "
							+"due to deployment app Error");
				}
					
			}
		}
	
	
	/*Login to deployment application with valid credential */
	@BeforeMethod
	public void configMethod(){
		System.out.println("Inside before method");
		try{
			cLib.createDialogbox("Login Screen ","Please enter your credential and click on 'Submit'"
							+ " button before clicking on dialogbox 'OK' button");
			//cLib.WebsitesToDepllomentApp(getDriver(), "satyaprakash.pani", "Kila@999!");
			/*if(getDriver().findElement(By.xpath("//a[contains(text(),'Applications')]")).getText().
					equals("")){
				System.out.println("Logged in to tha app");
			}*/
		}catch(Exception e){
				if(getDriver().getTitle().equals("Server Error")){
					cLib.createDialogbox("Login Error","Unable to Login");
					getDriver().close();
				}
		}
	}
	

	@Test
	public void DeploySitesTest(){
		try{
			cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//a[contains"
					+ "(text(),'Applications')]")), 40);
			/*Thread.sleep(10000);*///application response is not same so need to wait long time to	
			//synchronize
			Thread.sleep(2000);
			cLib.highlightElement(getDriver().findElement(By.xpath("//a[contains(text(),"
					+ "'Applications')]")), getDriver());
			
			/*Click on Sites if Sites link is enabled*/
			WebElement sites = getDriver().findElement(By.xpath("//div[@id='page']//div[@class="
					+ "'list-group-item']//a[@href='/applications/sites']"));
			
			if(sites.isEnabled()){
				System.out.println("sites Link is enabled");
				Thread.sleep(10000);
				cLib.highlightElement(sites, getDriver());
				System.out.println("sites loc: "+sites.getLocation());
				/*Actions act = new Actions(getDriver());
				act.click(sites).perform();*/
				JavascriptExecutor executor = (JavascriptExecutor)getDriver();
				executor.executeScript("arguments[0].click()", sites);
				System.out.println("sites Clicked");
				
				}
			
			
			
			if(cLib.WaitForPresenceOfElement("//div[@id='page']//h1", getDriver(), 30).isDisplayed()){
				cLib.highlightElement(getDriver().findElement(By.xpath("//div[@id='page']//h1")),
						getDriver());
				String oldBNo = getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/"
						+ "following-sibling::td[@class='text-right']")).getText();
				System.out.println("Old Build No : "+oldBNo);
				String data=getDriver().findElement(By.xpath("//tr[td[a[text()='Cressex']]]/td[contains"
						+ "(text(),'Sites')]")).getText();
				/*System.out.println("Data-->"+data);
				System.out.println(data.split("-")[data.split("-").length-1]);*/
				
				/*Highlight and Click on build number drop-down*/
				cLib.highlightElement(getDriver().findElement(By.xpath("//td[a[contains(text(),"
						+ "'Cressex')]]/following-sibling::td//button[@class='btn dropdown-toggle "
						+ "btn-default']")), getDriver());
				getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/following-sibling"
						+ "::td//button[@class='btn dropdown-toggle btn-default']/span")).click();
				
				if(cLib.checkForOldBuild("//td[a[contains(text(),'Cressex')]]/following-sibling::td//"
						+ "span[@class='text']", getDriver(),Integer.valueOf(oldBNo))){
					System.out.println("Build number present");
					try{
						cLib.createDialogbox("Build no selection", "Please select suitable build number to deploy");
					
					/*getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/following-sibling"
							+ "::td//button[@class='btn dropdown-toggle btn-default']")).click();*/
					}catch(Exception selectBtn){
						cLib.createDialogbox("Build Not Found", "Dropdown is not enable to click");
						cLib.select("//tr[td[a[text()='Cressex']]]/td/form/select[@name='build']", 
								data.split("-")[data.split("-").length-1], getDriver());
					}
						}else{
							cLib.createDialogbox("Build Not Found", "Please change it manually");
							cLib.clickOnOldBuild(oldBNo, getDriver());
						}
				
				
				//Click on Deploy button
				try{
					cLib.highlightElement(getDriver().findElement(By.xpath("//td[a[contains(text(),"
							+ "'Cressex')]]/following-sibling::td//button[contains(text(),'Deploy')]"
							)),getDriver());
					System.out.println("Highlighted");
					
					/*Actions deploy = new Actions(getDriver());
					deploy.click(getDriver().findElement(By.xpath("//tr[td[a[text()='Cressex']]]/td/form"
							+ "/button[text()='Deploy' and @class='btn']"))).perform();*/
					getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/following-"
							+ "sibling::td//button[contains(text(),'Deploy')]")).click();
					System.out.println("Cliclked on 'Deploy'");
					
					
				}catch(Exception deploymentButton){
					cLib.createDialogbox("DeployButton", "Deploy Button is not Clickable");
					deploymentButton.printStackTrace();
				}
				
			}else{
				System.out.println("sites not displayed");
			}
			/*Confirm deployment application, environment and build*/
			try{
				if(cLib.WaitForPresenceOfElement("//h2[text()='Confirm Deployment']", getDriver(),
						40).isDisplayed()){
					cLib.highlightElement(getDriver().findElement(By.xpath("//h2[text()='Confirm "
							+ "Deployment']")), getDriver());
					
					
					cLib.createDialogbox("Confirm deployment ", "If Application, Environment and Build "
							+ "No. are correct then click OK in dialog box, \nElse click 'Cancel' on "
							+ "deployment App then click on 'Ok' in dialoge ");
					
				}
			}catch(Exception e){
				e.printStackTrace();
				cLib.createDialogbox("Error :","Error in : "+getDriver().getCurrentUrl());
			}
			
			//Click on Continue button to deploy Sites on First server
			cLib.waitAndClickElement(getDriver(),getDriver().findElement(By.xpath("//button[text()="
				+ "'Continue']")),40);
			
			System.out.println("Continue button clicked");
			
			
			try{
				String status = getDriver().findElement(By.xpath("//div[strong[contains(text(),"
						+ "'Status')]]/following-sibling::div/span")).getText();
				System.out.println("Status-->"+status);
				do{
					String deploymentURL = getDriver().getCurrentUrl();
					System.out.println("Dep Url --> "+deploymentURL);
					
					if(cLib.WaitForPresenceOfElement("//div[@id='deployment-actions']/a[contains(text(),"
							+ "'Working')]", getDriver(),5400).isDisplayed()){
						cLib.createDialogbox("Health Check", "Health Check for OK : Report in deployment channel or developer"
								+ " for health check failure");
						
						/*try{
							Open a new window and open Account Lookup
							//cLib.openNewWindow(getDriver());
							//cLib.switchToNewWindow(getDriver());
							
							//Open Account LookUp to login Control Centre for Abd
							Runtime.getRuntime().exec("C:\\AutoIT\\AutoItScript\\Test.exe");
							Thread.sleep(1000);
							System.out.println("Opening Acc Lookup to log into Highways");
							getDriver().navigate().to("http://satyaprakash.pani:ChangeMe!@intranet/"
									+ "AccountLookUp/AccountLookUp.aspx");
							//Search with Abd.administrator and click on ControlCentre
							getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
							getDriver().findElement(By.xpath("//input[@id='element71167']")).sendKeys
								("Abd.administrator");
							getDriver().findElement(By.xpath("//span[@id='div71174']/li/span/input")).click();
							cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//"
									+ "a[contains(text(),'Control centre')]")), 10);
							getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
							
						}catch(Exception accntLookupLogin){
							accntLookupLogin.printStackTrace();
							System.out.println("Error while Logging into CC for ABD");
							cLib.createDialogbox("Account Lookup Error", "Getting Error while testing "
							+getDriver().getTitle()+"page");
						}
						*/
						//Code for test link of PHB Choice
						/*open Account Lookup*/
						try{
							//Open Account LookUp to login Purchasing for PHB
							System.out.println("Opening Acc Lookup to log into CC for Company Admin test links");
							getDriver().navigate().to("http://@intranet/AccountLookUp/AccountLookUp.aspx");
							//Search with katy.atherton.phb.admin and click on Purchasing
							getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
							getDriver().findElement(By.xpath("//input[@id='element71167']")).sendKeys
								("katy.atherton.phb.admin");
							getDriver().findElement(By.xpath("//span[@id='div71174']/li/span/input")).click();
							cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//"
									+ "a[contains(text(),'Purchasing')]")), 10);
							getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
								
							}catch(Exception accntLookupLogin){
								accntLookupLogin.printStackTrace();
								System.out.println("Error while Logging into  Purchasing");
								cLib.createDialogbox("Account Lookup Error", "Getting Error while testing "
										+getDriver().getTitle()+"page");
							}
						
						try{
							
							System.out.println("Navigating to test Link for PHB Choice");
							cLib.openNewTabJSExecuter(getDriver());
							cLib.switchToNewTabByAryLst(getDriver());
							getDriver().navigate().to("http://web1.uk-plc.net/phb-marketplace/products.html");
							if(!getDriver().getTitle().contains("500")){
								try {
									if(getDriver().findElement(By.xpath("//div[@id='CookiePolicyPopup']"))
											.isDisplayed())
									{
										cLib.WaitForPresenceOfElement("//button[contains(text(),'Accept')]",getDriver(), 30).click();
									}
								}catch(Exception cookiePopUp) {
									System.out.println("Country selection pop up doesn't appear");
									cookiePopUp.printStackTrace();
								}
								cLib.WaitForPresenceOfElement("//input[@id='search']",getDriver(),40).click();
								Thread.sleep(10000);
								if(!getDriver().getTitle().contains("500")){
									List<WebElement> srchRlt = getDriver().findElements(By.xpath("//div[@class='result-container']//h3/a"));
									
									cLib.highlightElements(srchRlt, getDriver());
									//srchRlt.get(0).click();
									if(!getDriver().getTitle().contains("500")){
										cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@value='Buy now']", getDriver(), 40), getDriver());
										cLib.WaitForPresenceOfElement("//input[@value='Buy now']", getDriver(), 40).click();
										
										if(!getDriver().getTitle().contains("500")){
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//li[@class='li-details']//form//input[@type='text']", getDriver(), 40), getDriver());
											cLib.WaitForPresenceOfElement("//li[@class='li-details']//form//input[@type='text']", getDriver(), 40).sendKeys("11");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//li[@class='li-details']//form//input[@alt='UPDATE QUANTITY']", getDriver(), 40), getDriver());
											cLib.WaitForPresenceOfElement("//li[@class='li-details']//form//input[@alt='UPDATE QUANTITY']", getDriver(), 40).click();
											
											if(!getDriver().getTitle().contains("500")){
												cLib.highlightElement(cLib.WaitForPresenceOfElement("//form[@id='basketForm']//a", getDriver(), 40), getDriver());
												cLib.WaitForPresenceOfElement("//form[@id='basketForm']//a", getDriver(), 40).click();
												
												cLib.highlightElement(cLib.WaitForPresenceOfElement("//button[contains(text(),'Confirm')]", getDriver(), 40), getDriver());
												cLib.WaitForPresenceOfElement("//button[contains(text(),'Confirm')]", getDriver(), 40).click();
												
												if(getDriver().findElement(By.xpath("//div[@class='alertBox']")).isDisplayed()) {
													System.out.println("No blockage...This test link passed and all"
															+ " abd links got passed");
													
												}else{
													cLib.createDialogbox("Check For  Empty Basket", "Kindly empty the basket if any item present in Basket"+
															getDriver().getTitle()+"page");
														}
											}else{
												cLib.createDialogbox("500 Error", "Getting Error while testing"+
														getDriver().getTitle()+"page");
													}
										}else{
											cLib.createDialogbox("500 Error", "Getting Error while testing"+
													getDriver().getTitle()+"page");
												}
									}else{
										cLib.createDialogbox("500 Error", "Getting Error while testing"+
												getDriver().getTitle()+"page");
											}
								}else{
									cLib.createDialogbox("Link Test Error", "Getting Error while testing"+
											getDriver().getTitle()+"page");
										}
							}else{
								cLib.createDialogbox("Link Test Error", "Getting Error while testing"+
								getDriver().getTitle()+"page");
							}
						}catch(Exception phbError){
							phbError.printStackTrace();
							System.out.println("Error on PHB Choice test link");
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "
							+	getDriver().getTitle()+"page");
						}
						
						try{
							//Open testlink1 for Sites
							getDriver().navigate().to("http://web1.uk-plc.net/abd");
							Thread.sleep(2000);
							//cLib.openUrlInNewTab(getDriver(), "http://web1.uk-plc.net/abd");
							try {
								if(getDriver().findElement(By.xpath("//div[@id='countries']"))
										.isDisplayed())
								{
									cLib.WaitForPresenceOfElement("//div[@id='countries']//div[@value='GB' and "
											+ "contains (text(),'United Kingdom')]",getDriver(), 30).click();
								}
							}catch(Exception e) {
								System.out.println("Country selection pop up doesn't appear");
								e.printStackTrace();
							}
							if(!getDriver().getTitle().contains("500")){
							getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
							//Mouse hover on products
							cLib.mousehoverToAnElement(getDriver(), getDriver().findElement(By.xpath
									("//nav//a[contains(text(),'Products')]")));
							System.out.println("Mousehover complete");
							//Click on a link
							if(!getDriver().getTitle().contains("500")){
								cLib.highlightElement(cLib.WaitForPresenceOfElement("//nav//a[contains(text(),'Products')]/../div//a[contains(text(),'Negative ')]", getDriver(), 30), getDriver());
								cLib.WaitForPresenceOfElement("//nav//a[contains(text(),'Products')]/../div//a[contains(text(),'Negative ')]", getDriver(), 30).click();
								if(getDriver().getTitle().contains("500")){
									System.out.println("500 Error on testlink");
									cLib.createDialogbox("500 Error : ","Unable to search product");
									}else{
										System.out.println("NO Error on testlink");
										System.out.println("Test link1 for Sites Passed");
									}
								}else{
									System.out.println("500 Error on testlink");
									cLib.createDialogbox("Link Test Error", "Getting Error while "
											+ "testing :"+getDriver().getTitle()+"page, Please report it"
													+ " and Click on 'OK' to continue");
								}
							
							}else{
								System.out.println("500 Error on testlink");
								cLib.createDialogbox("Link Test Error", "Getting Error while testing :"
								+getDriver().getTitle()+"page, Please report it and Click on 'OK' to"
										+ " continue");
							}
						}catch(Exception sites1){
							sites1.printStackTrace();
							System.out.println("Error on abd link1 test");
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "
							+	getDriver().getTitle()+"page");
						}
						
						Thread.sleep(2000);
						try{
							//Open testlink2 for Sites
							System.out.println("Navigating to link2 for Abd");
							getDriver().navigate().to("http://web1.uk-plc.net/abd/search.html?searchType=SPECIFICITY&searchTerm=STK39");
							if(!getDriver().getTitle().contains("500")){
								try {
								if(getDriver().findElement(By.xpath("//div[@id='countries']"))
										.isDisplayed())
								{
									cLib.WaitForPresenceOfElement("//div[@id='countries']//div[@value='GB' and "
											+ "contains (text(),'United Kingdom')]",getDriver(), 30).click();
								}
								}catch(Exception e) {
									System.out.println("Country selection pop up doesn't appear");
									e.printStackTrace();
								}
								cLib.highlightElement(getDriver().findElement(By.xpath("//tbody//span[contains(text(),'VMA00281KT')]/ancestor::td/following-sibling::td//input[@value='Add']")), getDriver());
								System.out.println("Highlighted");
								WebElement addBtn= cLib.WaitForPresenceOfElement("//tbody//span[contains(text(),'VMA00281KT')]/ancestor::td/following-sibling::td//input[@value='Add']", getDriver(),40);
								
								JavascriptExecutor executor = (JavascriptExecutor) getDriver();
								executor.executeScript("arguments[0].click();", addBtn);
								
								Thread.sleep(4000);
								
								if(!getDriver().getTitle().contains("500")){
								cLib.highlightElement(getDriver().findElement(By.xpath("//div[@id='Embedded"
										+ "Basket']//a[contains(text(),'item')]")), getDriver());
								cLib.WaitForPresenceOfElement("//div[@id='EmbeddedBasket']//a[contains(text(),"
										+ "'item')]", getDriver(), 40).click();
								if(!getDriver().getTitle().contains("500")){
									System.out.println("Test link "+getDriver().getCurrentUrl()+" Passed");
								}else{
									System.out.println("500 Error on testlink");
									cLib.createDialogbox("Link Test Error", "Getting Error while testing :"
									+getDriver().getTitle()+"page, Please report it and Click on 'OK' to"
											+ " continue");
									}
								}else{
									System.out.println("500 Error on testlink");
									cLib.createDialogbox("Link Test Error", "Getting Error while testing :"
									+getDriver().getTitle()+"page, Please report it and Click on 'OK' to"
											+ " continue");
								}
							}else{
								System.out.println("500 Error on testlink");
								cLib.createDialogbox("Link Test Error", "Getting Error while testing :"
								+getDriver().getTitle()+"page, Please report it and Click on 'OK' to"
										+ " continue");
							}
						}catch(Exception sites2){
							sites2.printStackTrace();
							System.out.println("Error on abd link2 test");
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
							getDriver().getTitle()+"page");
						}
						
						Thread.sleep(2000);
						try{
							//Open testlink3 for Sites
							getDriver().get("http://web1.uk-plc.net/abd/site-search.html?SearchString=sheep");
							try {
								if(getDriver().findElement(By.xpath("//div[@id='countries']"))
										.isDisplayed())
								{
									cLib.WaitForPresenceOfElement("//div[@id='countries']//div[@value='GB' and "
											+ "contains (text(),'United Kingdom')]",getDriver(), 30).click();
								}
								}catch(Exception e) {
									System.out.println("Country selection pop up doesn't appear");
									e.printStackTrace();
								}
							if(!getDriver().getTitle().contains("500")){
								cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath
							("//div[@id='SearchResults']//a[contains(text(),'Anti-Sheep Antibodies')]")), 40);
								if(getDriver().getTitle().contains("500")){
									System.out.println("500 Error on testlink");
									cLib.createDialogbox("500 Error", "Getting Error while "
											+ "testing "+getDriver().getTitle()+"page");
								}else
									System.out.println("Test link3 "+getDriver().getCurrentUrl()+" Passed");
							}
						}catch(Exception sites3){
							sites3.printStackTrace();
							System.out.println("Error on Sites link3 test");
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
							getDriver().getTitle()+"page");
						}
						
						Thread.sleep(2000);
						try{
							//Open testlink4 for Sites
							getDriver().navigate().to("http://web1.uk-plc.net/abd/search.html?searchType=BASIC"
									+ "&searchTerm=CD4&Filter1Name=SpecCI&Filter1Value=CD4&Filter2Name=targetOr"
									+ "Cross&Filter2Value=Mouse&filterCount=2");
							if(!getDriver().getTitle().contains("500")){
								getDriver().manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
								Thread.sleep(2000);
								if(getDriver().findElement(By.xpath("//div[@id='countries']"))
										.isDisplayed())
								{
									cLib.WaitForPresenceOfElement("//div[@id='countries']//div[@value='GB' and "
											+ "contains (text(),'United Kingdom')]",getDriver(), 40).click();
								}
								if(cLib.WaitForPresenceOfElement("//span[contains(text(),'IMPORTANT ORDERING')]/"
										+ "following-sibling::button", getDriver(), 40).isDisplayed()){
									cLib.WaitForPresenceOfElement("//span[contains(text(),'IMPORTANT ORDERING'"
											+ ")]/following-sibling::button", getDriver(), 40).click();
								}else{
									System.out.println("No Pup up>>>>>>>>>>>");
								}
								
								Thread.sleep(2000);
								
								JavascriptExecutor executor = (JavascriptExecutor)getDriver();
								executor.executeScript("arguments[0].click()",cLib.WaitForPresenceOfElement("//span"
										+ "[contains(text(),'35GA')]/ancestor::td/following-sibling::td//input[@value"
										+ "='Add']", getDriver(),40) );
								Thread.sleep(20000);
								
								cLib.highlightElement(getDriver().findElement(By.xpath("//div[@id='Embedded"
										+ "Basket']//a[contains(text(),'item')]")), getDriver());
								cLib.WaitForPresenceOfElement("//div[@id='EmbeddedBasket']//a[contains(text(),"
										+ "'item')]", getDriver(), 40).click();
								
								Thread.sleep(6000);
								
								/*if(cLib.WaitForPresenceOfElement("//span[contains(text(),'IMPORTANT ORDERING')]/"
										+ "following-sibling::button", getDriver(), 40).isDisplayed()){
									cLib.WaitForPresenceOfElement("//span[contains(text(),'IMPORTANT ORDERING')]/"
											+ "following-sibling::button", getDriver(), 40).click();
								}else{
									System.out.println("No Pup up>>>>>>>>>>>");
								}*/
								
								cLib.highlightElement(cLib.WaitForPresenceOfElement("//tr[@class='basketProductRow']"
									+ "//input[@class='quantity autoUpdateQuantity']", getDriver(), 40), getDriver());
								cLib.WaitForPresenceOfElement("//tr[@class='basketProductRow']"
									+ "//input[@class='quantity autoUpdateQuantity']", getDriver(), 40).sendKeys("2");
								
								cLib.highlightElement(cLib.WaitForPresenceOfElement("//tr[@class='basketProductRow']"
										+ "//input[@class='updateQuantity']", getDriver(), 40), getDriver());
								cLib.WaitForPresenceOfElement("//tr[@class='basketProductRow']"
										+ "//input[@class='updateQuantity']", getDriver(), 40).click();
								
								/*if(cLib.WaitForPresenceOfElement("//span[contains(text(),'IMPORTANT ORDERING')]/"
										+ "following-sibling::button", getDriver(), 40).isDisplayed()){
									cLib.WaitForPresenceOfElement("//span[contains(text(),'IMPORTANT ORDERING')]/"
											+ "following-sibling::button", getDriver(), 40).click();
								}else{
									System.out.println("No Pup up>>>>>>>>>>>");
								}*/
								Thread.sleep(500);
									cLib.highlightElement(getDriver().findElement(By.xpath("//form[@id='basketForm']/div"
											+ "[@class='basketOptions']//a")), getDriver());
									cLib.WaitForPresenceOfElement("//form[@id='basketForm']/div[@class='basketOptions']"
											+ "//a", getDriver(), 40).click();
									Thread.sleep(500);
									
									/*if(cLib.WaitForPresenceOfElement("//span[contains(text(),'IMPORTANT ORDERING')]/"
											+ "following-sibling::button", getDriver(), 40).isDisplayed()){
										cLib.WaitForPresenceOfElement("//span[contains(text(),'IMPORTANT ORDERING')]/"
												+ "following-sibling::button", getDriver(), 40).click();
									}else{
										System.out.println("No Pup up>>>>>>>>>>>");
									}*/
									
								if(cLib.WaitForPresenceOfElement("//form[@id='basketForm']/div[contains"
										+ "(text(),'Your basket is currently empty')]", getDriver(), 
										40).isDisplayed()){
									System.out.println("There is no items in your cart");
									cLib.highlightElement(getDriver().findElement(By.xpath("//form[@id="
											+ "'basketForm']/div[contains(text(),'Your basket is currently"
											+ " empty')]")), getDriver());
									cLib.createDialogbox("Empty Cart", "There is no items in your cart :");
									System.out.println("Test link 4 Pass");
								}else{
									cLib.createDialogbox("EmptyCart Error", "Unable to Empty your Basket");
								}
							}else{
								cLib.createDialogbox("Link Test Error", "Getting 500 Error while testing "
										+getDriver().getTitle()+"page, Please report it to developer");
							}
						}catch(Exception sitesTL4){
							sitesTL4.printStackTrace();
							System.out.println("Error on abd link4 test");
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "
							+getDriver().getTitle()+"page");
						}
						
						/*try{
							//Open testlink5 for Abd
							System.out.println("Navigating to Abd test link5");
							getDriver().navigate().to("http://web1.uk-plc.net/abd/human-cd127-antibody-abd11590-hca144.html");
							getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
							if(getDriver().findElement(By.xpath("//div[@id='countries']"))
									.isDisplayed()){
								cLib.WaitForPresenceOfElement("//div[@id='countries']//div[@value='GB' and "
										+ "contains (text(),'United Kingdom')]",getDriver(), 30).click();
							}
							if(!getDriver().getTitle().contains("500")){
								cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[contains(text(),'UniProt')]/following-"
										+ "sibling::div/div[@class='ExtLinkSearch']/a",getDriver(), 40), getDriver());
								cLib.WaitForPresenceOfElement("//div[contains(text(),'UniProt')]/following-sibling::div/div[@class="
										+ "'ExtLinkSearch']/a",	getDriver(), 40).click();
								if(!getDriver().getTitle().contains("500")){
									System.out.println("Test link Pass");
									}else{
										System.out.println("500 Error in the test link");
										cLib.createDialogbox("500 Error", "Kindly report to concerned team");
									}
								}else{
									cLib.createDialogbox("500 Error", "Getting 500 Error while testing "
											+getDriver().getTitle()+"page, Please report it to developer");
								}

						}catch(Exception abdL5){
							abdL5.printStackTrace();
							System.out.println("Error on abd link5 test");
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
							getDriver().getTitle()+"page");
						}*/
						
						Thread.sleep(2000);
						try{
							//Open testlink6 for Abd
							System.out.println("Navigating to test Link 6");
							/*String windowId=getDriver().getWindowHandle();
							getDriver().switchTo().window(windowId);*/
							getDriver().navigate().to("http://web1.uk-plc.net/abd/drug-discovery.html");
							Thread.sleep(1000);
							System.out.println("Navigated to test Link 6");
							if(!getDriver().getTitle().contains("500")){
								cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='PageBody']//a[contains(text(),'More"
										+ " about anti-idiotypic')]",getDriver(), 40), getDriver());
								cLib.WaitForPresenceOfElement("//div[@id='PageBody']//a[contains(text(),'More"
										+ " about anti-idiotypic')]",getDriver(), 40).click();
								Thread.sleep(1000);
								if(getDriver().getTitle().contains("500")){
									System.out.println("500 Error in test link");
									cLib.createDialogbox("Link Test Error", "Getting Error while "
											+ "testing "+getDriver().getTitle()+"page");
									}else {
										System.out.println("No blockage...This test link passed");
											}
								}else{
									cLib.createDialogbox("Link Test Error", "Getting Error while "
											+ "testing "+getDriver().getTitle()+"page");
								}
						}catch(Exception abdL6){
							abdL6.printStackTrace();
							System.out.println("Error on abd link6 test");
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
							getDriver().getTitle()+"page");
						}
						
						Thread.sleep(2000);
						try{
							//Open testlink7 for Abd
							System.out.println("Navigating to test Link 7 for ABD");
							getDriver().navigate().to("http://web1.uk-plc.net/abd/anti-remicade-antibodies.html");
							if(!getDriver().getTitle().contains("500")){
								cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='LefthandMenu']//a[contains(text(),'Denosumab')]",	getDriver(),40), getDriver());
								WebElement lnk = cLib.WaitForPresenceOfElement("//div[@id='LefthandMenu']//a[contains(text(),'Denosumab')]",	getDriver(),40);
								JavascriptExecutor executor = (JavascriptExecutor)getDriver();
								executor.executeScript("arguments[0].click()",lnk );
								if(getDriver().getTitle().contains("500")){
									System.out.println("500 Error in test link");
									cLib.createDialogbox("500 Error", "Getting Error while testing"+
											getDriver().getTitle()+"page");
									}else {
										System.out.println("No blockage...This test link passed and all"
												+ " abd links got passed");
									}
							}else{
								cLib.createDialogbox("Link Test Error", "Getting Error while testing"+
								getDriver().getTitle()+"page");
							}
							
						}catch(Exception abdL7){
							abdL7.printStackTrace();
							System.out.println("Error on abd link7 test");
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
							getDriver().getTitle()+"page");
						}
						
						Thread.sleep(2000);
						try{
							//Open test link8 for Abd
							System.out.println("Navigating to test Link 8 for abd");
							getDriver().navigate().to("http://web1.uk-plc.net/abd/clinical-diagnostic-antigens-and-antibodies.html");
							System.out.println("Navigated to test Link 8 for abd");
							if(!getDriver().getTitle().contains("500")){
								WebElement ele = cLib.WaitForPresenceOfElement("//a[contains(text(),'Recombinant monoclonal antibody generation in just 8 weeks')]",getDriver(),40);
								cLib.highlightElement(ele, getDriver());
								JavascriptExecutor executor = (JavascriptExecutor)getDriver();
								executor.executeScript("arguments[0].click()",ele );
								if(getDriver().getTitle().contains("500")){
									System.out.println("500 Error in test link");
									cLib.createDialogbox("500 Error", "Report to Development team");
									}else {
										System.out.println("No blockage...This test link passed and all"
												+ " abd links got passed");
									}
							}else{
								cLib.createDialogbox("Link Test Error", "Getting Error while testing"+
								getDriver().getTitle()+"page");
							}
							
						}catch(Exception abdL8){
							abdL8.printStackTrace();
							System.out.println("Error on abd link8 test");
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
							getDriver().getTitle()+"page");
						}
						
						//Test link for SPS
						try{
							System.out.println("Navigating to test Link 1 for SPS");
							getDriver().navigate().to("http://web1.uk-plc.net/sps-consultancy/");

							if(!getDriver().getTitle().contains("500")){
								cLib.highlightElement(cLib.WaitForPresenceOfElement("//a[contains(text(),'commercial transformation solutions')]", getDriver(), 30), getDriver());
								cLib.WaitForPresenceOfElement("//a[contains(text(),'commercial transformation solutions')]", getDriver(), 30).click();
								
								if(!getDriver().getTitle().contains("500")){
									List<WebElement> lhMenuLink = getDriver().findElements(By.xpath("//div[@id='LefthandMenu']//a"));
									cLib.highlightElement(lhMenuLink.get(1), getDriver());
									Thread.sleep(2000);
									lhMenuLink.get(1).click();
									if(!getDriver().getTitle().contains("500")){
										System.out.println("No Blockage...Test link Pass");
									}else{
										System.out.println(" 500 Error on testlink");
										cLib.createDialogbox("Link Test Error", "Getting Error while "
												+ "testing :"+getDriver().getTitle()+"page, Please report it"
														+ " and Click on 'OK' to continue");
										}
								}else{
									System.out.println(" 500 Error on testlink");
									cLib.createDialogbox("Link Test Error", "Getting Error while "
											+ "testing :"+getDriver().getTitle()+"page, Please report it"
													+ " and Click on 'OK' to continue");
									}
								
							}else{
								System.out.println(" 500 Error on testlink");
								cLib.createDialogbox("Link Test Error", "Getting Error while "
										+ "testing :"+getDriver().getTitle()+"page, Please report it"
												+ " and Click on 'OK' to continue");
							}
						
					
						}catch(Exception spsL1){
							spsL1.printStackTrace();
							System.out.println("Error on sps link1 test");
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "
							+	getDriver().getTitle()+"page");
						}
						
						try{
							/*Open test link  for SPS test link2*/
							getDriver().navigate().to("http://web1.uk-plc.net/sps-consultancy/rss/index%20page%20feed.xml");
								if(!getDriver().getTitle().contains("500")){
									cLib.createDialogbox("Check for proper XML page", "Report to dev team for any Error, Click on 'Ok' button to continue");
								}else{
									System.out.println("500 error");
									cLib.createDialogbox("500 Error", "Report to dev team for 500 Error");
								}
						}catch(Exception spsSitesLinkErr2){
							System.out.println("Error on sps test Link ");
							spsSitesLinkErr2.printStackTrace();
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
							getDriver().getTitle()+"page");
						}
						
						
						/*try{
							//Open testlink1 for SPS
							getDriver().navigate().to("http://web1.uk-plc.net/sps-consultancy/");
							getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
							//Click on a link
							if(!getDriver().getTitle().contains("500")){
								cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='NavigationBar']"
										+ "//a[contains(text(),'About SPS')]", getDriver(), 30), getDriver());
								cLib.WaitForPresenceOfElement("//div[@id='NavigationBar']//a[contains(text(),"
									+ "'About SPS')]", getDriver(), 30).click();
							
								if(!getDriver().getTitle().contains("500")){
									System.out.println("No 500 Error on testlink");
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='Content']"
											+ "//a[contains(text(),"
											+ "'Knowledge Store')]", getDriver(), 30), getDriver());
									cLib.WaitForPresenceOfElement("//div[@id='Content']//a[contains(text(),"
											+ "'Knowledge Store')]", getDriver(), 30).click();
									
									if(!getDriver().getTitle().contains("500")){
										cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id="
												+ "'NavigationBar']//a[contains(text(),'Contact Us')]", 
												getDriver(), 30), getDriver());
										cLib.WaitForPresenceOfElement("//div[@id='NavigationBar']//a[contains"
												+ "(text(),'Contact Us')]", getDriver(), 30).click();
									}else{
										System.out.println(" 500 Error on testlink");
										cLib.createDialogbox("Link Test Error", "Getting Error while "
												+ "testing :"+getDriver().getTitle()+"page, Please report it"
														+ " and Click on 'OK' to continue");
										}
									}
								}else{
									System.out.println(" 500 Error on testlink");
									cLib.createDialogbox("Link Test Error", "Getting Error while "
											+ "testing :"+getDriver().getTitle()+"page, Please report it"
													+ " and Click on 'OK' to continue");
								}
						}catch(Exception SPSLink1Err){
							System.out.println("Error on SPS test Link ");
							SPSLink1Err.printStackTrace();
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
							getDriver().getTitle()+"page");
						}*/
						
						/*try{
							//Open testlink2 for SPS
							getDriver().navigate().to("http://web1.uk-plc.net/sps-consultancy/rss/index%20page%20feed.xml");
							getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
							
							//Click on a link
							if(!getDriver().getTitle().contains("500")){
								cLib.highlightElement(cLib.WaitForPresenceOfElement("//xhtml:div[@id='feedContent']", 
										getDriver(), 30), getDriver());
								List<WebElement> links = getDriver().findElements(By.xpath("//xhtml:div[@id='feedContent']"
										+ "//xhtml:a"));
								System.out.println("No of links --> "+links.size());
								for(WebElement ele : links){
									cLib.highlightElement(ele, getDriver());
									ele.click();
									break;
								}
								getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
								if(!getDriver().getTitle().contains("500")){
									System.out.println("No 500 Error on testlink and test link2 for SPS passed");
									}
								}else{
									System.out.println(" 500 Error on testlink2 for SPS");
									cLib.createDialogbox("Link Test Error", "Getting Error while "
											+ "testing :"+getDriver().getTitle()+"page, Please report it"
													+ " and Click on 'OK' to continue");
								}
						}catch(Exception SPSLink2Err){
							System.out.println("Error on SPS test Link ");
							SPSLink2Err.printStackTrace();
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
							getDriver().getTitle()+"page");
						}*/
						
						try{
							//Open testlink for Sites
							//cLib.openUrlInNewTab(getDriver(), "http://web1.uk-plc.net/ukplc-company-registrations/search.html");
							getDriver().navigate().to("http://web1.uk-plc.net/ukplc-company-registrations/search.html");
							getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
							String compName = "gobbledegook Eg dakfgajkfhlagkj";
							//Click on a link
							if(!getDriver().getTitle().contains("500")){
								cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='SearchTerm']", getDriver(), 30),
										getDriver());
								cLib.WaitForPresenceOfElement("//input[@id='SearchTerm']", getDriver(), 30).sendKeys(compName);
								cLib.highlightElement(cLib.WaitForPresenceOfElement("//form[@id='Form8563']//select[@id="
										+ "'CompanyType']", getDriver(), 40), getDriver());
								if(cLib.checkForSelectOptionExistance("//form[@id='Form8563']//select[@id='CompanyType']", "P",
										getDriver())){
									cLib.select("//form[@id='Form8563']//select[@id='CompanyType']", "P", getDriver());
								}else{
									cLib.createDialogbox("Option not available", "Unable to click or option not available in"
											+ " dropdown");
								}
								getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
								cLib.WaitForPresenceOfElement("//input[@id='Check']", getDriver(), 40).click();
								Thread.sleep(2000);
								if(!getDriver().getTitle().contains("500")){
									System.out.println("No 500 Error on testlink and test link2 for SPS: Passed");
									String msg = "Congratulations! "+compName+" PLC is available";
									String text = cLib.WaitForPresenceOfElement("//div[@id='PageTunnel']//h3[@class='congrats']",
											getDriver(), 40).getText();
									if(text.contains(msg)){
										System.out.println("Company name is available");
										cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='essential']//span[contains"
												+ "(text(),'SELECT')]", getDriver(), 40), getDriver());
										cLib.WaitForPresenceOfElement("//div[@id='essential']//span[contains(text(),'SELECT')]", 
												getDriver(), 40).click();
										getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
										if(!getDriver().getTitle().contains("500")&&getDriver().getCurrentUrl().contains("options."
												+ "html")){
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='EmbeddedBasketBlock']",
													getDriver(), 40), getDriver());
											cLib.createDialogbox("Confirmation", "Check the URLwhich should be landed on "
													+ "options.html and Check the layout and styling for all the pages​");
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='EmbeddedBasket']"
													+ "//a[contains(text(),'Empty Basket')]", getDriver(), 40), getDriver());
											cLib.WaitForPresenceOfElement("//div[@id='EmbeddedBasket']//a[contains(text(),"
													+ "'Empty Basket')]", getDriver(), 40).click();
											getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
											
											if(!getDriver().getTitle().contains("500")){
												System.out.println("No 500 Error , Testlink for CA Passed");
											}else{
												System.out.println(" 500 Error on testlink2 for SPS");
												cLib.createDialogbox("Link Test Error", "Getting Error while "
														+ "testing :"+getDriver().getTitle()+"page, Please report it"
																+ " and Click on 'OK' to continue");
											}
											
										}else{
											System.out.println(" 500 Error on testlink2 for Sites");
											cLib.createDialogbox("Link Test Error", "Getting Error while "
													+ "testing :"+getDriver().getTitle()+"page, Please report it"
															+ " and Click on 'OK' to continue");
										}
									}else
										System.out.println("Company name is Not available");
									}
								}else{
									System.out.println(" 500 Error on testlink2 for CA");
									cLib.createDialogbox("Link Test Error", "Getting Error while "
											+ "testing :"+getDriver().getTitle()+"page, Please report it"
													+ " and Click on 'OK' to continue");
								}
							
						}catch(Exception CALinkErr){
							System.out.println("Error on Company Admin test Link ");
							CALinkErr.printStackTrace();
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
							getDriver().getTitle()+"page");
						}
						
						/*Navigate to deployment application window*/
						cLib.openNewTabJSExecuter(getDriver());
						cLib.switchToNewTabByAryLst(getDriver());
						cLib.openURL(getDriver(), deploymentURL);
						
						/*getDriver().switchTo().window(cLib.navigateToParentWindow(getDriver()));*/
						cLib.createDialogbox("Deployment Confirmation: ", "All test links got tested and "
								+ "working as per expected \n Please complete ticket related testing if any"
								+ " and click on 'OK' 'Working' button");
						
						cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='deployment-actions']"
								+ "/a[contains(text(),'Working')]", getDriver(), 40), getDriver());
						cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//div[@id="
								+ "'deployment-actions']/a[contains(text(),'Working')]")), 30);
						
						if(cLib.WaitForPresenceOfElement("//div[@id='page']//div[@class='alert alert-success']"
								+ "//strong",getDriver(), 5400).isDisplayed()){
							cLib.createDialogbox("Success Message","Sites Deployed on Cressex environment "
									+ "successfully with successful message : "+getDriver().findElement(By.
										xpath("//div[@id='page']//div[@class='alert alert-success']//strong")).
									getText());
						}else{
							cLib.createDialogbox("Failure Message", "Sites is unable to Deploy on Cressex "
									+ "environment");
						}
							
						
					}else{
						if(getDriver().findElement(By.xpath("//strong[contains(text(),'Deployment "
								+ "failed')]")).isDisplayed()){
							cLib.createDialogbox("Failure Message", "Sites is unable to Deploy on Cressex "
									+ "environment");
						}
					}
				}while(status.contains("Deploying to first server"));
				
				System.out.println("Deployment completed");
			}catch(Exception e){
				e.printStackTrace();
			}
			
	
			
		}catch(Exception E){
			E.printStackTrace();
			if(getDriver().getTitle().equals("Server Error")){
				cLib.createDialogbox("Deployment Error : ","Unable to access deployment App" 
				+"due to Server Error");
				System.out.println("Error");
				getDriver().get("https://deployment.ukplc.corp");
			}
		}
		
		
	}
	
	@AfterClass
	public void configAfterClassMtd(){
		try {
			getDriver().close();
			getDriver().quit();
			vcLib.stopRecording();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
