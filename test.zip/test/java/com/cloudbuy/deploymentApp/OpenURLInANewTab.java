package com.cloudbuy.deploymentApp;


import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.security.UserAndPassword;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

/*This is my test comment I am trying to commit 16th nov 2017 */

import com.cloudbuy.deploymentApp.CommonLib;

public class OpenURLInANewTab{
	CommonLib cLib = new CommonLib();
	
	@Test
	public void openURL() throws InterruptedException {
		
		
		try {
			DesiredCapabilities caps = new DesiredCapabilities();
		FirefoxProfile profile = new FirefoxProfile();
		File modifyHder = new File("C:\\Users\\sandeep.behera\\Desktop\\modify_headers-0.7.1.1-fx.xpi");
		profile.setEnableNativeEvents(false);
		try{
			profile.addExtension(modifyHder);
		}catch(IOException IO){
			IO.printStackTrace();
			//Test
			
		}
		profile.setPreference("modifyheaders.config.active", true);
		profile.setPreference("modifyheaders.config.openNewTab", true);
		profile.setPreference("modifyheaders.config.alwaysOn", true);
		profile.setPreference("modifyheaders.config.start", true);
		profile.setPreference("modifyheaders.headers.count", 1);
		profile.setPreference("modifyheaders.headers.action1", "Modify");
		profile.setPreference("modifyheaders.headers.name0", "X-Forwarded-Proto");
		profile.setPreference("modifyheaders.headers.value0", "https");
		profile.setPreference("modifyheaders.headers.enabled0", true);
		caps.setCapability(FirefoxDriver.PROFILE, profile);
		WebDriver driver = new FirefoxDriver(caps);
		Runtime.getRuntime().exec("C:\\AutoIT\\AutoIT Scripts\\Helloworld.exe");
		Thread.sleep(2000);
		//driver.get("https://satyaprakash.pani:Kila@86!@deployment.ukplc.corp");
		driver.get("http://preview1.uk-plc.net/highways");
		Runtime.getRuntime().exec("C:\\AutoIT\\AutoIT Scripts\\Helloworld.exe");
		System.out.println("Authenticated dep app");
		Thread.sleep(1000);
		System.out.println("System wait till 1000ms");
		//driver.get("http://preview1.uk-plc.net/highways");
//		cLib.openUrlInNewTab(driver, "http://preview1.uk-plc.net/highways");
		System.out.println("Test link passed");
		//Runtime.getRuntime().exec("C:\\AutoIT\\AutoIT Scripts\\Helloworld.exe");
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*Runtime.getRuntime().exec("C:\\AutoIT\\AutoIT Scripts\\Test.exe");*/
		System.out.println("Authenticated");
		/*cLib.openUrlInNewTab(driver, "http://satyaprakash.pani:Kila@86!@intranet/AccountLookUp/AccountLookUp.aspx");
		Runtime.getRuntime().exec("C:\\AutoIT\\AutoIT Scripts\\Test.exe");
		System.out.println("Authenticated  5555");*/
		/*cLib.CopyAndPasteToHostFile("C:\\Users\\sandeep.behera\\Desktop\\Checkout", 
				"C:\\Windows\\System32\\drivers\\etc\\hosts");*/
		/*System.getProperties().put("http.proxyHost", "squid.ukplc.corp");
		System.getProperties().put("http.proxyPort", "3128");
		System.getProperties().put("http.proxyUser", "satyaprakash.pani");
		System.getProperties().put("http.proxyPassword", "Kila@86!");*/
		/*FirefoxProfile profile = new FirefoxProfile();
		profile.setPreference("network.proxy.type", 1);
		profile.setPreference("network.proxy.http", "squid.ukplc.corp");
		profile.setPreference("network.proxy.http_port", 3128);
		profile.setPreference("signon.autologin.proxy", true);
		WebDriver driver = new FirefoxDriver(profile);
		driver.get("https://deployment.ukplc.corp");
		cLib.openUrlInNewTab(driver, "http://satyaprakash.pani:Kila@86!@intranet/AccountLookUp/AccountLookUp.aspx");*/
		/*cLib.openNewTab(driver);
		 
		
		driver.navigate().to("http://satyaprakash.pani:Kila@86!@intranet/AccountLookUp/"
				+ "AccountLookUp.aspx");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@id='element71167']")).sendKeys("ha.cms");
		driver.findElement(By.xpath("//span[@id='div71174']/li/span/input")).click();
		cLib.waitAndClickElement(driver, driver.findElement(By.xpath("//a[contains(text(),"
				+ "'Control centre')]")), 10);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		cLib.openUrlInNewTab(driver, "http://preview1.uk-plc.net/highways");*/
		
		/*System.setProperty("webdriver.chrome.driver", "C:\\AutomationProjects\\Checkout\\Reference\\chromedriver.exe");
			WebDriver driver = new ChromeDriver();*/
		/*driver.navigate().to("http://sandeep.behera:Kila@1234+@intranet/AccountLookUp/AccountLookUp.aspx");
		driver.findElement(By.xpath("//input[@id='element71171']")).sendKeys("292717");
		driver.findElement(By.xpath("//span[@id='div71174']/li/span/input")).click();
		//cLib.WaitForPresenceOfElement("//a[contains(text(),'Control centre')]", driver, 10);
		cLib.waitAndClickElement(driver, driver.findElement(By.xpath("//a[contains(text(),'Control centre')]")), 10);
		cLib.openUrlInNewTab(driver, "http://secure1.uk-plc.net/checkout/receipt.aspx?ordernumber=2149232");*/
		/*driver.navigate().to("http://intranet/AccountLookUp/AccountLookUp.aspx");
		WebDriverWait wait = new WebDriverWait(driver, 10);
		
		Alert alt = wait.until(ExpectedConditions.alertIsPresent());
		alt.authenticateUsing(new UserAndPassword("sandeep.behera","Kila@1234"));
		System.out.println("Passed");*/
		
		
		
	}

}
