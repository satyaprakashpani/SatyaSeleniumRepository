package com.cloudbuy.deploymentApp;

import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class CompanyAdminOnCressex extends DriverSetUpCressx{
	CommonLib cLib =new CommonLib();
	CaptureVideo vcLib=new CaptureVideo();
	/*This will open browser and deployment application  */
	@BeforeClass
	public void configBeforeClass() {
		//Start video recording
		try {
			vcLib.startRecording();
		} catch (Exception videoException) {
			videoException.printStackTrace();
			System.out.println("Problem in video recording");
		}
		try{
			setDriver("https://deployment2.ukplc.corp");
			System.out.println("Inside beforeClass--> "+getDriver().getTitle());
			//cLib.WaitForPresenceOfElement("//input[@id='login' and @name='login']", getDriver(), 20);
			}catch(Exception e){
				e.printStackTrace();
				if(getDriver().getTitle().equals("Server Error")){
					System.out.println("Inside Catch if Server error");
					cLib.createDialogbox("Deployment Error : ","Unable to access deployment App "
					+"due to Server Error");
					getDriver().navigate().refresh();
				}else{
					cLib.createDialogbox("Deployment Error : ","Unable to access deployment App "
							+"due to deployment app Error");
				}
					
			}
		}
	
	/*Login to deployment application with valid credential */
	@BeforeMethod
	public void configMethod(){
		System.out.println("Inside before method");
		try{
			cLib.createDialogbox("Login Screen ","Please enter your credential and click on 'Submit'"
							+ " button before clicking on OK");
			//cLib.WebsitesToDepllomentApp(getDriver(), "satyaprakash.pani", "Kila@999!");
			/*if(getDriver().findElement(By.xpath("//a[contains(text(),'Applications')]")).getText().
					equals("")){
				System.out.println("Logged in to tha app");
			}*/
		}catch(Exception e){
				if(getDriver().getTitle().equals("Server Error")){
					cLib.createDialogbox("Login Error","Unable to Login");
					getDriver().close();
				}
		}
	}
	
	@Test
	public void DeployCompanyAdminOnCressexTest(){
		try{
			System.out.println("Inside DeployCompanyAdminOnCressexTest()");
			Set<String> wIds= getDriver().getWindowHandles();
			Iterator<String> itr = wIds.iterator();
			String parentWindowId = itr.next();
			System.out.println("parentWindowId--> "+parentWindowId);
			cLib.highlightElement(getDriver().findElement(By.xpath("//div[@id='page']")), getDriver());
			cLib.WaitForPresenceOfElement("//div[@id='page']", getDriver(), 40);
			cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//a[contains"
					+ "(text(),'Applications')]")), 40);
			Thread.sleep(2000);
			cLib.highlightElement(getDriver().findElement(By.xpath("//a[contains(text(),"
					+ "'Applications')]")), getDriver());
			
			/*Click on CA if Websites link is enabled*/
			WebElement CA = getDriver().findElement(By.xpath("//div[@id='page']//div[@class='list"
					+ "-group-item']//a[text()='Company Admin']"));
			if(CA.isEnabled()){
				System.out.println("CA Link is enabled");
				Thread.sleep(10000);
				cLib.highlightElement(CA, getDriver());
				System.out.println("CA loc: "+CA.getLocation());
				/*Actions act = new Actions(getDriver());
				act.click(Websites).perform();*/
				JavascriptExecutor executor = (JavascriptExecutor)getDriver();
				executor.executeScript("arguments[0].click()", CA);
				System.out.println("Company Admin Clicked");
				
				}
			if(cLib.WaitForPresenceOfElement("//div[@id='page']//h1", getDriver(), 30).isDisplayed()){
				cLib.highlightElement(getDriver().findElement(By.xpath("//div[@id='page']//h1")),
						getDriver());
				String oldBNo = getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/"
						+ "following-sibling::td[@class='text-right']")).getText();
				System.out.println("Old Build No : "+oldBNo);
				String data=getDriver().findElement(By.xpath("//tr[td[a[text()='Cressex']]]/td[contains"
						+ "(text(),'CompanyAdmin')]")).getText();
				/*System.out.println("Data-->"+data);
				System.out.println(data.split("-")[data.split("-").length-1]);*/
				
				/*Highlight and Click on build number drop-down*/
				cLib.highlightElement(getDriver().findElement(By.xpath("//td[a[contains(text(),"
						+ "'Cressex')]]/following-sibling::td//button[@class='btn dropdown-toggle "
						+ "btn-default']")), getDriver());
				getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/following-sibling"
						+ "::td//button[@class='btn dropdown-toggle btn-default']/span")).click();
				
				if(cLib.checkForOldBuild("//td[a[contains(text(),'Cressex')]]/following-sibling::td//"
						+ "span[@class='text']", getDriver(),Integer.valueOf(oldBNo))){
					System.out.println("Build number present");
					
					try{
					//cLib.clickOnOldBuild(oldBNo, getDriver());
						cLib.createDialogbox("Build Selection","Please change it manually");
					}catch(Exception selectBtn){
						cLib.createDialogbox("Build Not Found", "Dropdown is not enable to click");
						cLib.select("//tr[td[a[text()='Cressex']]]/td/form/select[@name='build']", 
								data.split("-")[data.split("-").length-1], getDriver());
					}
						}else{
							cLib.createDialogbox("Build Not Found", "Please change it manually");
							cLib.clickOnOldBuild(oldBNo, getDriver());
						}
				//Click on Deploy button
				try{
					cLib.highlightElement(getDriver().findElement(By.xpath("//td[a[contains(text(),"
							+ "'Cressex')]]/following-sibling::td//button[contains(text(),'Deploy')]"
							)),getDriver());
					System.out.println("Highlighted");
					
					/*Actions deploy = new Actions(getDriver());
					deploy.click(getDriver().findElement(By.xpath("//tr[td[a[text()='Cressex']]]/td/form"
							+ "/button[text()='Deploy' and @class='btn']"))).perform();*/
					getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/following-"
							+ "sibling::td//button[contains(text(),'Deploy')]")).click();
					System.out.println("Cliclked on 'Deploy'");
					
				}catch(Exception deploymentButton){
					cLib.createDialogbox("DeployButton", "Deploy Button is not Clickable");
					deploymentButton.printStackTrace();
				}
				
				/*Confirm deployment application, environment and build*/
				try{
					if(cLib.WaitForPresenceOfElement("//h2[text()='Confirm Deployment']", getDriver(),
							40).isDisplayed()){
						cLib.highlightElement(getDriver().findElement(By.xpath("//h2[text()='Confirm "
								+ "Deployment']")), getDriver());
						
						
						cLib.createDialogbox("Confirm deployment ", "If Application, Environment and Build "
								+ "No. are correct then click OK in dialog box, \nElse click 'Cancel' on "
								+ "deployment App then click on 'Ok' in dialoge ");
						
					}
				}catch(Exception e){
					e.printStackTrace();
					cLib.createDialogbox("Error :","Error in : "+getDriver().getCurrentUrl());
				}
				
				//Click on Continue button to deploy CA on First server
				cLib.waitAndClickElement(getDriver(),getDriver().findElement(By.xpath("//button[text()="
					+ "'Continue']")),40);
				
				System.out.println("Continue button clicked");
				
				try{
					String status = getDriver().findElement(By.xpath("//div[strong[contains(text(),"
							+ "'Status')]]/following-sibling::div/span")).getText();
					System.out.println("Status-->"+status);
					do{
						if(cLib.WaitForPresenceOfElement("//div[@id='deployment-actions']/a[contains(text(),"
								+ "'Working')]", getDriver(),5400).isDisplayed()){
							cLib.createDialogbox("Health Check", "Health Check for OK : Report in deployment channel or developer"
									+ " for health check failure");
							
							String deploymentURL = getDriver().getCurrentUrl();
							System.out.println("Dep Url --> "+deploymentURL);
							
							try{
								//Test
								
								/*Open a new window and open Account Lookup*/
								cLib.openNewTabJSExecuter(getDriver());
								cLib.switchToNewTabByAryLst(getDriver());
								
									//Open Account LookUp to login Control Centre for Basket
								System.out.println("Opening Acc Lookup to log into CC for Company Admin test links");
								cLib.openURL(getDriver(), "http://@intranet/AccountLookUp/AccountLookUp.aspx");
								//Search with Abd.administrator and click on ControlCentre
								getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
								getDriver().findElement(By.xpath("//input[@id='element71171']")).sendKeys
									("213021");
								getDriver().findElement(By.xpath("//span[@id='div71174']/li/span/input")).click();
								cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//"
										+ "a[contains(text(),'Control centre')]")), 10);
								getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
									
								}catch(Exception accntLookupLogin){
									accntLookupLogin.printStackTrace();
									System.out.println("Error while Logging into CC for ABD");
									cLib.createDialogbox("Account Lookup Error", "Getting Error while testing "
									+getDriver().getTitle()+"page");
								}
							
							
							//Open testlink for Company Admin test link1
							System.out.println("Navigating to Company Admin test link1");
							cLib.openNewTabJSExecuter(getDriver());
							cLib.switchToNewTabByAryLst(getDriver());
							cLib.openURL(getDriver(), "http://cadmin1.uk-plc.net/listcompanies.aspx");
							
							getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
							String frstNme = "Automation-";
							String surName = "Director"+Math.round(Math.random()*100);
							
							if((!getDriver().getTitle().contains("500"))){
								
								try{
									if(cLib.WaitForPresenceOfElement("//div[@id='appPageTitle']/h1", getDriver(), 40).getText().contains("My Companies and LLPs")){
										
										cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='appPageTitle']/h1",getDriver(), 30), getDriver());
										
										
										cLib.highlightElement(cLib.WaitForPresenceOfElement("//span[contains(text(),'DC Premier Testing Limited')]/ancestor::td/following-sibling::td//a[contains(text(),'View Details')]",getDriver(), 30), getDriver());
										cLib.WaitForPresenceOfElement("//span[contains(text(),'DC Premier Testing Limited')]/ancestor::td/following-sibling::td//a[contains(text(),'View Details')]",getDriver(), 30).click();
										
										if((!getDriver().getTitle().contains("500"))){
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='appColumn1']//input[@value='add DIRECTOR / SECRETARY / SHAREHOLDER / PSC']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//div[@id='appColumn1']//input[@value='add DIRECTOR / SECRETARY / SHAREHOLDER / PSC']",getDriver(), 30).click();
										}else{
											cLib.createDialogbox("Error", "Enter Details tab not appeared, please report to developer "+getDriver().getCurrentUrl()
													+"' page");
										}
										
										if((!getDriver().getTitle().contains("500"))){
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='checkDirector']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='checkDirector']",getDriver(), 30).click();
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Submit']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Submit']",getDriver(), 30).click();
										}else{
											cLib.createDialogbox("Error", "Enter Details tab not appeared, please report to developer "+getDriver().getCurrentUrl()
													+"' page");
										}
										
										if((!getDriver().getTitle().contains("500"))){
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='FirstForename']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='FirstForename']",getDriver(), 30).sendKeys(frstNme);
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Surname']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Surname']",getDriver(), 30).sendKeys(surName);
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//select[@id='Nationality']",getDriver(), 30), getDriver());
											cLib.select("//select[@id='Nationality']", "Indian", getDriver());
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Occupation']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Occupation']",getDriver(), 30).sendKeys("Doctor");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//select[@id='DOBDay']",getDriver(), 30), getDriver());
											cLib.select("//select[@id='DOBDay']", "15", getDriver());
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//select[@id='DOBMonth']",getDriver(), 30), getDriver());
											cLib.select("//select[@id='DOBMonth']", "9", getDriver());
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//select[@id='DOBYear']",getDriver(), 30), getDriver());
											cLib.select("//select[@id='DOBYear']", "1980", getDriver());
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='ResAddrSameAsServ']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='ResAddrSameAsServ']",getDriver(), 30).click();
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Submit']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Submit']",getDriver(), 30).click();
										}else{
											cLib.createDialogbox("Error", "Enter Details tab not appeared, please report to developer "+getDriver().getCurrentUrl()
													+"' page");
										}
										
										if((!getDriver().getTitle().contains("500"))){
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Address1']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Address1']",getDriver(), 30).sendKeys("House no : 134");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Town']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Town']",getDriver(), 30).sendKeys("Jodhpur");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Postcode']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Postcode']",getDriver(), 30).sendKeys("W1S 1DW");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Submit']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Submit']",getDriver(), 30).click();
											
										}else{
											System.out.println("Service Address not appeared");
											cLib.createDialogbox("Service Address not appeared", "Service Address tab not appeared, please report to developer "+getDriver().getCurrentUrl()
													+"' page");
										}
										
										if((!getDriver().getTitle().contains("500"))){
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Confirmation']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Confirmation']",getDriver(), 30).click();
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Proof']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Proof']",getDriver(), 30).click();
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Name']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Name']",getDriver(), 30).sendKeys("Satya");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Submit']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Submit']",getDriver(), 30).click();
											
											getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
											
											if((!getDriver().getTitle().contains("500"))){
												cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Submit']",getDriver(), 30), getDriver());
												cLib.WaitForPresenceOfElement("//input[@id='Submit']",getDriver(), 30).click();
											}else{
												System.out.println("Consent to act as director not appeared");
												cLib.createDialogbox("Consent to act as director not appeared", "Consent to act as director tab not appeared, please report to developer "+getDriver().getCurrentUrl()
														+"' page");
											}
											
											boolean toggle = false;
											if((!getDriver().getTitle().contains("500"))){
												
												List<WebElement> elements = getDriver().findElements(By.xpath("//th[contains(text(),'Name')]/../following-sibling::tr/td[1]"));
												
												cLib.highlightElements(elements, getDriver());
												String name = frstNme+" "+surName;
												System.out.println("Name = "+name);
												for(WebElement wb :elements){
													System.out.println(wb.getText());
													if(wb.getText().equals(name)){
														toggle=true;
														break;
													}
												}
												
												if(toggle){
													System.out.println("Link Pass");
												}else{
													System.out.println("Director name is not appeared as provided during registration");
													cLib.createDialogbox("Director Name Error", "Director name is not appeared as provided during registration, please report to developer ");
												}
												
											}else{
												System.out.println("Consent to act as director not appeared");
												cLib.createDialogbox("Consent to act as director not appeared", "Consent to act as director tab not appeared, please report to developer "+getDriver().getCurrentUrl()
														+"' page");
											}
											
										}else{
											System.out.println("Consent to act as director not appeared");
											cLib.createDialogbox("Consent to act as director not appeared", "Consent to act as director tab not appeared, please report to developer "+getDriver().getCurrentUrl()
													+"' page");
										}
									
									}else{
										System.out.println("Enter detail not appeared");
										cLib.createDialogbox("Enter details not appeared", "Enter Details tab not appeared, please report to developer "+getDriver().getCurrentUrl()
												+"' page");
									}
								}catch (Exception dtlEntryError){
									dtlEntryError.printStackTrace();
									cLib.createDialogbox("Enter details Error : ","Unable to enter details," 
											+"Please report to developer");
								}
							}
							
							try{
								//Open testlink for Company Admin test link2
								System.out.println("Navigating to Company Admin test link2");
								cLib.openURL(getDriver(), "http://cadmin1.uk-plc.net/PreRegistration/Nominees.aspx");
								
								getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
								
								if((!getDriver().getTitle().contains("500"))){
									
									try{
										if(cLib.WaitForPresenceOfElement("//ul[@id='nav']//a[text()='My Companies (and LLPs)']", getDriver(), 40).isDisplayed()){
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//ul[@id='nav']//a[text()='My Companies (and LLPs)']",getDriver(), 30), getDriver());
											
											
											cLib.WaitForPresenceOfElement("//ul[@id='nav']//a[text()='My Companies (and LLPs)']",getDriver(), 30).click();
											
											if((!getDriver().getTitle().contains("500"))){
												
												cLib.highlightElement(cLib.WaitForPresenceOfElement("//ul[@id='nav']//a[text()='My Services']",getDriver(), 30), getDriver());
												cLib.WaitForPresenceOfElement("//ul[@id='nav']//a[text()='My Services']",getDriver(), 30).click();
												
											}else{
												cLib.createDialogbox("Error", "Enter Details tab not appeared, please report to developer "+getDriver().getCurrentUrl()
														+"' page");
											}
											System.out.println("11");
											if((!getDriver().getTitle().contains("500"))){
												
												cLib.highlightElement(cLib.WaitForPresenceOfElement("//ul[@id='nav']//a[text()='Form a new company']",getDriver(), 30), getDriver());
												cLib.WaitForPresenceOfElement("//ul[@id='nav']//a[text()='Form a new company']",getDriver(), 30).click();
												
												getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
												
												getDriver().navigate().back();
												
											}else{
												cLib.createDialogbox("Error", "Enter Details tab not appeared, please report to developer "+getDriver().getCurrentUrl()
														+"' page");
											}
											System.out.println("12");
											if((!getDriver().getTitle().contains("500"))){
												
												cLib.highlightElement(cLib.WaitForPresenceOfElement("//ul[@id='nav']//a[text()='Companies House Paper Forms']",getDriver(), 30), getDriver());
												cLib.WaitForPresenceOfElement("//ul[@id='nav']//a[text()='Companies House Paper Forms']",getDriver(), 30).click(); 
												
												
												getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
											}else{
												cLib.createDialogbox("Error", "Enter Details tab not appeared, please report to developer "+getDriver().getCurrentUrl()
														+"' page");
											}
											System.out.println("13");
											if((!getDriver().getTitle().contains("500"))){
												
												cLib.highlightElement(cLib.WaitForPresenceOfElement("//ul[@id='nav']//a[text()='Control Centre']",getDriver(), 30), getDriver());
												cLib.WaitForPresenceOfElement("//ul[@id='nav']//a[text()='Control Centre']",getDriver(), 30).sendKeys("House no : 134");
												
												getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
												
												getDriver().navigate().back();
												
												System.out.println("Jai Jagannath");
											}else{
												System.out.println("Service Address not appeared");
												cLib.createDialogbox("Service Address not appeared", "Service Address tab not appeared, please report to developer "+getDriver().getCurrentUrl()
														+"' page");
											}
											
											if((!getDriver().getTitle().contains("500"))){
												
												cLib.highlightElement(cLib.WaitForPresenceOfElement("//ul[@id='nav']//a[text()='Our Company Services']/following-sibling::div",getDriver(), 30), getDriver());
												cLib.WaitForPresenceOfElement("//ul[@id='nav']//a[text()='Our Company Services']/following-sibling::div",getDriver(), 30).click();
												
												cLib.highlightElement(cLib.WaitForPresenceOfElement("//ul[@id='nav']//ul//a[text()='Company Services']",getDriver(), 30), getDriver());
												cLib.WaitForPresenceOfElement("//ul[@id='nav']//ul//a[text()='Company Services']",getDriver(), 30).click();
												 System.out.println("14");
												
												getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
												
												if((!getDriver().getTitle().contains("500"))){
													System.out.println("15");
													cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='PageTitle']/h1",getDriver(), 30), getDriver());
													getDriver().navigate().back();
													
													getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
												}else{
													System.out.println("Our Company Services not appeared");
													cLib.createDialogbox("Our Company Services not appeared", "Our Company Services menu link not appeared, please report to developer "+getDriver().getCurrentUrl()
															+"' page");
												}
												
												if((!getDriver().getTitle().contains("500"))){
													System.out.println("16");
													cLib.highlightElement(cLib.WaitForPresenceOfElement("//ul[@id='nav']//a[text()='Services from our Business Partners']/following-sibling::div",getDriver(), 30), getDriver());
													cLib.WaitForPresenceOfElement("//ul[@id='nav']//a[text()='Services from our Business Partners']/following-sibling::div",getDriver(), 30).click();
													
													cLib.highlightElement(cLib.WaitForPresenceOfElement("//ul[@id='nav']//a[text()='Barclays Business Bank Account']",getDriver(), 30), getDriver());
													cLib.WaitForPresenceOfElement("//ul[@id='nav']//a[text()='Barclays Business Bank Account']",getDriver(), 30).click();
													
													if((!getDriver().getTitle().contains("500"))){
														System.out.println("17");
														cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='PageTitle']/h1",getDriver(), 30), getDriver());
														
														getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
													}else{
														System.out.println("Barclays Business Bank Account not appeared");
														cLib.createDialogbox("SBarclays Business Bank Account not appeared", "Barclays Business Bank Account menu link not appeared, please report to developer "+getDriver().getCurrentUrl()
																+"' page");
													}
												}
											}else{
												System.out.println("Consent to act as director not appeared");
												cLib.createDialogbox("Consent to act as director not appeared", "Consent to act as director tab not appeared, please report to developer "+getDriver().getCurrentUrl()
														+"' page");
											}
										
										}else{
											System.out.println("Enter detail not appeared");
											cLib.createDialogbox("Enter details not appeared", "Enter Details tab not appeared, please report to developer "+getDriver().getCurrentUrl()
													+"' page");
										}
									}catch (Exception dtlEntryError){
										dtlEntryError.printStackTrace();
										cLib.createDialogbox("Enter details Error : ","Unable to enter details," 
												+"Please report to developer");
									}
									
									
								}else{
									cLib.createDialogbox("500 Error", "Getting 500 error for '"+getDriver().getCurrentUrl()
											+"' page");
									}

							}catch(Exception BLinkError1){
								BLinkError1.printStackTrace();
								if(getDriver().getTitle().equals("Server Error")){
									cLib.createDialogbox("Deployment Error : ","Unable to access deployment App" 
									+"due to Server Error");
									System.out.println("Error");
									getDriver().get("https://deployment.ukplc.corp");
								}else if(getDriver().getTitle().equals("502 Bad Gateway")){
									cLib.createDialogbox("Deployment App Error : ","502 Bad Gateway");
											System.out.println("Error");
								}
							}
							

							/*Navigate to deployment application window*/
							
							
							
							//getDriver().switchTo().window(cLib.navigateToParentWindow(getDriver()));
							
							cLib.openNewTabJSExecuter(getDriver());
							cLib.switchToNewTabByAryLst(getDriver());
							cLib.openURL(getDriver(), deploymentURL);
							
							cLib.createDialogbox("Deployment Confirmation: ", "All test links got tested and "
									+ "working as per expected \n Please complete ticket related testing if any"
									+ " and click on 'OK' 'Working' button");
							
							cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='deployment-actions']"
									+ "/a[contains(text(),'Working')]", getDriver(), 40), getDriver());
				/*			cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//div[@id='page']"
									+ "//div[@id='deployment-actions']/a[contains(text(),'Working')]")), 40);*/
							
							cLib.clickElemntByMouseMovement(getDriver(), cLib.WaitForPresenceOfElement("//div[@id='page']"
									+ "//div[@id='deployment-actions']/a[contains(text(),'Working')]", getDriver(), 40));
							
							if(cLib.WaitForPresenceOfElement("//div[@id='page']//div[@class='alert alert-success']"
									+ "//strong",getDriver(), 1800).isDisplayed()){
								cLib.createDialogbox("Success Message","Company Admin Deployed on Cressex environment "
										+ "successfully with successful message : "+getDriver().findElement(By.
											xpath("//div[@id='page']//div[@class='alert alert-success']//strong")).
										getText());
							}else{
								cLib.createDialogbox("Failure Message", "CA is unable to Deploy on Cressex "
										+ "environment");
							}
							
							
						}else{				//Else for 'Working' button availability 
							System.out.println("Working button is not available");
							cLib.createDialogbox("Working button Error", "Working button is not available, kindly check the "
									+ "deployment app for more info...");
							}
							
						}while(status.contains("Deploying to first server"));
						
					}catch(Exception e){
						e.printStackTrace();
						if(getDriver().findElement(By.xpath("//h1[contains(text(),'502 Bad Gateway')]")).isDisplayed()){
							cLib.createDialogbox("Bad Gateway Error", "502 Bad Gateway : Report to Infra or Dev team");
						}
					}
				
			}else{
				cLib.createDialogbox("Navigation Error", "Unable to navigate Registration page ");
				}	
			
		}catch(Exception CAErr){
			CAErr.printStackTrace();
			if(getDriver().getTitle().equals("Server Error")){
				cLib.createDialogbox("Deployment Error : ","Unable to access deployment App" 
				+"due to Server Error");
				System.out.println("Error");
				getDriver().get("https://deployment.ukplc.corp");
				}
			}
		}
	
	
	
	@AfterClass
	public void configAfterClassMtd(){
		try {
			getDriver().close();
			getDriver().quit();
			vcLib.stopRecording();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
