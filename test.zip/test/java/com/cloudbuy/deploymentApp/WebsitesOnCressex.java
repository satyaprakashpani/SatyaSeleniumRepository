package com.cloudbuy.deploymentApp;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class WebsitesOnCressex extends DriverSetUpCressx  {
	CommonLib cLib =new CommonLib();
	CaptureVideo vcLib=new CaptureVideo();
	/*This will open browser and deployment application  */
	@BeforeClass
	public void configBeforeClass() {
		//Start video recording
		try {
			vcLib.startRecording();
		} catch (Exception videoException) {
			videoException.printStackTrace();
			System.out.println("Problem in video recording");
		}
		try{
			setDriver("https://deployment2.ukplc.corp");
			getDriver().navigate().refresh();
			System.out.println("Inside beforeClass--> "+getDriver().getTitle());
			/*cLib.WaitForPresenceOfElement("//input[@id='login']", getDriver(), 30);*/
			System.out.println("Login screen appears");
			}catch(Exception e){
				System.out.println("---------------------");
				e.printStackTrace();
				if(getDriver().getTitle().equals("Server Error")){
					
					getDriver().navigate().refresh();
				}else{
					cLib.createDialogbox("Deployment Error : ","Unable to access deployment App "
							+"due to deployment app Error");
				}
					
			}
		}
	
	/*Websites to deployment application with valid credential */
	@BeforeMethod
	public void configMethod(){
		System.out.println("Inside before method");
		try{
			cLib.createDialogbox("Login ","Please enter your credential and click on 'Submit'"
							+ " button before clicking on OK");
			//cLib.WebsitesToDepllomentApp(getDriver(), "satyaprakash.pani", "Kila@999!");
			/*if(getDriver().findElement(By.xpath("//a[contains(text(),'Applications')]")).getText().
					equals("")){
				System.out.println("Logged in to tha app");
			}*/
		}catch(Exception e){
				if(getDriver().getTitle().equals("Server Error")){
					cLib.createDialogbox("Websites Error","Unable to Websites");
					getDriver().close();
				}
		}
	}

	@Test
	public void deployWebsitesOnCressexTest(){
		System.out.println("Inside deployWebsitesOnCressexTest()");
		try{
			cLib.highlightElement(getDriver().findElement(By.xpath("//div[@id='page']")), getDriver());
			//cLib.WaitForPresenceOfElement("//div[@id='page']", getDriver(), 40);
			cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//a[contains"
					+ "(text(),'Applications')]")), 40);
			Thread.sleep(2000);
			cLib.highlightElement(getDriver().findElement(By.xpath("//a[contains(text(),"
					+ "'Applications')]")), getDriver());
			
			/*Click on Websites if Websites link is enabled*/
			WebElement websites = getDriver().findElement(By.xpath("//div[@id='page']//div[@class='list"
					+ "-group-item']//a[text()='Websites']"));
			if(websites.isEnabled()){
				System.out.println("Websites Link is enabled");
				Thread.sleep(10000);
				cLib.highlightElement(websites, getDriver());
				System.out.println("Websites loc: "+websites.getLocation());
				/*Actions act = new Actions(getDriver());
				act.click(Websites).perform();*/
				JavascriptExecutor executor = (JavascriptExecutor)getDriver();
				executor.executeScript("arguments[0].click()", websites);
				System.out.println("Websites Clicked");
				
				}
			if(cLib.WaitForPresenceOfElement("//div[@id='page']//h1", getDriver(), 30).isDisplayed()){
				cLib.highlightElement(getDriver().findElement(By.xpath("//div[@id='page']//h1")),
						getDriver());
				String oldBNo = getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/"
						+ "following-sibling::td[@class='text-right']")).getText();
				System.out.println("Old Build No : "+oldBNo);
				String data=getDriver().findElement(By.xpath("//tr[td[a[text()='Cressex']]]/td[contains"
						+ "(text(),'Purchasing-Build')]")).getText();
				/*System.out.println("Data-->"+data);
				System.out.println(data.split("-")[data.split("-").length-1]);*/
				
				/*Highlight and Click on build number drop-down*/
				cLib.highlightElement(getDriver().findElement(By.xpath("//td[a[contains(text(),"
						+ "'Cressex')]]/following-sibling::td//button[@class='btn dropdown-toggle "
						+ "btn-default']")), getDriver());
				getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/following-sibling"
						+ "::td//button[@class='btn dropdown-toggle btn-default']/span")).click();
				
				if(cLib.checkForOldBuild("//td[a[contains(text(),'Cressex')]]/following-sibling::td//"
						+ "span[@class='text']", getDriver(),Integer.valueOf(oldBNo))){
					System.out.println("Build number present");
					
					try{
					//cLib.clickOnOldBuild(oldBNo, getDriver());
						cLib.createDialogbox("Build Selection","Please change it manually");
					}catch(Exception selectBtn){
						cLib.createDialogbox("Build Not Found", "Dropdown is not enable to click");
						cLib.select("//tr[td[a[text()='Cressex']]]/td/form/select[@name='build']", 
								data.split("-")[data.split("-").length-1], getDriver());
					}
						}else{
							cLib.createDialogbox("Build Not Found", "Please change it manually");
							cLib.clickOnOldBuild(oldBNo, getDriver());
						}
				
				//Click on Deploy button
				try{
					cLib.highlightElement(getDriver().findElement(By.xpath("//td[a[contains(text(),"
							+ "'Cressex')]]/following-sibling::td//button[contains(text(),'Deploy')]"
							)),getDriver());
					System.out.println("Highlighted");
					
					/*Actions deploy = new Actions(getDriver());
					deploy.click(getDriver().findElement(By.xpath("//tr[td[a[text()='Cressex']]]/td/form"
							+ "/button[text()='Deploy' and @class='btn']"))).perform();*/
					getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/following-"
							+ "sibling::td//button[contains(text(),'Deploy')]")).click();
					System.out.println("Cliclked on 'Deploy'");
					
				}catch(Exception deploymentButton){
					cLib.createDialogbox("DeployButton", "Deploy Button is not Clickable");
					deploymentButton.printStackTrace();
				}
				
				/*Confirm deployment application, environment and build*/
				try{
					if(cLib.WaitForPresenceOfElement("//h2[text()='Confirm Deployment']", getDriver(),
							40).isDisplayed()){
						cLib.highlightElement(getDriver().findElement(By.xpath("//h2[text()='Confirm "
								+ "Deployment']")), getDriver());
						
						
						cLib.createDialogbox("Confirm deployment ", "If Application, Environment and Build "
								+ "No. are correct then click OK in dialog box, \nElse click 'Cancel' on "
								+ "deployment App then click on 'Ok' in dialoge ");
						
					}
				}catch(Exception e){
					e.printStackTrace();
					cLib.createDialogbox("Error :","Error in : "+getDriver().getCurrentUrl());
				}
				
				//Click on Continue button to deploy Websites on First server
				cLib.waitAndClickElement(getDriver(),getDriver().findElement(By.xpath("//button[text()="
					+ "'Continue']")),40);
				
				System.out.println("Continue button clicked");
				
				
				try{
					String status = getDriver().findElement(By.xpath("//div[strong[contains(text(),"
							+ "'Status')]]/following-sibling::div/span")).getText();
					System.out.println("Status-->"+status);
					do{
						String deploymentURL = getDriver().getCurrentUrl();
						System.out.println("Dep Url --> "+deploymentURL);
						
						if(cLib.WaitForPresenceOfElement("//div[@id='deployment-actions']/a[contains(text(),"
								+ "'Working')]", getDriver(),5400).isDisplayed()){
							cLib.createDialogbox("Health Check", "Health Check for OK : Report in deployment channel or developer"
									+ " for health check failure");
			
			try{
				
				//Open a new window and open Account Lookup
				cLib.openNewTabJSExecuter(getDriver());
				cLib.switchToNewTabByAryLst(getDriver());
				
					//Open Account LookUp to Websites Control Centre for Websites
				Runtime.getRuntime().exec("C:\\AutoIT\\AutoItScript\\Test.exe");
				Thread.sleep(1000);
				System.out.println("Opening Acc Lookup to log into Highways");
				cLib.openURL(getDriver(), "http://satyaprakash.pani:Kila@999!@intranet/"
						+ "AccountLookUp/AccountLookUp.aspx");
				//Search with Abd.administrator and click on ControlCentre
				getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				getDriver().findElement(By.xpath("//input[@id='element71172']")).sendKeys
					("479824");
				getDriver().findElement(By.xpath("//span[@id='div71174']/li/span/input")).click();
				cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//"
						+ "a[contains(text(),'Control centre')]")), 10);
				getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					
				}catch(Exception accntLookupWebsites){
					accntLookupWebsites.printStackTrace();
					System.out.println("Error while Logging into CC for ABD");
					cLib.createDialogbox("Account Lookup Error", "Getting Error while testing "
					+getDriver().getTitle()+"page");
				}
		
			try{
				//Open testlink for Websites test link1
				System.out.println("Navigating to Websites test link1");
				cLib.openUrlInNewTab(getDriver(), " purchasing1.uk-plc.net/websites/index.aspx?companyid=479824");
				getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
				
				if((!getDriver().getTitle().contains("500"))){
					cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@class='wrapper']",getDriver(), 30), getDriver());
					
					cLib.highlightElement(cLib.WaitForPresenceOfElement("//a[contains(text(),'A-Z item list')]",getDriver(), 30), getDriver());
					cLib.WaitForPresenceOfElement("//a[contains(text(),'A-Z item list')]",getDriver(), 30).click();
					
					cLib.highlightElement(cLib.WaitForPresenceOfElement("//a[text()='D']",getDriver(), 30), getDriver());
					cLib.WaitForPresenceOfElement("//a[text()='D']",getDriver(), 30).click();
					
					getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
					
					try{
						if(!getDriver().getTitle().contains("500")){
							System.out.println("Navigated to : "+getDriver().getTitle());
							
							cLib.highlightElement(cLib.WaitForPresenceOfElement("//a[starts-with(text(),'D')]",getDriver(), 30), getDriver());
							List<WebElement> elements = getDriver().findElements(By.xpath("//a[starts-with(text(),'D')]"));
							cLib.highlightElements(elements, getDriver());
							cLib.WaitForPresenceOfElement("//a[starts-with(text(),'D')]", getDriver(), 30).click();
							
							cLib.highlightElement(cLib.WaitForPresenceOfElement("//a[text()='X']",getDriver(), 30), getDriver());
							cLib.WaitForPresenceOfElement("//a[text()='X']",getDriver(), 30).click();
							
							cLib.highlightElement(cLib.WaitForPresenceOfElement("//a[starts-with(text(),'X')]",getDriver(), 30), getDriver());
							List<WebElement> elementX = getDriver().findElements(By.xpath("//a[starts-with(text(),'X')]"));
							cLib.highlightElements(elementX, getDriver());
							cLib.WaitForPresenceOfElement("//a[starts-with(text(),'X')]", getDriver(), 30).click();
							
							
							cLib.highlightElement(cLib.WaitForPresenceOfElement("//a[contains(text(),'GOLD')]",getDriver(), 30), getDriver());
							String linkText = cLib.WaitForPresenceOfElement("//a[contains(text(),'GOLD')]",getDriver(), 30).getText();
							cLib.WaitForPresenceOfElement("//a[contains(text(),'GOLD')]",getDriver(), 30).click();
							
							getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
							
							cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='ukplcWysiwygPageTitle']",getDriver(), 30), getDriver());
							String prodTitle = cLib.WaitForPresenceOfElement("//div[@id='ukplcWysiwygPageTitle']",getDriver(), 30).getText();
							
							if(linkText.trim().equals(prodTitle.trim())){
								System.out.println("Link and prod name same ");
							}else{
								System.out.println("Link and prod name different");
							}
							//Test
						}else{
						cLib.createDialogbox("500 Error", "Getting 500 error for '"+getDriver().getCurrentUrl()
								+"' page");
						}
						
					}catch(Exception e){
						cLib.createDialogbox("Error", "Getting 500 error for '"+getDriver().getCurrentUrl()
								+"' page");
					}
				}else{
					cLib.createDialogbox("500 Error", "Getting 500 error for '"+getDriver().getCurrentUrl()
							+"' page");
					}

			}catch(Exception websitesError1){
				websitesError1.printStackTrace();
				if(getDriver().getTitle().equals("Server Error")){
					cLib.createDialogbox("Deployment Error : ","Unable to access deployment App" 
					+"due to Server Error");
					System.out.println("Error");
					getDriver().get("https://deployment.ukplc.corp");
				}else if(getDriver().getTitle().equals("502 Bad Gateway")){
					cLib.createDialogbox("Deployment App Error : ","502 Bad Gateway");
							System.out.println("Error");
				}
			}
				
				
			
			
			
			/*Navigate to deployment application window*/
			/*getDriver().switchTo().window(cLib.navigateToParentWindow(getDriver()));*/
			
			cLib.openNewTabJSExecuter(getDriver());
			cLib.switchToNewTabByAryLst(getDriver());
			cLib.openURL(getDriver(), deploymentURL);
			
			cLib.createDialogbox("Deployment Confirmation: ", "All test links got tested and "
					+ "working as per expected \n Please complete ticket related testing if any"
					+ " and click on 'OK' 'Working' button");
			
			cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='deployment-actions']"
					+ "/a[contains(text(),'Working')]", getDriver(), 40), getDriver());
/*			cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//div[@id='page']"
					+ "//div[@id='deployment-actions']/a[contains(text(),'Working')]")), 40);*/
			
			cLib.clickElemntByMouseMovement(getDriver(), cLib.WaitForPresenceOfElement("//div[@id='page']"
					+ "//div[@id='deployment-actions']/a[contains(text(),'Working')]", getDriver(), 40));
			
			if(cLib.WaitForPresenceOfElement("//div[@id='page']//div[@class='alert alert-success']"
					+ "//strong",getDriver(), 1800).isDisplayed()){
				cLib.createDialogbox("Success Message","Websites Deployed on Cressex environment "
						+ "successfully with successful message : "+getDriver().findElement(By.
							xpath("//div[@id='page']//div[@class='alert alert-success']//strong")).
						getText());
			}else{
				cLib.createDialogbox("Failure Message", "Websites is unable to Deploy on Cressex "
						+ "environment");
			}
			
						}else{				//Else for 'Working' button availability 
							System.out.println("Working button is not available");
							cLib.createDialogbox("Working button Error", "Working button is not available, kindly check the "
									+ "deployment app for more info...");
						}
			
						}while(status.contains("Deploying to first server"));
					
					}catch(Exception e){
						e.printStackTrace();
						if(getDriver().findElement(By.xpath("//h1[contains(text(),'502 Bad Gateway')]")).isDisplayed()){
							cLib.createDialogbox("Bad Gateway Error", "502 Bad Gateway : Report to Infra or Dev team");
						}	}
			
			}else{
				cLib.createDialogbox("Navigation Error", "Unable to navigate Websites page ");
			}
		}catch(Exception wbErr){
			wbErr.printStackTrace();
			if(getDriver().getTitle().equals("Server Error")){
				cLib.createDialogbox("Deployment Error : ","Unable to access deployment App" 
				+"due to Server Error");
				System.out.println("Error");
				getDriver().get("https://deployment2.ukplc.corp");
				}
		}
		
	}
	
	@AfterClass
	public void configAfterClassMtd(){
		try {
			getDriver().close();
			getDriver().quit();
			vcLib.stopRecording();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
