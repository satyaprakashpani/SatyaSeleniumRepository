package com.cloudbuy.deploymentApp;


import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.media.jai.operator.GradientMagnitudeDescriptor;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.thoughtworks.selenium.webdriven.commands.Highlight;

public class PreviewCressex extends DriverSetUpCressx {
	CommonLib cLib =new CommonLib();
	CaptureVideo vcLib=new CaptureVideo();
	
	/*This will open browser and deployment application  */
	@BeforeClass
	public void configBeforeClass() {
		//Start video recording
		try {
			vcLib.startRecording();
		} catch (Exception videoException) {
			videoException.printStackTrace();
			System.out.println("Problem in video recording");
		}
		try{
			setDriver("https://satyaprakash.pani:ChangeMe!@deployment2.ukplc.corp");
			getDriver().navigate().refresh();
			System.out.println("Inside beforeClass--> "+getDriver().getTitle());
			cLib.WaitForPresenceOfElement("//input[@id='login']", getDriver(), 20);
			}catch(Exception e){
				e.printStackTrace();
				if(getDriver().getTitle().equals("Server Error")){
					System.out.println("Inside Catch if Server error");
					cLib.createDialogbox("Deployment Error : ","Unable to access deployment App "
					+"due to Server Error");
					getDriver().navigate().refresh();
				}else{
					cLib.createDialogbox("Deployment Error : ","Unable to access deployment App "
							+"due to deployment app Error");
				}
					
			}
		}
	
	
	/*Login to deployment application with valid credential */
	@BeforeMethod
	public void configMethod(){
		System.out.println("Inside before method");
		try{
			cLib.createDialogbox("Login Screen ","Please enter your credential and click on 'Submit'"
							+ " button before clicking on OK");
			//cLib.WebsitesToDepllomentApp(getDriver(), "satyaprakash.pani", "Kila@999!");
			/*if(getDriver().findElement(By.xpath("//a[contains(text(),'Applications')]")).getText().
					equals("")){
				System.out.println("Logged in to tha app");
			}*/
		}catch(Exception e){
				if(getDriver().getTitle().equals("Server Error")){
					cLib.createDialogbox("Login Error","Unable to Login");
					getDriver().close();
				}
		}
	}
		
	
	
	@Test
	public void DeployPreviewTest(){
		try{
			cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//a[contains"
					+ "(text(),'Applications')]")), 40);
			/*Thread.sleep(10000);*///application response is not same so need to wait long time to	
			//synchronize
			cLib.highlightElement(getDriver().findElement(By.xpath("//a[contains(text(),"
					+ "'Applications')]")), getDriver());
			
			/*Click on Preview if Preview link is enabled*/
			WebElement preview = getDriver().findElement(By.xpath("//div[@id='page']//div[@class="
					+ "'list-group-item']//a[@href='/applications/preview']"));
			
			if(getDriver().findElement(By.linkText("Preview")).isEnabled()){
				System.out.println("Preview Link is enabled");
				Thread.sleep(6000);
				cLib.highlightElement(preview, getDriver());
				System.out.println("preview loc: "+preview.getLocation());
				/*Actions act = new Actions(getDriver());
				act.click(preview).perform();*/
				JavascriptExecutor executor = (JavascriptExecutor)getDriver();
				executor.executeScript("arguments[0].click()", preview);
				System.out.println("Preview Clicked");
				
				/*Thread.sleep(4000);
				preview.click();*/
				}
			
			/*Click on Deployments tab*/
			/*WebElement deployButton = getDriver().findElement(By.xpath("//td[a[contains(text(),"
					+ "'Cressex')]]/following-sibling::td//button[text()='Deploy']"));
			if(cLib.WaitForPresenceOfElement("//td[a[contains(text(),'Cressex')]]/following-sibling"
					+ "::td//button[text()='Deploy']", getDriver(), 40).isEnabled()){
				cLib.waitAndClickElement(getDriver(), deployButton, 40);
				System.out.println("Deployment Clicked");
			}else{
				cLib.createDialogbox("Deployment Link Issue", "Deployment Link is not enabled");
			}*/
			
			if(cLib.WaitForPresenceOfElement("//div[@id='page']//h1", getDriver(), 30).isDisplayed()){
				cLib.highlightElement(getDriver().findElement(By.xpath("//div[@id='page']//h1")),
						getDriver());
				String oldBNo = getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/"
						+ "following-sibling::td[@class='text-right']")).getText();
				System.out.println("Old Build No : "+oldBNo);
				String data=getDriver().findElement(By.xpath("//tr[td[a[text()='Cressex']]]/td[contains"
						+ "(text(),'Sites-Build')]")).getText();
				/*System.out.println("Data-->"+data);
				System.out.println(data.split("-")[data.split("-").length-1]);*/
				
				/*Highlight Click on build number drop-down*/
				cLib.highlightElement(getDriver().findElement(By.xpath("//td[a[contains(text(),"
						+ "'Cressex')]]/following-sibling::td//button[@class='btn dropdown-toggle "
						+ "btn-default']")), getDriver());
				cLib.WaitForPresenceOfElement("//td[a[contains(text(),'Cressex')]]/following-sibling::td"
						+ "//button[@class='btn dropdown-toggle btn-default']/span", getDriver(), 40).click();
				Thread.sleep(1000);
				
				if(cLib.checkForOldBuild("//td[a[contains(text(),'Cressex')]]/following-sibling::td//"
						+ "span[@class='text']", getDriver(),Integer.valueOf(oldBNo))){
					System.out.println("Build number present");
					try{
					
						//cLib.clickOnOldBuild(oldBNo, getDriver());
						cLib.createDialogbox("Build Selection","Please change it manually");
					
					/*getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/following-sibling"
							+ "::td//button[@class='btn dropdown-toggle btn-default']")).click();*/
					}catch(Exception selectBtn){
						cLib.createDialogbox("Build Not Found", "Dropdown is not enable to click");
						cLib.select("//tr[td[a[text()='Cressex']]]/td/form/select[@name='build']", 
								data.split("-")[data.split("-").length-1], getDriver());
					}
						}else{
							cLib.createDialogbox("Build Not Found", "Please change it manually");
							cLib.clickOnOldBuild(oldBNo, getDriver());
						}
				
				
				//Click on Deploy button
				try{
					cLib.highlightElement(getDriver().findElement(By.xpath("//td[a[contains(text(),"
							+ "'Cressex')]]/following-sibling::td//button[contains(text(),'Deploy')]"
							)),getDriver());
					System.out.println("Highlighted");
					
					/*Actions deploy = new Actions(getDriver());
					deploy.click(getDriver().findElement(By.xpath("//tr[td[a[text()='Cressex']]]/td/form"
							+ "/button[text()='Deploy' and @class='btn']"))).perform();*/
					getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/following-"
							+ "sibling::td//button[contains(text(),'Deploy')]")).click();
					System.out.println("Cliclked on 'Deploy'");
					
					
				}catch(Exception deploymentButton){
					cLib.createDialogbox("DeployButton", "Deploy Button is not Clickable");
					deploymentButton.printStackTrace();
				}
				
			}else{
				System.out.println("Preview not displayed");
			}
			/*Confirm deployment application, environment and build*/
			try{
				if(cLib.WaitForPresenceOfElement("//h2[text()='Confirm Deployment']", getDriver(),
						40).isDisplayed()){
					cLib.highlightElement(getDriver().findElement(By.xpath("//h2[text()='Confirm "
							+ "Deployment']")), getDriver());
					
					
					cLib.createDialogbox("Confirm deployment ", "If Application, Environment and Build "
							+ "No. are correct then click OK in dialog box, \nElse click 'Cancel' on "
							+ "deployment App then click on 'Ok' in dialoge ");
					
				}
			}catch(Exception e){
				e.printStackTrace();
			}
			
			//Click on Continue button to deploy Preview on First server
			cLib.waitAndClickElement(getDriver(),getDriver().findElement(By.xpath("//button[text()="
				+ "'Continue']")),40);
			
			System.out.println("Continue button clicked");
			try{
				
				String status = getDriver().findElement(By.xpath("//div[strong[contains(text(),"
						+ "'Status')]]/following-sibling::div/span")).getText();
				System.out.println("Status-->"+status);
								
				do{
					String deploymentURL = getDriver().getCurrentUrl();
					System.out.println("Dep Url --> "+deploymentURL);
					
					/*Wait till working button available*/
					if(cLib.WaitForPresenceOfElement("//div[@id='deployment-actions']/a[contains(text(),"
							+ "'Working')]", getDriver(),5400).isDisplayed()){
						
						System.out.println("Working button available");
						
						cLib.createDialogbox("Health Check", "Health Check for OK : Report in deployment channel or developer"
								+ " for health check failure");
						
					/*	Open a new window and open Account Lookup
						cLib.openNewTabJSExecuter(getDriver());
						cLib.switchToNewTabByAryLst(getDriver());
						
						Runtime.getRuntime().exec("C:\\AutoIT\\AutoItScript\\Test.exe");
						Thread.sleep(1000);
						System.out.println("Opening Acc Lookup to log into Highways");
						getDriver().navigate().to("http://intranet/AccountLookUp/AccountLookUp.aspx");
						
						
						Search with ha.cms in Customer's User name field and click on Control Centre 
						getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
						getDriver().findElement(By.xpath("//input[@id='element71167']")).sendKeys("ha.cms");
						getDriver().findElement(By.xpath("//span[@id='div71174']/li/span/input")).click();
						cLib.waitAndClickElement(getDriver(),getDriver().findElement(By.xpath("//a[contains"
								+ "(text(),'Control centre')]")), 10);*/
						
						getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
						
						
						/*Open test link1 for highways */
						/*try{
							cLib.openUrlInNewTab(getDriver(), "http://preview1.uk-plc.net/highways");
							
							//Click on SHARE
							String text = getDriver().findElement(By.xpath("//div[@id='BoxInform']/ul/li/a"))
									.getText();
							cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//div"
									+ "[@id='BoxInform']/ul/li/a")), 40);
							System.out.println("text--> "+text);
							if(cLib.WaitForPresenceOfElement("//div[@id='PageTitle']/h1", getDriver(), 
									40).getText().equals(text)){
								System.out.println("No blocker SO test link "+getDriver().getCurrentUrl()
										+"-->Pass");
							}else{
								cLib.createDialogbox("Error in Link Test1", "Getting Error while testing "+
										getDriver().getTitle()+"page");
							}
						}catch(Exception link1){
							System.out.println("Error");
							cLib.createDialogbox("Test Link Error for Highways", getDriver().getTitle());
						}
						
						try{
							Open test link2 for highways
							getDriver().navigate().to("http://preview1.uk-plc.net/highways/functions.html");
							System.out.println(getDriver().getTitle()+" loaded");
							Click on General Counsel link
							cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//h5"
									+ "[contains(text(),'General Counsel')]")), 40);
							System.out.println("General Counsel clicked");
							cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//div"
									+ "[@id='ProcessTitle']/a[contains(text(),'General Counsel')]")), 40);
							System.out.println("Process ID clicked");
							
							if(!cLib.WaitForPresenceOfElement("//div[@class='ProcessContainer']//h1", 
									getDriver(),40).getText().isEmpty()){
								System.out.println("You are in "+getDriver().findElement(By.xpath("//div"
										+ "[@class='ProcessContainer']/h1")).getText()+"page");
								System.out.println("No blocker SO test link "+getDriver().getCurrentUrl()+
										"-->Pass");
							}else{
								cLib.createDialogbox("Error in Link Test1", "Getting Error while testing"+
										getDriver().getTitle()+"page");
							}
						}catch(Exception link2){
							System.out.println("Error");
							link2.printStackTrace();
							cLib.createDialogbox("Test Link Error for Highways", getDriver().getTitle());
						}*/
						
						/*try{
							Open test link3 for highways
						getDriver().navigate().to("http://preview1.uk-plc.net/highways/self-service.html");
							
							cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//div"
									+ "[@id='PageBody']//a[contains(text(),'Book a meeting room')]")), 40);
							String text = getDriver().findElement(By.xpath("//div[@id='PageBody']//a["
									+ "contains(text(),'Book a meeting room')]")).getText();
							System.out.println("Text-->"+text);
							if(!getDriver().getTitle().contains("500")&& cLib.WaitForPresenceOfElement
								("//div[@id='Procedure']//h1", getDriver(), 40).getText().equals(text)){
								System.out.println("You are in "+cLib.WaitForPresenceOfElement
										("///div[@id='Procedure']//h1", getDriver(), 40).getText()+" page");
								System.out.println("No blocker SO test link "+getDriver().getCurrentUrl()
										+ "-->Pass");
							}else{
								cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
							getDriver().
										getTitle()+"page");
							}
						}catch(Exception highwayL3){
							System.out.println("Error on Highway Link 3");
							highwayL3.printStackTrace();
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
							getDriver().getTitle()+"page");
						}*/
						
						
					/*	try{
							Open test link4 for highways
							getDriver().navigate().to("http://preview1.uk-plc.net/highways/people-network."
									+ "html");
							Submit a post and delete the post
							cLib.WaitForPresenceOfElement("//input[@id='postTitle']", getDriver(), 40)
								.sendKeys("Testing Post");
							cLib.WaitForPresenceOfElement("//textarea[@id='postText']", getDriver(), 40)
								.sendKeys("Testing in Server1");
							cLib.WaitForPresenceOfElement("//input[@id='WallPostFormSubmit']", getDriver(), 
									40)
										.click();
							getDriver().manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
							cLib.WaitForPresenceOfElement("//div[div[contains(text(),'Testing Post')]]/"
									+ "span/div/a[contains(text(),'Delete')]", getDriver(), 40).click();
							System.out.println("Post Deleted");
							
						}catch(Exception highwayL4){
							System.out.println("Error on Highway Link 4");
							highwayL4.printStackTrace();
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "
							+getDriver().getTitle()+"page");
				}*/
		
						/*try{
							Open test link5 for highways
							getDriver().navigate().to("http://preview1.uk-plc.net/highways/news/black-"
									+ "history-month--my-african-perspective--by-esosa-ikolo.html");
							
							cLib.WaitForPresenceOfElement("//div[@id='PageTitle']/h1[contains(text(),"
									+ "'Black History Month:')]", getDriver(), 40);
								
							String cmt = cLib.WaitForPresenceOfElement("//a[contains(text(),'Comments')]", 
									getDriver(), 40).getText();
							String cmtNo = cmt.split(" ")[cmt.split(" ").length-1].replace("(","")
									.replace(")", "");
							
							List<WebElement> cmtList = getDriver().findElements(By.xpath("//div[@id='"
									+ "column0']//div[@class='blogPostComment']"));
							if(Integer.valueOf(cmtNo)==cmtList.size()){
								System.out.println("Comment( "+cmtNo+" ) == "+cmtList.size() );
								System.out.println("Page is loaded properly So Pass the link");
							}
							
						}catch(Exception highwayL5){
							System.out.println("Error on Highway Link 4");
							highwayL5.printStackTrace();
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "
							+getDriver().getTitle()+"page");
						}
						
						try{
							Open test link6 for highways
							getDriver().navigate().to("http://preview1.uk-plc.net/highways/procedure/"
									+ "commercial-services-process-maps.html");
							
							if(cLib.WaitForPresenceOfElement("//div[@id='Procedure']//h1[contains(text(),"
								+ "'Commercial Services Process Maps')]", getDriver(), 40).isDisplayed()){
								
								System.out.println("Page is loaded properly So Pass the link6");
							}else{
								System.out.println("Error in Link6");
							}
														
						}catch(Exception highwayL6){
							System.out.println("Error on Highway Link 6");
							highwayL6.printStackTrace();
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
							getDriver().getTitle()+"page");
						}
						
						try{
							Open test link7 for highways
							getDriver().navigate().to("http://preview1.uk-plc.net/highways/inform/"
									+ "staff-handbook/chapter2-4-parta.html");
							
							if(cLib.WaitForPresenceOfElement("//div[@id='PageTitle']/h1[contains(text(),"
									+ "'Chapter 2.4 - Leave')]", getDriver(), 40).isDisplayed()){
								
								System.out.println("Page is loaded properly So Pass the link7");
							}else{
								System.out.println("Error in Link7");
							}
														
						}catch(Exception highwayL7){
							System.out.println("Error on Highway Link 7");
							highwayL7.printStackTrace();
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
							getDriver().getTitle()+"page");
						}
						
						try{
							Open test link8 for highways
							getDriver().navigate().to("http://preview1.uk-plc.net/highways/edit-use"
									+ "r-profile.html");
							
							if(cLib.WaitForPresenceOfElement("//form[@id='Form8994']/h3[contains(text(),"
									+ "'Update Profile')]", getDriver(), 40).isDisplayed()){
								
								System.out.println("Page is loaded properly So Pass the link8");
							}else{
								System.out.println("Error in Link8");
							}
														
						}catch(Exception highwayL8){
							System.out.println("Error on Highway Link 8");
							highwayL8.printStackTrace();
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
							getDriver().getTitle()+"page");
						}
						*/
						
						try{
							//Open Account LookUp to login Control Centre for Abd
							/*Runtime.getRuntime().exec("C:\\AutoIT\\AutoItScript\\Test.exe");
							Thread.sleep(1000);*/
							/*Open a new window and open Account Lookup*/
							cLib.openNewTabJSExecuter(getDriver());
							cLib.switchToNewTabByAryLst(getDriver());
							
							/*Runtime.getRuntime().exec("C:\\AutoIT\\AutoItScript\\Test.exe");
							Thread.sleep(1000);*/
							System.out.println("Opening Acc Lookup to log into Abd");
							getDriver().navigate().to("http://intranet/AccountLookUp/AccountLookUp.aspx");
							//Search with Abd.administrator and click on ControlCentre
							getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
							getDriver().findElement(By.xpath("//input[@id='element71167']")).sendKeys
								("Abd.administrator");
							getDriver().findElement(By.xpath("//span[@id='div71174']/li/span/input")).click();
							cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//"
									+ "a[contains(text(),'Control centre')]")), 10);
							getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
						}catch(Exception abdCCLogin){
							abdCCLogin.printStackTrace();
							System.out.println("Error while Logging into CC for ABD");
							cLib.createDialogbox("Account Lookup Error", "Getting Error while testing "
							+getDriver().getTitle()+"page");
						}
						
						Thread.sleep(2000);
						try{
							//Open testlink1 for Abd
							cLib.openUrlInNewTab(getDriver(), "http://preview1.uk-plc.net/abd");
							if(!getDriver().getTitle().contains("500")){
								getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
								//Mouse hover on products
									try{
										cLib.highlightElement(cLib.WaitForPresenceOfElement("//button[contains(text(),'closes window')]", getDriver(), 40), getDriver());
										cLib.WaitForPresenceOfElement("//button[contains(text(),'closes window')]", getDriver(), 40).click();
									}catch(Exception popUp){
										System.out.println("PopUp not available");
										popUp.printStackTrace();
									}
								cLib.mousehoverToAnElement(getDriver(), getDriver().findElement(By.xpath("//nav//a[contains(text(),'Products')]")));
								System.out.println("Mousehover complete");
								//Click on a link
								//Test
								if(!getDriver().getTitle().contains("500")){
									
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//nav//a[contains(text(),'Products')]/../div//a[contains(text(),'Negative ')]", getDriver(), 30), getDriver());
									
									WebElement subMenu= cLib.WaitForPresenceOfElement("//nav//a[contains(text(),'Products')]/../div//a[contains(text(),'Negative ')]", getDriver(),40);
									
									JavascriptExecutor executor = (JavascriptExecutor) getDriver();
									executor.executeScript("arguments[0].click();", subMenu);
									if(!getDriver().getTitle().contains("500")){
										System.out.println("No 500 Error on testlink");
										}
								}else{
									System.out.println("500 Error on testlink");
									cLib.createDialogbox("Link Test Error", "Getting Error while "
											+ "testing :"+getDriver().getTitle()+"page, Please report it"
													+ " and Click on 'OK' to continue");
								}
							System.out.println("Test link1 for ABD Passed");
							}else{
								System.out.println("500 Error on testlink");
								cLib.createDialogbox("Link Test Error", "Getting Error while testing :"
								+getDriver().getTitle()+"page, Please report it and Click on 'OK' to"
										+ " continue");
							}
						}catch(Exception abdL1){
							abdL1.printStackTrace();
							System.out.println("Error on abd link1 test");
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "
							+	getDriver().getTitle()+"page");
						}
						
						Thread.sleep(2000);
						try{
							//Open testlink2 for Abd
							getDriver().navigate().to("http://preview1.uk-plc.net/abd/search.html?searchType=SPECIFICITY&searchTerm=STK39");
							if(!getDriver().getTitle().contains("500")){
								/*try{
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//button[contains(text(),'closes window')]", getDriver(), 40), getDriver());
									cLib.WaitForPresenceOfElement("//button[contains(text(),'closes window')]", getDriver(), 40).click();
								}catch(Exception popUp){
									System.out.println("PopUp not available");
									popUp.printStackTrace();
								}*/
								
								cLib.highlightElement(getDriver().findElement(By.xpath("//tbody//span[contains(text(),'VMA00281KT')]/ancestor::td/following-sibling::td//input[@value='Add']")), getDriver());
								System.out.println("Highlighted");
								WebElement addBtn= cLib.WaitForPresenceOfElement("//tbody//span[contains(text(),'VMA00281KT')]/ancestor::td/following-sibling::td//input[@value='Add']", getDriver(),40);
								
								JavascriptExecutor executor = (JavascriptExecutor) getDriver();
								executor.executeScript("arguments[0].click();", addBtn);
								
								Thread.sleep(4000);
								
								if(!getDriver().getTitle().contains("500")){
								cLib.highlightElement(getDriver().findElement(By.xpath("//div[@id='Embedded"
										+ "Basket']//a[contains(text(),'item')]")), getDriver());
								cLib.WaitForPresenceOfElement("//div[@id='EmbeddedBasket']//a[contains(text(),"
										+ "'item')]", getDriver(), 40).click();
								if(!getDriver().getTitle().contains("500")){
									System.out.println("Test link "+getDriver().getCurrentUrl()+" Passed");
								}else{
									System.out.println("500 Error on testlink");
									cLib.createDialogbox("Link Test Error", "Getting Error while testing :"
									+getDriver().getTitle()+"page, Please report it and Click on 'OK' to"
											+ " continue");
									}
								}else{
									System.out.println("500 Error on testlink");
									cLib.createDialogbox("Link Test Error", "Getting Error while testing :"
									+getDriver().getTitle()+"page, Please report it and Click on 'OK' to"
											+ " continue");
								}
								
								
							}else{
								System.out.println("500 Error on testlink");
								cLib.createDialogbox("Link Test Error", "Getting Error while testing :"
								+getDriver().getTitle()+"page, Please report it and Click on 'OK' to"
										+ " continue");
							}
						}catch(Exception abdL2){
							abdL2.printStackTrace();
							System.out.println("Error on abd link2 test");
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
							getDriver().getTitle()+"page");
						}
						
						Thread.sleep(2000);
						try{
							//Open testlink3 for Abd
							getDriver().navigate().to("http://preview1.uk-plc.net/abd/site-search.html?"+
							"SearchString=sheep​​​");
							if(!getDriver().getTitle().contains("500")){
								cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath
							("//div[@id='SearchResults']//a[contains(text(),'Anti-Sheep Antibodies')]")), 40);
								if(getDriver().getTitle().contains("500")){
									System.out.println("500 Error on testlink");
								}
								System.out.println("Test link 3 '"+getDriver().getCurrentUrl()+"' Passed");
							}
						}catch(Exception abdL3){
							abdL3.printStackTrace();
							System.out.println("Error on abd link3 test");
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
							getDriver().getTitle()+"page");
						}
						
						Thread.sleep(2000);
						try{
							//Open testlink4 for Abd
							getDriver().navigate().to("http://preview1.uk-plc.net/abd/search.html?searchType="
									+ "BASIC&searchTerm=CD4&Filter1Name=SpecCI&Filter1Value=CD4&Filter2Name="
									+ "targetOrCross&Filter2Value=Mouse&filterCount=2​​");
							if(!getDriver().getTitle().contains("500")){
								/*try{
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//button[contains(text(),'closes window')]", getDriver(), 40), getDriver());
									cLib.WaitForPresenceOfElement("//button[contains(text(),'closes window')]", getDriver(), 40).click();
								}catch(Exception popUp){
									System.out.println("PopUp not available");
									popUp.printStackTrace();
								}*/
								getDriver().manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
								
								try{
								if(getDriver().findElement(By.xpath("//div[@id='countries']"))
										.isDisplayed()){
									cLib.WaitForPresenceOfElement("//div[@id='countries']//div[@value='GB' and "
											+ "contains (text(),'United Kingdom')]",getDriver(), 30).click();
								}
								if(cLib.WaitForPresenceOfElement("//span[contains(text(),'IMPORTANT ORDERING')]/"
										+ "following-sibling::button", getDriver(), 40).isDisplayed()){
									cLib.WaitForPresenceOfElement("//span[contains(text(),'IMPORTANT ORDERING'"
											+ ")]/following-sibling::button", getDriver(), 40).click();
								}else{
									System.out.println("No Pup up>>>>>>>>>>>");
								}
								}catch(Exception expPopUp){
									expPopUp.printStackTrace();
								}
								//Thread.sleep(2000);
								
								Thread.sleep(6000);
								cLib.highlightElement(getDriver().findElement(By.xpath("//tbody//span[contains(text(),'55PE')]/ancestor::td/following-sibling::td//input[@value='Add']")), getDriver());
								System.out.println("Highlighted");
								WebElement addBtn= cLib.WaitForPresenceOfElement("//tbody//span[contains(text(),'55PE')]/ancestor::td/following-sibling::td//input[@value='Add']", getDriver(),40);
								
								JavascriptExecutor executor = (JavascriptExecutor) getDriver();
								executor.executeScript("arguments[0].click();", addBtn);
								
								Thread.sleep(30000);
								
								
								cLib.highlightElement(getDriver().findElement(By.xpath("//div[@id='Embedded"
										+ "Basket']//a[contains(text(),'item')]")), getDriver());
								cLib.WaitForPresenceOfElement("//div[@id='EmbeddedBasket']//a[contains(text(),"
										+ "'item')]", getDriver(), 40).click();
								
								Thread.sleep(2000);
								/*
								if(cLib.WaitForPresenceOfElement("//span[contains(text(),'IMPORTANT ORDERING')]/"
										+ "following-sibling::button", getDriver(), 40).isDisplayed()){
									cLib.WaitForPresenceOfElement("//span[contains(text(),'IMPORTANT ORDERING')]/"
											+ "following-sibling::button", getDriver(), 40).click();
								}else{
									System.out.println("No Pup up>>>>>>>>>>>");
								}*/
								
								cLib.highlightElement(cLib.WaitForPresenceOfElement("//tr[@class='basketProductRow']"
									+ "//input[@class='quantity autoUpdateQuantity']", getDriver(), 40), getDriver());
								cLib.WaitForPresenceOfElement("//tr[@class='basketProductRow']"
									+ "//input[@class='quantity autoUpdateQuantity']", getDriver(), 40).sendKeys("2");
								
								cLib.highlightElement(cLib.WaitForPresenceOfElement("//tr[@class='basketProductRow']"
										+ "//input[@class='updateQuantity']", getDriver(), 40), getDriver());
								cLib.WaitForPresenceOfElement("//tr[@class='basketProductRow']"
										+ "//input[@class='updateQuantity']", getDriver(), 40).click();
								
								/*if(cLib.WaitForPresenceOfElement("//span[contains(text(),'IMPORTANT ORDERING')]/"
										+ "following-sibling::button", getDriver(), 40).isDisplayed()){
									cLib.WaitForPresenceOfElement("//span[contains(text(),'IMPORTANT ORDERING')]/"
											+ "following-sibling::button", getDriver(), 40).click();
								}else{
									System.out.println("No Pup up>>>>>>>>>>>");
								}
								Thread.sleep(500);*/
									cLib.highlightElement(getDriver().findElement(By.xpath("//form[@id='basketForm']/div"
											+ "[@class='basketOptions']//a")), getDriver());
									cLib.WaitForPresenceOfElement("//form[@id='basketForm']/div[@class='basketOptions']"
											+ "//a", getDriver(), 40).click();
									Thread.sleep(3000);
									
									/*if(cLib.WaitForPresenceOfElement("//span[contains(text(),'IMPORTANT ORDERING')]/"
											+ "following-sibling::button", getDriver(), 40).isDisplayed()){
										cLib.WaitForPresenceOfElement("//span[contains(text(),'IMPORTANT ORDERING')]/"
												+ "following-sibling::button", getDriver(), 40).click();
									}else{
										System.out.println("No Pup up>>>>>>>>>>>");
									}*/
									
								if(cLib.WaitForPresenceOfElement("//form[@id='basketForm']/div[contains"
										+ "(text(),'Your basket is currently empty')]", getDriver(), 
										40).isDisplayed()){
									System.out.println("There is no items in your cart");
									cLib.highlightElement(getDriver().findElement(By.xpath("//form[@id="
											+ "'basketForm']/div[contains(text(),'Your basket is currently"
											+ " empty')]")), getDriver());
									cLib.createDialogbox("Empty Cart", "There is no items in your cart :");
								}else{
									cLib.createDialogbox("EmptyCart Error", "Unable to Empty your Basket");
								}
								}else{
									cLib.createDialogbox("Link Test Error", "Getting 500 Error while testing "
											+getDriver().getTitle()+"page, Please report it to developer");
								}
						}catch(Exception abdL4){
							abdL4.printStackTrace();
							System.out.println("Error on abd link4 test");
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "
							+getDriver().getTitle()+"page");
						}
						
						//Commenting script for this link as 404 error appears for this link
						/*try{
							//Open testlink5 for Abd
							getDriver().navigate().to("http://preview1.uk-plc.net/abd/human-cd127-"
									+ "antibody-11590-hca144.html");
							if(!getDriver().getTitle().contains("500")){
								cLib.WaitForPresenceOfElement("//div[contains(text(),'UniProt')]/"
										+ "following-sibling::div/div[@class='ExtLinkSearch']/a",
										getDriver(), 40).click();
								if(getDriver().getTitle().contains("500")){
									System.out.println("500 Error in test link");
									}
								}

						}catch(Exception abdL5){
							abdL5.printStackTrace();
							System.out.println("Error on abd link5 test");
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
							getDriver().getTitle()+"page");
						}*/
						
						Thread.sleep(2000);
						try{
							//Open testlink6 for Abd
							System.out.println("Navigating to test Link 6");
							String windowId=getDriver().getWindowHandle();
							getDriver().switchTo().window(windowId);
							getDriver().navigate().to("http://Preview1.uk-plc.net/abd/drug-discovery.html");
							Thread.sleep(1000);
							System.out.println("Navigated to test Link 6");
							if(!getDriver().getTitle().contains("500")){
								cLib.WaitForPresenceOfElement("//div[@id='PageBody']//a[contains(text(),'More"
										+ " about anti-idiotypic')]",getDriver(), 40).click();
								Thread.sleep(1000);
								if(getDriver().getTitle().contains("500")){
									System.out.println("500 Error in test link");
									cLib.createDialogbox("Link Test Error", "Getting Error while "
											+ "testing "+getDriver().getTitle()+"page");
									}else {
										System.out.println("No blockage...This test link passed");
											}
								}else{
									cLib.createDialogbox("Link Test Error", "Getting Error while "
											+ "testing "+getDriver().getTitle()+"page");
								}
						}catch(Exception abdL6){
							abdL6.printStackTrace();
							System.out.println("Error on abd link6 test");
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
							getDriver().getTitle()+"page");
						}
						
						Thread.sleep(2000);
						try{
							//Open testlink7 for Abd
							System.out.println("Navigating to test Link 7 for ABD");
							getDriver().navigate().to("http://preview1.uk-plc.net/abd/anti-remicade-"
									+ "antibodies.html");
							System.out.println("Navigated to test Link 7 for ABD");
							if(!getDriver().getTitle().contains("500")){
								cLib.WaitForPresenceOfElement("//div[@id='LefthandMenu']//li[7]/a",
								getDriver(),40).click();
								if(getDriver().getTitle().contains("500")){
									System.out.println("500 Error in test link");
									}else {
										System.out.println("No blockage...This test link passed and all"
												+ " abd links got passed");
									}
							}else{
								cLib.createDialogbox("Link Test Error", "Getting Error while testing"+
								getDriver().getTitle()+"page");
							}
							
						}catch(Exception abdL7){
							abdL7.printStackTrace();
							System.out.println("Error on abd link7 test");
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
							getDriver().getTitle()+" : page");
						}
						
						Thread.sleep(2000);
						try{
							//Open testlink8 for Abd
							getDriver().navigate().to("http://preview1.uk-plc.net/abd/clinical-diagnostic-antigens-and-antibodies.html");
							if(!getDriver().getTitle().contains("500")){
								/*try{
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//button[contains(text(),'closes window')]", getDriver(), 40), getDriver());
									cLib.WaitForPresenceOfElement("//button[contains(text(),'closes window')]", getDriver(), 40).click();
								}catch(Exception popUp){
									System.out.println("PopUp not available");
									popUp.printStackTrace();
								}*/
								getDriver().manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
								
								
								cLib.highlightElement(getDriver().findElement(By.xpath("//a[contains(text(),'in just 8 weeks ')]")), getDriver());
								cLib.WaitForPresenceOfElement("//a[contains(text(),'in just 8 weeks ')]", getDriver(),40).click();
								
								
								getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
								
								
								if(!getDriver().getTitle().contains("500")){
									System.out.println("Test link8 for ABD Pass");
								}else {
									cLib.createDialogbox("Link Test Error", "Getting Error while "
											+ "testing "+getDriver().getTitle()+"page");
								}
								
								
							}else{
								cLib.createDialogbox("Link Test Error", "Getting 500 Error while testing "
										+getDriver().getTitle()+"page, Please report it to developer");
							}
						}catch(Exception abdL8){
							abdL8.printStackTrace();
							System.out.println("Error on abd link1 test");
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "
							+	getDriver().getTitle()+"page");
						}
						
												
						Thread.sleep(2000);
						try{
							//Open Account LookUp to login Control Centre for SPS
							/*Runtime.getRuntime().exec("C:\\AutoIT\\AutoItScript\\Test.exe");
							Thread.sleep(1000);*/
							getDriver().navigate().to("http://intranet/AccountLookUp/AccountLookUp.aspx");
							//Search with Abd.administrator and click on ControlCentre
							getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
							getDriver().findElement(By.xpath("//input[@id='element71171']")).sendKeys
								("1179885");
							getDriver().findElement(By.xpath("//span[@id='div71174']/li/span/input")).click();
							cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//"
									+ "a[contains(text(),'Control centre')]")), 10);
							getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
						}catch(Exception abdCCLogin){
							abdCCLogin.printStackTrace();
							System.out.println("Error while Logging into CC for ABD");
							cLib.createDialogbox("Account Lookup Error", "Getting Error while testing "
							+getDriver().getTitle()+"page");
						}
						
						try{
							//Open testlink1 for SPS
							getDriver().navigate().to("http://Preview1.uk-plc.net/sps-consultancy");
							if(!getDriver().getTitle().contains("500")){
							getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
							
							//Click on a link
							if(!getDriver().getTitle().contains("500")){
								cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='NavigationBar']"
										+ "//a[contains(text(),'About SPS')]", getDriver(), 30), getDriver());
								cLib.WaitForPresenceOfElement("//div[@id='NavigationBar']//a[contains(text(),"
									+ "'About SPS')]", getDriver(), 30).click();
							
								if(!getDriver().getTitle().contains("500")){
									System.out.println("No 500 Error on testlink");
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='Content']"
											+ "//a[contains(text(),"
											+ "'Knowledge Store')]", getDriver(), 30), getDriver());
									cLib.WaitForPresenceOfElement("//div[@id='Content']//a[contains(text(),"
											+ "'Knowledge Store')]", getDriver(), 30).click();
									
									if(!getDriver().getTitle().contains("500")){
										cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id="
												+ "'NavigationBar']//a[contains(text(),'Contact Us')]", 
												getDriver(), 30), getDriver());
										cLib.WaitForPresenceOfElement("//div[@id='NavigationBar']//a[contains"
												+ "(text(),'Contact Us')]", getDriver(), 30).click();
									}else{
										System.out.println(" 500 Error on testlink");
										cLib.createDialogbox("Link Test Error", "Getting Error while "
												+ "testing :"+getDriver().getTitle()+"page, Please report it"
														+ " and Click on 'OK' to continue");
										}
									}
								}else{
									System.out.println(" 500 Error on testlink");
									cLib.createDialogbox("Link Test Error", "Getting Error while "
											+ "testing :"+getDriver().getTitle()+"page, Please report it"
													+ " and Click on 'OK' to continue");
								}
							
							}
							
						}catch(Exception spsLinkErr){
							System.out.println("Error on SPS test Link ");
							spsLinkErr.printStackTrace();
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
							getDriver().getTitle()+"page");
						}
						
						/*open Account Lookup*/
						try{
							//Open Account LookUp to login Purchasing for PHB
							System.out.println("Opening Acc Lookup to log into CC for Company Admin test links");
							getDriver().navigate().to("http://@intranet/AccountLookUp/AccountLookUp.aspx");
							//Search with katy.atherton.phb.admin and click on Purchasing
							getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
							getDriver().findElement(By.xpath("//input[@id='element71167']")).sendKeys
								("katy.atherton.phb.admin");
							getDriver().findElement(By.xpath("//span[@id='div71174']/li/span/input")).click();
							cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//"
									+ "a[contains(text(),'Purchasing')]")), 10);
							getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
								
							}catch(Exception accntLookupLogin){
								accntLookupLogin.printStackTrace();
								System.out.println("Error while Logging into  Purchasing");
								cLib.createDialogbox("Account Lookup Error", "Getting Error while testing "
										+getDriver().getTitle()+"page");
							}
						
						try{
							//Open phb testlink for Preview
							getDriver().navigate().to("http://preview1.uk-plc.net/phb-marketplace/products.html");
							Thread.sleep(2000);
							getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
							try {
								if(getDriver().findElement(By.xpath("//div[@id='CookiePolicyPopup']"))
										.isDisplayed())
								{
									cLib.WaitForPresenceOfElement("//button[contains(text(),'Accept')]",getDriver(), 30).click();
								}
							}catch(Exception cookiePopUp) {
								System.out.println("Country selection pop up doesn't appear");
								cookiePopUp.printStackTrace();
							}
							
							if(!getDriver().getTitle().contains("500")){
								cLib.highlightElement(cLib.WaitForPresenceOfElement("//p[contains(text(),'Sort by')]", getDriver(), 30), getDriver());
								//Mouse hover 
								cLib.mousehoverToAnElement(getDriver(), cLib.WaitForPresenceOfElement("//p[contains(text(),'Sort by')]", getDriver(), 30));
								
								cLib.highlightElement(cLib.WaitForPresenceOfElement("//a[contains(text(),'Name (A-Z)')]", getDriver(), 30), getDriver());
								cLib.WaitForPresenceOfElement("//a[contains(text(),'Name (A-Z)')]", getDriver(), 30).click();

								Thread.sleep(1000);
								
								List<WebElement> supplierList = getDriver().findElements(By.xpath("//div[@id='collapse2']//a"));
								cLib.highlightElement(supplierList.get(0),getDriver());
								supplierList.get(0).click();
								
								Thread.sleep(1000);
								
								cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='query']", getDriver(), 30), getDriver());
								cLib.WaitForPresenceOfElement("//input[@id='query']", getDriver(), 30).sendKeys("Test");
								
								cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='searchElementRow']/input[@id='search']", getDriver(), 30), getDriver());
								cLib.WaitForPresenceOfElement("//div[@id='searchElementRow']/input[@id='search']", getDriver(), 30).click();
								if(!getDriver().getTitle().contains("500")){
									
									List<WebElement> srcRelt = getDriver().findElements(By.xpath("//div[@class='result-container']//h3/a"));
									cLib.highlightElement(srcRelt.get(0),getDriver());
									srcRelt.get(0).click();
									
									}else{
										System.out.println("NO Error on testlink");
										System.out.println("Test link1 for Sites Passed");
										cLib.createDialogbox("500 Error : ","Unable to search product");
									}
								}else{
									System.out.println("500 Error on testlink");
									cLib.createDialogbox("Link Test Error", "Getting Error while "
											+ "testing :"+getDriver().getTitle()+"page, Please report it"
													+ " and Click on 'OK' to continue");
								}
							
						}catch(Exception phbLError){
							phbLError.printStackTrace();
							System.out.println("Error on abd link1 test");
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "
							+	getDriver().getTitle()+"page");
						}
						
						/*Navigate to deployment application window*/
						/*getDriver().switchTo().window(cLib.navigateToParentWindow(getDriver()));*/
						cLib.openNewTabJSExecuter(getDriver());
						cLib.switchToNewTabByAryLst(getDriver());
						cLib.openURL(getDriver(), deploymentURL);
						
						cLib.createDialogbox("Deployment Confirmation: ", "All test links got tested and "
								+ "working as per expected \n Please complete ticket related testing if any"
								+ " and click on 'OK' 'Working' button");
						
						
					/*	cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//button
					 * [contains(text(),'Working')]")), 30);*/
						
						cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='deployment-actions']"
								+ "/a[contains(text(),'Working')]", getDriver(), 40), getDriver());
						cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//div[@id="
								+ "'deployment-actions']/a[contains(text(),'Working')]")), 30);
						
						if(cLib.WaitForPresenceOfElement("//div[@id='page']//strong[contains(text(),"
								+ "'Success')]",getDriver(), 5400).isDisplayed()){
							cLib.createDialogbox("Success Message","Preview Deployed on Cressex environment "
									+ "successfully with successful message : "+getDriver().findElement(By.
										xpath("//div[@id='page']//div[@class='alert alert-success']")).
									getText());
						}else{
							cLib.createDialogbox("Failure Message", "Preview is unable to Deploy on Cressex "
									+ "environment");
						}
							
							}else{
								if(getDriver().findElement(By.xpath("//strong[contains(text(),'Deployment "
										+ "failed')]")).isDisplayed()){
									
								}
							}
					
				}while(status.contains("Deploying to first server"));
				
				/*else{
						}
							cLib.createDialogbox("Deployment Error :",getDriver().findElement(By.xpath
									("//div[@class='alert alert-error']")).getText( ));
							getDriver().navigate().refresh();
						}*/
				

				}catch(Exception e){
					e.printStackTrace();
					if(getDriver().getTitle().equals("Server Error")){
						cLib.createDialogbox("Deployment Error : ","Unable to access deployment App "
						+"due to Server Error");
						System.out.println("Error");
						getDriver().get("https://deployment.ukplc.corp");
					}else if(getDriver().findElement(By.xpath("//strong[contains(text(),'Deployment"
							+ " failed')]")).isDisplayed()){
					System.out.println("Error --> "+getDriver().findElement(By.xpath("//strong[contains"
							+ "(text(),'Deployment failed')]")).getText());	
					cLib.createDialogbox("Deployment Error :",getDriver().findElement(By.xpath("//strong"
							+ "[contains(text(),'Deployment failed')]")).getText( ));
					}
					
				}
			
			
		}catch(Exception E){
			E.printStackTrace();
			if(getDriver().getTitle().equals("Server Error")){
				cLib.createDialogbox("Deployment Error : ","Unable to access deployment App" 
				+"due to Server Error");
				System.out.println("Error");
				getDriver().get("https://deployment.ukplc.corp");
			}
			/*else if(getDriver().findElement(By.xpath("//div[@class='alert alert-error']")).
			isDisplayed()){
			System.out.println("Error --> "+getDriver().findElement(By.xpath("//div[@class='alert "
					+ "alert-error']")).getText());	
			}*/
		}
		
	}
	
	@AfterClass
	public void configAfterClassMtd(){
		try {
			getDriver().close();
			getDriver().quit();
			vcLib.stopRecording();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
