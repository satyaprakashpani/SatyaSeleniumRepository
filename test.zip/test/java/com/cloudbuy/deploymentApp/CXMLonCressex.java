package com.cloudbuy.deploymentApp;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class CXMLonCressex extends DriverSetUpCressx{
	CommonLib cLib =new CommonLib();
	CaptureVideo vcLib=new CaptureVideo();
	/*This will open browser and deployment application  */
	@BeforeClass
	public void configBeforeClass() {
		//Start video recording
		try {
			vcLib.startRecording();
		} catch (Exception videoException) {
			videoException.printStackTrace();
			System.out.println("Problem in video recording");
		}
		try{
			setDriver("https://deployment2.ukplc.corp");
			getDriver().navigate().refresh();
			Thread.sleep(5000);
			System.out.println("Inside beforeClass--> "+getDriver().getTitle());
			cLib.WaitForPresenceOfElement("//input[@id='login']", getDriver(), 20);
			}catch(Exception e){
				e.printStackTrace();
				if(getDriver().getTitle().equals("Server Error")){
					System.out.println("Inside Catch if Server error");
					cLib.createDialogbox("Deployment Error : ","Unable to access deployment App "
					+"due to Server Error");
					getDriver().navigate().refresh();
				}else{
					cLib.createDialogbox("Deployment Error : ","Unable to access deployment App "
							+"due to deployment app Error");
				}
					
			}
		}
	
	/*Login to deployment application with valid credential */
	@BeforeMethod
	public void configMethod(){
		System.out.println("Inside before method");
		try{
			cLib.createDialogbox("Login Screen ","Please enter your credential and click on 'Submit'"
							+ " button before clicking on OK");
			//cLib.WebsitesToDepllomentApp(getDriver(), "satyaprakash.pani", "Kila@999!");
			/*if(getDriver().findElement(By.xpath("//a[contains(text(),'Applications')]")).getText().
					equals("")){
				System.out.println("Logged in to tha app");
			}*/
		}catch(Exception e){
				if(getDriver().getTitle().equals("Server Error")){
					cLib.createDialogbox("Login Error","Unable to Login");
					getDriver().close();
				}
		}
	}
	
	@Test
	public void DeployCXMLTest(){
		try{
			cLib.highlightElement(getDriver().findElement(By.xpath("//div[@id='page']")), getDriver());
			cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//a[contains"
					+ "(text(),'Applications')]")), 40);
			/*Thread.sleep(10000);*///application response is not same so need to wait long time to	
			//synchronize
			Thread.sleep(2000);
			cLib.highlightElement(getDriver().findElement(By.xpath("//a[contains(text(),"
					+ "'Applications')]")), getDriver());
			
			/*Click on CXML if Basket link is enabled*/
			WebElement cxmlLink = getDriver().findElement(By.xpath("//div[@id='page']//div[@class='list"
					+ "-group-item']//a[text()='cXml']"));
			
			if(cxmlLink.isEnabled()){
				System.out.println("CXML Link is enabled");
				Thread.sleep(10000);
				cLib.highlightElement(cxmlLink, getDriver());
				System.out.println("CXML loc: "+cxmlLink.getLocation());
				/*Actions act = new Actions(getDriver());
				act.click(Basket).perform();*/
				JavascriptExecutor executor = (JavascriptExecutor)getDriver();
				executor.executeScript("arguments[0].click()", cxmlLink);
				System.out.println("CXML Clicked");
				
				}
			
			if(cLib.WaitForPresenceOfElement("//div[@id='page']//h1", getDriver(), 30).isDisplayed()){
				cLib.highlightElement(getDriver().findElement(By.xpath("//div[@id='page']//h1")),
						getDriver());
				String oldBNo = getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/"
						+ "following-sibling::td[@class='text-right']")).getText();
				System.out.println("Old Build No : "+oldBNo);
				/*String data=getDriver().findElement(By.xpath("//tr[td[a[text()='Cressex']]]/td[contains"
						+ "(text(),'Basket-Build')]")).getText();*/
				/*System.out.println("Data-->"+data);
				System.out.println(data.split("-")[data.split("-").length-1]);*/
				
				/*Highlight and Click on build number drop-down*/
				cLib.highlightElement(getDriver().findElement(By.xpath("//td[a[contains(text(),"
						+ "'Cressex')]]/following-sibling::td//button[@class='btn dropdown-toggle "
						+ "btn-default']")), getDriver());
				getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/following-sibling"
						+ "::td//button[@class='btn dropdown-toggle btn-default']/span")).click();
				
				cLib.createDialogbox("Build no selection", "Please select build number to build");
				/*if(cLib.checkForOldBuild("//td[a[contains(text(),'Cressex')]]/following-sibling::td//"
						+ "span[@class='text']", getDriver(),Integer.valueOf(oldBNo))){
					System.out.println("Build number present");
					
					try{
						cLib.createDialogbox("Build Not Found", "Dropdown is not enable to click");
						cLib.clickOnOldBuild(oldBNo, getDriver());
					}catch(Exception selectBtn){
						cLib.createDialogbox("Build Not Found", "Dropdown is not enable to click");
						cLib.select("//tr[td[a[text()='Cressex']]]/td/form/select[@name='build']", 
								data.split("-")[data.split("-").length-1], getDriver());
					}
						}else{
							cLib.createDialogbox("Build Not Found", "Please change it manually");
							cLib.clickOnOldBuild(oldBNo, getDriver());
						}*/
				
			
				//Click on Deploy button
				try{
					cLib.highlightElement(getDriver().findElement(By.xpath("//td[a[contains(text(),"
							+ "'Cressex')]]/following-sibling::td//button[contains(text(),'Deploy')]"
							)),getDriver());
					System.out.println("Highlighted");
					
					/*Actions deploy = new Actions(getDriver());
					deploy.click(getDriver().findElement(By.xpath("//tr[td[a[text()='Cressex']]]/td/form"
							+ "/button[text()='Deploy' and @class='btn']"))).perform();*/
					getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/following-"
							+ "sibling::td//button[contains(text(),'Deploy')]")).click();
					System.out.println("Cliclked on 'Deploy'");
					
				}catch(Exception deploymentButton){
					cLib.createDialogbox("DeployButton", "Deploy Button is not Clickable");
					deploymentButton.printStackTrace();
				}
				
				/*Confirm deployment application, environment and build*/
				try{
					if(cLib.WaitForPresenceOfElement("//h2[text()='Confirm Deployment']", getDriver(),
							40).isDisplayed()){
						cLib.highlightElement(getDriver().findElement(By.xpath("//h2[text()='Confirm "
								+ "Deployment']")), getDriver());
						
						
						cLib.createDialogbox("Confirm deployment ", "If Application, Environment and Build "
								+ "No. are correct then click OK in dialog box, \nElse click 'Cancel' on "
								+ "deployment App then click on 'Ok' in dialoge ");
						
					}
				}catch(Exception e){
					e.printStackTrace();
					cLib.createDialogbox("Error :","Error in : "+getDriver().getCurrentUrl());
				}
				
				//Click on Continue button to deploy Basket on First server
				cLib.waitAndClickElement(getDriver(),getDriver().findElement(By.xpath("//button[text()="
					+ "'Continue']")),40);
				
				System.out.println("Continue button clicked");
				
				try{
					String status = getDriver().findElement(By.xpath("//div[strong[contains(text(),"
							+ "'Status')]]/following-sibling::div/span")).getText();
					System.out.println("Status-->"+status);
					do{
						String deploymentURL = getDriver().getCurrentUrl();
						System.out.println("Dep Url --> "+deploymentURL);
						
						if(cLib.WaitForPresenceOfElement("//div[@id='deployment-actions']/a[contains(text(),"
								+ "'Working')]", getDriver(),5400).isDisplayed()){
							cLib.createDialogbox("Health Check", "On failure, first click on 'Go' button if still failure persists Report in deployment channel or developer"
									+ " for health check failure, Then click on 'OK' button of dialogbox to continue");
			cLib.createDialogbox("Host File Check", "Check the host file manually for CXML and then click on 'OK' button of dialogbox to continue");
							
			try{
				
				/*Open a new window and open Account Lookup*/
				cLib.openNewTabJSExecuter(getDriver());
				cLib.switchToNewTabByAryLst(getDriver());
				
				//Open Account LookUp to open purchasing for CXML
				System.out.println("Opening Acc Lookup to login into controlcentre/purchasing");
				cLib.openURL(getDriver(), "http://@intranet/"
						+ "AccountLookUp/AccountLookUp.aspx");
				//Search with Abd.administrator and click on ControlCentre
				getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				getDriver().findElement(By.xpath("//input[@id='element71167']")).sendKeys
					("Katy.Atherton.Test");
				getDriver().findElement(By.xpath("//span[@id='div71174']/li/span/input")).click();
				cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//"
						+ "a[contains(text(),'Purchasing')]")), 10);
				getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					
				}catch(Exception accntLookup){
					accntLookup.printStackTrace();
					System.out.println("Error while Logging into Purchasing for CXML");
					cLib.createDialogbox("Account Lookup Error", "Getting Error while testing "
					+getDriver().getTitle()+"page");
				}
			try{
				//Open testlink for CXML test link
				System.out.println("Navigating to CXML test link1");
				getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
				
				if((!getDriver().getTitle().contains("500"))){
					
					try{
					cLib.highlightElement(cLib.WaitForPresenceOfElement("//button[@id='CloseMenuNotification']",getDriver(), 30), getDriver());
					cLib.WaitForPresenceOfElement("//button[@id='CloseMenuNotification']",getDriver(), 30).click();
					}catch (Exception closeBtn){
						closeBtn.printStackTrace();
					}
					
					cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[contains(text(),'Office Supplies')]",getDriver(), 30), getDriver());
					cLib.WaitForPresenceOfElement("//div[contains(text(),'Office Supplies')]",getDriver(), 30).click();
					
					
					
					
					getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
					
					try{
						if(!getDriver().getTitle().contains("500")){
							System.out.println("Navigated to : "+getDriver().getTitle());
							
							cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='Suppliers']//a[contains(text(),'Rs Components Open Punchout')]",getDriver(), 30), getDriver());
							cLib.WaitForPresenceOfElement("//div[@id='Suppliers']//a[contains(text(),'Rs Components Open Punchout')]",getDriver(), 30).click();
							if(!getDriver().getTitle().contains("500")){
								
								
								
								//getDriver().switchTo().frame(getDriver().findElement(By.tagName("iframe")).getAttribute("id"));
								
								//Test
								cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@type='image']",getDriver(), 30), getDriver());
								cLib.WaitForPresenceOfElement("//input[@type='image']",getDriver(), 30).click();
								
								Thread.sleep(30000);
								
								try{
									if(cLib.WaitForPresenceOfElement("//div[@id='fsrInvite']", getDriver(), 40).isDisplayed()){
										cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='fsrInvite']//button[contains(text(),'No, thanks')]", getDriver(), 40), getDriver());
										cLib.WaitForPresenceOfElement("//div[@id='fsrInvite']//button[contains(text(),'No, thanks')]", getDriver(), 40).click();
									}
								}catch(Exception popUp1){
									System.out.println("Popup not appeared");
									popUp1.printStackTrace();
								}
								
								cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='searchTerm']",getDriver(), 30), getDriver());
								cLib.WaitForPresenceOfElement("//input[@id='searchTerm']",getDriver(), 30).sendKeys("Test");;
								
								cLib.highlightElement(cLib.WaitForPresenceOfElement("//button[@id='btnSearch']",getDriver(), 30), getDriver());
								cLib.WaitForPresenceOfElement("//button[@id='btnSearch']",getDriver(), 30).click();
								
								//Handling invite PopUp
								try{
									if(cLib.WaitForPresenceOfElement("//div[@id='fsrInvite']", getDriver(), 40).isDisplayed()){
										cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='fsrInvite']//button[contains(text(),'No, thanks')]", getDriver(), 40), getDriver());
										cLib.WaitForPresenceOfElement("//div[@id='fsrInvite']//button[contains(text(),'No, thanks')]", getDriver(), 40).click();
									}
								}catch(Exception popUp1){
									System.out.println("Popup not appeared");
									popUp1.printStackTrace();
								}
								
								System.out.println("1");
								cLib.highlightElement(cLib.WaitForPresenceOfElement("//aside[@id='sidebar']//li[1]",getDriver(), 30), getDriver());
								cLib.WaitForPresenceOfElement("//aside[@id='sidebar']//li[1]",getDriver(), 30).click();
								System.out.println("2");
								cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@class='cartButton']",getDriver(), 30), getDriver());
								cLib.WaitForPresenceOfElement("//input[@class='cartButton']",getDriver(), 30).click();
								System.out.println("3");
								
								
								/*Handling invite PopUp*/
								try{
									if(cLib.WaitForPresenceOfElement("//div[@id='fsrInvite']", getDriver(), 40).isDisplayed()){
										cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='fsrInvite']//button[contains(text(),'No, thanks')]", getDriver(), 40), getDriver());
										cLib.WaitForPresenceOfElement("//div[@id='fsrInvite']//button[contains(text(),'No, thanks')]", getDriver(), 40).click();
									}
								}catch(Exception popUp1){
									System.out.println("Popup not appeared");
									popUp1.printStackTrace();
								}
								
								cLib.highlightElement(cLib.WaitForPresenceOfElement("//span[contains(text(),'View Basket')]",getDriver(), 30), getDriver());
								cLib.WaitForPresenceOfElement("//span[contains(text(),'View Basket')]",getDriver(), 30).click();
								
								/*try{
										cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='listbuttons']//span[contains(text(),'Empty Basket')]",getDriver(), 30), getDriver());
										cLib.WaitForPresenceOfElement("//div[@id='listbuttons']//span[contains(text(),'Empty Basket')]",getDriver(), 30).click();
									
								}catch(Exception popUp){
									System.out.println("Popup not appeared");
									popUp.printStackTrace();
								}*/
								int reqReqBtnCount =0;
								try{
									if(cLib.WaitForPresenceOfElement("//div[@id='shoppingBasketForm:TopCheckoutPunchoutNavigationWidgetActionNAVTOPDIVId']//span[@id='checkoutSecurelyAndPuchBtn']/..",getDriver(), 30).isEnabled()){
										reqReqBtnCount++;
										cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='shoppingBasketForm:TopCheckoutPunchoutNavigationWidgetActionNAVTOPDIVId']//span[@id='checkoutSecurelyAndPuchBtn']/..",getDriver(), 30), getDriver());
										cLib.WaitForPresenceOfElement("//div[@id='shoppingBasketForm:TopCheckoutPunchoutNavigationWidgetActionNAVTOPDIVId']//span[@id='checkoutSecurelyAndPuchBtn']/..",getDriver(), 30).click();
										}
									}catch(Exception reqReqBtn){
									System.out.println("Top ReqReqBtn not appeared");
									reqReqBtn.printStackTrace();
									try{
										if(cLib.WaitForPresenceOfElement("//div[@id='shoppingBasketForm:BottomCheckoutPunchoutNavigationWidgetActionNAVTOPDIVId']//span[@id='checkoutSecurelyAndPuchBtn']/..",getDriver(), 30).isEnabled()){
											System.out.println("Bottom ReqReqBtn appeared");
											reqReqBtnCount++;
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='shoppingBasketForm:BottomCheckoutPunchoutNavigationWidgetActionNAVTOPDIVId']//span[@id='checkoutSecurelyAndPuchBtn']/..",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//div[@id='shoppingBasketForm:BottomCheckoutPunchoutNavigationWidgetActionNAVTOPDIVId']//span[@id='checkoutSecurelyAndPuchBtn']/..",getDriver(), 30).click();
											}
										}catch(Exception bottomReqReqBtn){
											System.out.println("Bottom ReqReqBtn not appeared");
											reqReqBtn.printStackTrace();
										}
								}
								if(reqReqBtnCount>0){
									if(getDriver().getCurrentUrl().contains("uk-plc.net")){
										cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='listbuttons']//span[contains(text(),'Empty Basket')]",getDriver(), 30), getDriver());
										cLib.WaitForPresenceOfElement("//div[@id='listbuttons']//span[contains(text(),'Empty Basket')]",getDriver(), 30).click();
										System.out.println("All products from Basket are removed");
									}else{
										cLib.createDialogbox("CXML error", "CXML URL is not having 'uk-plc.net' "+getDriver().getCurrentUrl()
												+"' page");
									}
								}
									
							}else{
								cLib.createDialogbox("500 Error", "Getting 500 error for '"+getDriver().getCurrentUrl()
										+"' page");
								}
						}else{
						cLib.createDialogbox("500 Error", "Getting 500 error for '"+getDriver().getCurrentUrl()
								+"' page");
						}
						
					}catch(Exception e){
						e.printStackTrace();
						cLib.createDialogbox("Error", "Getting error for '"+getDriver().getCurrentUrl()
								+"' page");
					}
				}else{
					cLib.createDialogbox("500 Error", "Getting 500 error for '"+getDriver().getCurrentUrl()
							+"' page");
					}

			}catch(Exception BLinkError1){
				BLinkError1.printStackTrace();
				if(getDriver().getTitle().equals("Server Error")){
					cLib.createDialogbox("Deployment Error : ","Unable to access deployment App" 
					+"due to Server Error");
					System.out.println("Error");
					getDriver().get("https://deployment.ukplc.corp");
				}else if(getDriver().getTitle().equals("502 Bad Gateway")){
					cLib.createDialogbox("Deployment App Error : ","502 Bad Gateway");
							System.out.println("Error");
				}
			}
			
			/*Navigate to deployment application window*/
			/*getDriver().switchTo().window(cLib.navigateToParentWindow(getDriver()));*/
			cLib.openNewTabJSExecuter(getDriver());
			cLib.switchToNewTabByAryLst(getDriver());
			cLib.openURL(getDriver(), deploymentURL);
			cLib.createDialogbox("Deployment Confirmation: ", "All test links got tested and "
					+ "working as per expected \n Please complete ticket related testing if any"
					+ " and click on 'OK' 'Working' button");
			
			cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='deployment-actions']"
					+ "/a[contains(text(),'Working')]", getDriver(), 40), getDriver());
/*			cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//div[@id='page']"
					+ "//div[@id='deployment-actions']/a[contains(text(),'Working')]")), 40);*/
			
			cLib.clickElemntByMouseMovement(getDriver(), cLib.WaitForPresenceOfElement("//div[@id='page']"
					+ "//div[@id='deployment-actions']/a[contains(text(),'Working')]", getDriver(), 40));
			
			if(cLib.WaitForPresenceOfElement("//div[@id='page']//div[@class='alert alert-success']"
					+ "//strong",getDriver(), 1800).isDisplayed()){
				cLib.createDialogbox("Success Message","CXML Deployed on Cressex environment "
						+ "successfully with successful message : "+getDriver().findElement(By.
							xpath("//div[@id='page']//div[@class='alert alert-success']//strong")).
						getText());
			}else{
				cLib.createDialogbox("Failure Message", "CXML is unable to Deploy on Cressex "
						+ "environment");
			}
			
						}else{				//Else for 'Working' button availability 
							System.out.println("Working button is not available");
							cLib.createDialogbox("Working button Error", "Working button is not available, kindly check the "
									+ "deployment app for more info...");
						}
			
						}while(status.contains("Deploying to first server"));
					
					}catch(Exception e){
						e.printStackTrace();
						if(getDriver().findElement(By.xpath("//h1[contains(text(),'502 Bad Gateway')]")).isDisplayed()){
							cLib.createDialogbox("Bad Gateway Error", "502 Bad Gateway : Report to Infra or Dev team");
						}	}
			
			}else{
				cLib.createDialogbox("Navigation Error", "Unable to navigate CXML page ");
				}
			
		}catch(Exception cXMLErr){
			cXMLErr.printStackTrace();
			if(getDriver().getTitle().equals("Server Error")){
				cLib.createDialogbox("Deployment Error : ","Unable to access deployment App" 
				+"due to Server Error");
				System.out.println("Error");
				getDriver().get("https://deployment.ukplc.corp");
				}
			}
	}
	
	@AfterClass
	public void configAfterClassMtd(){
		try {
			getDriver().close();
			getDriver().quit();
			vcLib.stopRecording();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
