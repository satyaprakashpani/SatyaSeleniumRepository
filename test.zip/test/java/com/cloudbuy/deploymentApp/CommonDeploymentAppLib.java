package com.cloudbuy.deploymentApp;

public class CommonDeploymentAppLib {
	public void loginToDepApp(String uName, String password){
		//Test
	}
}
