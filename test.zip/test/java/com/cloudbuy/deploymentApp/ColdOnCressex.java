package com.cloudbuy.deploymentApp;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class ColdOnCressex extends DriverSetUpCressx{
	CommonLib cLib =new CommonLib();
	CaptureVideo vcLib=new CaptureVideo();
	/*This will open browser and deployment application  */
	@BeforeClass
	public void configBeforeClass() {
		//Start video recording
		try {
			vcLib.startRecording();
		} catch (Exception videoException) {
			videoException.printStackTrace();
			System.out.println("Problem in video recording");
		}
		try{
			setDriver("https://deployment2.ukplc.corp");
			System.out.println("Inside beforeClass--> "+getDriver().getTitle());
			cLib.WaitForPresenceOfElement("//input[@id='login']", getDriver(), 20);
			}catch(Exception e){
				e.printStackTrace();
				if(getDriver().getTitle().equals("Server Error")){
					System.out.println("Inside Catch if Server error");
					cLib.createDialogbox("Deployment Error : ","Unable to access deployment App "
					+"due to Server Error");
					getDriver().navigate().refresh();
				}else{
					cLib.createDialogbox("Deployment Error : ","Unable to access deployment App "
							+"due to deployment app Error");
				}
					
			}
		}
	
	/*Login to deployment application with valid credential */
	@BeforeMethod
	public void configMethod(){
		System.out.println("Inside before method");
		try{
			cLib.createDialogbox("Login Screen ","Please enter your credential and click on 'Submit'"
							+ " button before clicking on OK");
		}catch(Exception e){
				if(getDriver().getTitle().equals("Server Error")){
					cLib.createDialogbox("Login Error","Unable to Login");
					getDriver().close();
				}
		}
	}
	
	@Test
	public void DeployColdOnCressexTest(){
		try{
			cLib.highlightElement(getDriver().findElement(By.xpath("//div[@id='page']")), getDriver());
			cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//a[contains"
					+ "(text(),'Applications')]")), 40);
			
			//synchronize
			Thread.sleep(2000);
			cLib.highlightElement(getDriver().findElement(By.xpath("//a[contains(text(),"
					+ "'Applications')]")), getDriver());
			
			/*Click on Cold if Cold link is enabled*/
			WebElement coldLink = getDriver().findElement(By.xpath("//div[@id='page']//div[@class='list"
					+ "-group-item']//a[text()='Cold']"));
			
			if(coldLink.isEnabled()){
				System.out.println("Cold Link is enabled");
				Thread.sleep(10000);
				cLib.highlightElement(coldLink, getDriver());
				System.out.println("Cold loc: "+coldLink.getLocation());
				/*Actions act = new Actions(getDriver());
				act.click(Basket).perform();*/
				JavascriptExecutor executor = (JavascriptExecutor)getDriver();
				executor.executeScript("arguments[0].click()", coldLink);
				System.out.println("Cold Clicked");
			}
			
			if(cLib.WaitForPresenceOfElement("//div[@id='page']//h1", getDriver(), 30).isDisplayed()){
				cLib.highlightElement(getDriver().findElement(By.xpath("//div[@id='page']//h1")),
						getDriver());
				String oldBNo = getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/"
						+ "following-sibling::td[@class='text-right']")).getText();
				System.out.println("Old Build No : "+oldBNo);
				
				cLib.highlightElement(getDriver().findElement(By.xpath("//td[a[contains(text(),"
						+ "'Cressex')]]/following-sibling::td//button[@class='btn dropdown-toggle "
						+ "btn-default']")), getDriver());
				/*getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/following-sibling"
						+ "::td//button[@class='btn dropdown-toggle btn-default']/span")).click();*/
				
				cLib.createDialogbox("Build no selection", "Please select suitable build number to deploy");
				try{
					cLib.highlightElement(getDriver().findElement(By.xpath("//td[a[contains(text(),"
							+ "'Cressex')]]/following-sibling::td//button[contains(text(),'Deploy')]"
							)),getDriver());
					System.out.println("Highlighted");
					//Test
					
					/*Actions deploy = new Actions(getDriver());
					deploy.click(getDriver().findElement(By.xpath("//tr[td[a[text()='Cressex']]]/td/form"
							+ "/button[text()='Deploy' and @class='btn']"))).perform();*/
					getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/following-"
							+ "sibling::td//button[contains(text(),'Deploy')]")).click();
					System.out.println("Cliclked on 'Deploy'");
					
				}catch(Exception deploymentButton){
					cLib.createDialogbox("DeployButton", "Deploy Button is not Clickable");
					deploymentButton.printStackTrace();
				}
				
				/*Confirm deployment application, environment and build*/
				try{
					if(cLib.WaitForPresenceOfElement("//h2[text()='Confirm Deployment']", getDriver(),
							40).isDisplayed()){
						cLib.highlightElement(getDriver().findElement(By.xpath("//h2[text()='Confirm "
								+ "Deployment']")), getDriver());
						
						
						cLib.createDialogbox("Confirm deployment ", "If Application, Environment and Build "
								+ "No. are correct then click OK in dialog box, \nElse click 'Cancel' on "
								+ "deployment App then click on 'Ok' in dialoge ");
						
					}
				}catch(Exception e){
					e.printStackTrace();
					cLib.createDialogbox("Error :","Error in : "+getDriver().getCurrentUrl());
				}
				
				//Click on Continue button to deploy Basket on First server
				cLib.waitAndClickElement(getDriver(),getDriver().findElement(By.xpath("//button[text()="
					+ "'Continue']")),40);
				
				System.out.println("Continue button clicked");
				
				try{
					String status = getDriver().findElement(By.xpath("//div[strong[contains(text(),"
							+ "'Status')]]/following-sibling::div/span")).getText();
					System.out.println("Status-->"+status);
					do{
						String deploymentURL = getDriver().getCurrentUrl();
						System.out.println("Dep Url --> "+deploymentURL);
						
						if(cLib.WaitForPresenceOfElement("//div[@id='deployment-actions']/a[contains(text(),"
								+ "'Working')]", getDriver(),5400).isDisplayed()){
							cLib.createDialogbox("Health Check", "Health Check for OK : Report in deployment channel or developer"
									+ " for health check failure");
							try{
								//Open test link for Cold
								
								cLib.openNewTabJSExecuter(getDriver());
								cLib.switchToNewTabByAryLst(getDriver());
								
								System.out.println("Navigating to Cold test link1");
								cLib.openURL(getDriver(), "http://login1.uk-plc.net/register/cold/enterdetails.aspx");
								getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
								
								if((!getDriver().getTitle().contains("500"))){
									
									try{
										if(cLib.WaitForPresenceOfElement("//div[@id='PageTitle']/h1", getDriver(), 40).isDisplayed()){
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='PageTitle']/h1",getDriver(), 30), getDriver());
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//label[contains(text(),'First Name')]/following-sibling::input",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//label[contains(text(),'First Name')]/following-sibling::input",getDriver(), 30).sendKeys("AutomationFirstName");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//label[contains(text(),'Surname')]/following-sibling::input",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//label[contains(text(),'Surname')]/following-sibling::input",getDriver(), 30).sendKeys("AutomationSurname");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//label[contains(text(),'Contact email address')]/following-sibling::input",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//label[contains(text(),'Contact email address')]/following-sibling::input",getDriver(), 30).sendKeys("satyaprakash.pani@cloudbuy.com");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//label[contains(text(),'Business / organisation name')]/following-sibling::input",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//label[contains(text(),'Business / organisation name')]/following-sibling::input",getDriver(), 30).sendKeys("MoCompany");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Submit']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@value='Next']",getDriver(), 30).click();
										}else{
											System.out.println("Enter detail not appeared");
											cLib.createDialogbox("Enter details not appeared", "Enter Details tab not appeared, please report to developer "+getDriver().getCurrentUrl()
													+"' page");
										}
									}catch (Exception dtlEntryError){
										dtlEntryError.printStackTrace();
										cLib.createDialogbox("Enter details Error : ","Unable to enter details," 
												+"Please report to developer");
									}
									
									try{
										if(cLib.WaitForPresenceOfElement("//div[@id='PageTitle']/h1", getDriver(), 40).isDisplayed()){
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='PageTitle']/h1",getDriver(), 30), getDriver());
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//label[contains(text(),'Building number or name')]/following-sibling::input",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//label[contains(text(),'Building number or name')]/following-sibling::input",getDriver(), 30).sendKeys("HarnathTower");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//label[contains(text(),'Postcode')]/following-sibling::input",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//label[contains(text(),'Postcode')]/following-sibling::input",getDriver(), 30).sendKeys("001101");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@value='Next']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@value='Next']",getDriver(), 30).click();
											
											getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//label[contains(text(),'Address Line 1')]/following-sibling::input",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//label[contains(text(),'Address Line 1')]/following-sibling::input",getDriver(), 30).sendKeys("Jodhpur");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//label[contains(text(),'Country')]/following-sibling::select",getDriver(), 30), getDriver());
											cLib.select("//label[contains(text(),'Country')]/following-sibling::select", "IN", getDriver());
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//label[contains(text(),'Phone number')]/following-sibling::input",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//label[contains(text(),'Phone number')]/following-sibling::input",getDriver(), 30).sendKeys("9937412356");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@value='Next']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@value='Next']",getDriver(), 30).click();
											
										}else{
											System.out.println("Enter your business address not appeared");
											cLib.createDialogbox("Enter your business address not appeared", "Enter your business address tab not appeared, please report to developer "+getDriver().getCurrentUrl()
													+"' page");
										}
									}catch (Exception bsnsAdrsErr){
										bsnsAdrsErr.printStackTrace();
										cLib.createDialogbox("Business address Error : ","Unable to set business address," 
												+"Please report to developer");
									}
									
									
									getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
									String userName = "ColdAutoUser - "+Math.round(Math.random()*10000);
									try{
										if(cLib.WaitForPresenceOfElement("//div[@id='PageTitle']/h1", getDriver(), 40).isDisplayed()){
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='PageTitle']/h1",getDriver(), 30), getDriver());
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//label[contains(text(),'Your chosen username')]/following-sibling::input",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//label[contains(text(),'Your chosen username')]/following-sibling::input",getDriver(), 30).clear();
											cLib.WaitForPresenceOfElement("//label[contains(text(),'Your chosen username')]/following-sibling::input",getDriver(), 30).sendKeys(userName);
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//label[contains(text(),'Password')]/following-sibling::input",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//label[contains(text(),'Password')]/following-sibling::input",getDriver(), 30).sendKeys("Auto@1234!");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//label[contains(text(),'Repeat password')]/following-sibling::input",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//label[contains(text(),'Repeat password')]/following-sibling::input",getDriver(), 30).sendKeys("Auto@1234!");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//label[contains(text(),'Security question')]/following-sibling::select",getDriver(), 30), getDriver());
											cLib.select("//label[contains(text(),'Security question')]/following-sibling::select", "8", getDriver());
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//label[contains(text(),'Security question answer')]/following-sibling::input",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//label[contains(text(),'Security question answer')]/following-sibling::input",getDriver(), 30).sendKeys("AutoTestAns");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@value='Next']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@value='Next']",getDriver(), 30).click();
										}else{
											System.out.println("Choose password tab not appeared");
											cLib.createDialogbox("Choose password tab not appeared", "Choose password screen tab not appeared, please report to developer "+getDriver().getCurrentUrl()
													+"' page");
										}
									}catch (Exception chsPwdErr){
										chsPwdErr.printStackTrace();
										cLib.createDialogbox("Account SetUp Error : ","Unable to setup account," 
												+"Please report to developer");
									}
									
									try{
										if(!getDriver().getTitle().contains("500")){
											if(cLib.WaitForPresenceOfElement("//div[@id='PageTitle']/h1", getDriver(), 40).isDisplayed()){
												
												cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='PageTitle']/h1",getDriver(), 30), getDriver());
												
												cLib.highlightElement(cLib.WaitForPresenceOfElement("//form[@id='thanks']/input[@value='START BUILDING']",getDriver(), 30), getDriver());
												cLib.WaitForPresenceOfElement("//form[@id='thanks']/input[@value='START BUILDING']",getDriver(), 30).click();
												/*JavascriptExecutor executor = (JavascriptExecutor)getDriver();
												executor.executeScript("arguments[0].click()", pckCatgory);*/
												Thread.sleep(40000);
												if(getDriver().getCurrentUrl().contains("controlcentre.uk-plc.net/homepage")){
													
													System.out.println("Registration finished and safely landed on control centre");
													
												}else{
													System.out.println("Registration Failed");
													cLib.createDialogbox("Ragistration Fail", "Unable to finish Registration or After registration it's not landed on Control Centre  , please report to developer "+getDriver().getCurrentUrl()
															+"' page");
												}
												
											}else{
												System.out.println("Finished Reg tab not appeared");
												cLib.createDialogbox("Finished Reg tab not appeared", "Finished Reg tab not appeared, please report to developer "+getDriver().getCurrentUrl()
														+"' page");
											}
										}
										
									}catch (Exception regFnsh){
										regFnsh.printStackTrace();
										cLib.createDialogbox("Finished Reg Error : ","Finished Registration tab error," 
												+"Please report to developer");
									}
									
								}else{
									cLib.createDialogbox("500 Error", "Getting 500 error for '"+getDriver().getCurrentUrl()
											+"' page");
									}

							}catch(Exception cldLinkError){
								cldLinkError.printStackTrace();
								if(getDriver().getTitle().equals("Server Error")){
									cLib.createDialogbox("Deployment Error : ","Unable to access deployment App" 
									+"due to Server Error");
									System.out.println("Error");
									getDriver().get("https://deployment.ukplc.corp");
								}else if(getDriver().getTitle().equals("502 Bad Gateway")){
									cLib.createDialogbox("Deployment App Error : ","502 Bad Gateway");
											System.out.println("Error");
								}
							}
							
							/*Navigate to deployment application window*/
							/*getDriver().switchTo().window(cLib.navigateToParentWindow(getDriver()));*/
							cLib.openNewTabJSExecuter(getDriver());
							cLib.switchToNewTabByAryLst(getDriver());
							cLib.openURL(getDriver(), deploymentURL);
							
							cLib.createDialogbox("Deployment Confirmation: ", "All test links got tested and "
									+ "working as per expected \n Please complete ticket related testing if any"
									+ " and click on 'OK' 'Working' button");
							
							cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='deployment-actions']"
									+ "/a[contains(text(),'Working')]", getDriver(), 40), getDriver());
				/*			cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//div[@id='page']"
									+ "//div[@id='deployment-actions']/a[contains(text(),'Working')]")), 40);*/
							
							cLib.clickElemntByMouseMovement(getDriver(), cLib.WaitForPresenceOfElement("//div[@id='page']"
									+ "//div[@id='deployment-actions']/a[contains(text(),'Working')]", getDriver(), 40));
							
							if(cLib.WaitForPresenceOfElement("//div[@id='page']//div[@class='alert alert-success']"
									+ "//strong",getDriver(), 1800).isDisplayed()){
								cLib.createDialogbox("Success Message","Cold Deployed on Cressex environment "
										+ "successfully with successful message : "+getDriver().findElement(By.
											xpath("//div[@id='page']//div[@class='alert alert-success']//strong")).
										getText());
							}else{
								cLib.createDialogbox("Failure Message", "Cold is unable to Deploy on Cressex "
										+ "environment");
								}
							
										}else{				//Else for 'Working' button availability 
											System.out.println("Working button is not available");
											cLib.createDialogbox("Working button Error", "Working button is not available, kindly check the "
													+ "deployment app for more info...");
											}
							
										}while(status.contains("Deploying to first server"));
						
						
						}catch(Exception e){
							e.printStackTrace();
							if(getDriver().findElement(By.xpath("//h1[contains(text(),'502 Bad Gateway')]")).isDisplayed()){
								cLib.createDialogbox("Bad Gateway Error", "502 Bad Gateway : Report to Infra or Dev team");
							}
						}
				
			}else{
				cLib.createDialogbox("Navigation Error", "Unable to navigate Cold page ");
			}
			
		}catch(Exception coldErr){
			coldErr.printStackTrace();
			if(getDriver().getTitle().equals("Server Error")){
				cLib.createDialogbox("Deployment Error : ","Unable to access deployment App" 
				+"due to Server Error");
				System.out.println("Error");
				getDriver().get("https://deployment.ukplc.corp");
				}
			}
	}
	
	@AfterClass
	public void configAfterClassMtd(){
		try {
			getDriver().close();
			getDriver().quit();
			vcLib.stopRecording();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
