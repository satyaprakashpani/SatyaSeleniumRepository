package com.cloudbuy.deploymentApp;

import java.io.File;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.cloudbuy.deploymentApp.CommonLib;

public class CheckoutOnCressex extends DriverSetUpCressx{
	CommonLib cLib =new CommonLib();
	CaptureVideo vcLib=new CaptureVideo();
	/*This will open browser and deployment application  */
	@BeforeClass
	public void configBeforeClass() {
		//Start video recording
		try {
			vcLib.startRecording();
		} catch (Exception videoException) {
			videoException.printStackTrace();
			System.out.println("Problem in video recording");
		}
		try{
			setDriver("https://deployment2.ukplc.corp");
			System.out.println("Inside beforeClass--> "+getDriver().getTitle());
			cLib.WaitForPresenceOfElement("//input[@id='login']", getDriver(), 20);
			}catch(Exception e){
				e.printStackTrace();
				if(getDriver().getTitle().equals("Server Error")){
					System.out.println("Inside Catch if Server error");
					cLib.createDialogbox("Deployment Error : ","Unable to access deployment App "
					+"due to Server Error");
					getDriver().navigate().refresh();
				}else{
					cLib.createDialogbox("Deployment Error : ","Unable to access deployment App "
							+"due to deployment app Error");
				}
					
			}
		}
	
	/*Login to deployment application with valid credential */
	@BeforeMethod
	public void configMethod(){
		System.out.println("Inside before method");
		try{
			cLib.createDialogbox("Login Screen ","Please enter your credential and click on 'Submit'"
							+ " button before clicking on OK");
			//cLib.WebsitesToDepllomentApp(getDriver(), "satyaprakash.pani", "Kila@999!");
			/*if(getDriver().findElement(By.xpath("//a[contains(text(),'Applications')]")).getText().
					equals("")){
				System.out.println("Logged in to tha app");
			}*/
		}catch(Exception e){
				if(getDriver().getTitle().equals("Server Error")){
					cLib.createDialogbox("Login Error","Unable to Login");
					getDriver().close();
				}
		}
	}
		
	
	@Test
	public void DeployCheckoutCressex() throws InterruptedException{
		try{
			cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//a[contains"
					+ "(text(),'Applications')]")), 40);
			/*Thread.sleep(10000);*///application response is not same so need to wait long time to	
			//synchronize
			cLib.highlightElement(getDriver().findElement(By.xpath("//a[contains(text(),"
					+ "'Applications')]")), getDriver());
			
			/*Click on Checkout if Checkout link is enabled*/
			WebElement checkOut = getDriver().findElement(By.xpath("//div[@id='page']//a[@href="
					+ "'/applications/checkout']"));
			
			if(getDriver().findElement(By.linkText("Checkout")).isEnabled()){
				System.out.println("Checkout Link is enabled");
				Thread.sleep(10000);
				cLib.highlightElement(checkOut, getDriver());
				System.out.println("Checkout loc: "+checkOut.getLocation());
				/*Actions act = new Actions(getDriver());
				act.click(preview).perform();*/
				JavascriptExecutor executor = (JavascriptExecutor)getDriver();
				executor.executeScript("arguments[0].click()", checkOut);
				System.out.println("Checkout Clicked");
				
				}
			
			/*Click on Deployments tab*/
			/*WebElement deployButton = getDriver().findElement(By.xpath("//td[a[contains(text(),"
					+ "'Cressex')]]/following-sibling::td//button[text()='Deploy']"));
			if(cLib.WaitForPresenceOfElement("//td[a[contains(text(),'Cressex')]]/following-sibling"
					+ "::td//button[text()='Deploy']", getDriver(), 40).isEnabled()){
				cLib.waitAndClickElement(getDriver(), deployButton, 40);
				System.out.println("Deployment Clicked");
			}else{
				cLib.createDialogbox("Deployment Link Issue", "Deployment Link is not enabled");
			}*/
			
			if(cLib.WaitForPresenceOfElement("//div[@id='page']//h1", getDriver(), 30).isDisplayed()){
				cLib.highlightElement(getDriver().findElement(By.xpath("//div[@id='page']//h1")),
						getDriver());
				String oldBNo = getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/"
						+ "following-sibling::td[@class='text-right']")).getText();
				System.out.println("Old Build No : "+oldBNo);
				String data=getDriver().findElement(By.xpath("//tr[td[a[text()='Cressex']]]/td[contains"
						+ "(text(),'Secure-Build(master)')]")).getText();
				/*System.out.println("Data-->"+data);
				System.out.println(data.split("-")[data.split("-").length-1]);*/
				
				/*Highlight Click on build number drop-down*/
				cLib.highlightElement(getDriver().findElement(By.xpath("//td[a[contains(text(),"
						+ "'Cressex')]]/following-sibling::td//button[@class='btn dropdown-toggle "
						+ "btn-default']")), getDriver());
				cLib.WaitForPresenceOfElement("//td[a[contains(text(),'Cressex')]]/following-sibling::td"
						+ "//button[@class='btn dropdown-toggle btn-default']/span", getDriver(), 40).click();
				Thread.sleep(1000);
				
				if(cLib.checkForOldBuild("//td[a[contains(text(),'Cressex')]]/following-sibling::td//"
						+ "span[@class='text']", getDriver(),Integer.valueOf(oldBNo))){
					System.out.println("Build number present");
					try{
					
						cLib.createDialogbox("Build no selection", "Please select suitable build number to deploy");
					
					/*getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/following-sibling"
							+ "::td//button[@class='btn dropdown-toggle btn-default']")).click();*/
					}catch(Exception selectBtn){
						cLib.createDialogbox("Build Not Found", "Dropdown is not enable to click");
						cLib.select("//tr[td[a[text()='Cressex']]]/td/form/select[@name='build']", 
								data.split("-")[data.split("-").length-1], getDriver());
					}
						}else{
							cLib.createDialogbox("Build Not Found", "Please change it manually");
							cLib.clickOnOldBuild(oldBNo, getDriver());
						}
				
				
				//Click on Deploy button
				try{
					cLib.highlightElement(getDriver().findElement(By.xpath("//td[a[contains(text(),"
							+ "'Cressex')]]/following-sibling::td//button[contains(text(),'Deploy')]"
							)),getDriver());
					System.out.println("Highlighted");
					
					getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/following-"
							+ "sibling::td//button[contains(text(),'Deploy')]")).click();
					System.out.println("Cliclked on 'Deploy'");
					
					
				}catch(Exception deploymentButton){
					cLib.createDialogbox("DeployButton", "Deploy Button is not Clickable");
					deploymentButton.printStackTrace();
				}
				
			}else{
				System.out.println("CheckOut not displayed");
			}
			/*Confirm deployment application, environment and build*/
			try{
				if(cLib.WaitForPresenceOfElement("//h2[text()='Confirm Deployment']", getDriver(),
						40).isDisplayed()){
					cLib.highlightElement(getDriver().findElement(By.xpath("//h2[text()='Confirm "
							+ "Deployment']")), getDriver());
					
					
					cLib.createDialogbox("Confirm deployment ", "If Application, Environment and Build "
							+ "No. are correct then click OK in dialog box, \nElse click 'Cancel' on "
							+ "deployment App then click on 'Ok' in dialoge ");
					
				}
			}catch(Exception e){
				e.printStackTrace();
				cLib.createDialogbox("Deployment Error : ","Unable to locate confirm deployment Error");
			}
			
			//Click on Continue button to deploy Checkout on First server
			cLib.waitAndClickElement(getDriver(),getDriver().findElement(By.xpath("//button[text()="
				+ "'Continue']")),40);
			
			System.out.println("Continue button clicked");
			try{
				String status = getDriver().findElement(By.xpath("//div[strong[contains(text(),"
						+ "'Status')]]/following-sibling::div/span")).getText();
				System.out.println("Status-->"+status);
				do{
					String deploymentURL = getDriver().getCurrentUrl();
					System.out.println("Dep Url --> "+deploymentURL);
					
					if(cLib.WaitForPresenceOfElement("//div[@id='deployment-actions']/a[contains(text(),"
							+ "'Working')]", getDriver(),5400).isDisplayed()){
						
						cLib.createDialogbox("Health Check", "Health Check for OK : Report in deployment channel or developer"
								+ " for health check failure");
						
						
						
						/*Open a new window and open Account Lookup*/
						cLib.openNewTabJSExecuter(getDriver());
						cLib.switchToNewTabByAryLst(getDriver());
						
						//Open Account LookUp to login Control Centre for Checkout
						/*Runtime.getRuntime().exec("C:\\AutoIT\\AutoItScript\\Test.exe");
						Thread.sleep(1000);*/
						getDriver().navigate().to("http://intranet/AccountLookUp/AccountLookUp.aspx");
						//Search with Login id 292717 and click on ControlCentre
						getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
						getDriver().findElement(By.xpath("//input[@id='element71171']")).sendKeys
							("292717");
						getDriver().findElement(By.xpath("//span[@id='div71174']/li/span/input")).click();
						cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//"
								+ "a[contains(text(),'Control centre')]")), 10);
						getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
						
						try{
							//Open testlink1 for Checkout
							cLib.openURL(getDriver(), "http://checkout1.uk-plc.net/checkout/receipt.aspx?ordernumber"
									+ "=2149232");
							System.out.println("Page title : "+getDriver().getTitle());
							System.out.println(getDriver().getCurrentUrl());
							if(!getDriver().getTitle().contains("500")){
							getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
							cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='wrapper']//div/b", getDriver(), 40),
									getDriver());
							String orderNoText = cLib.WaitForPresenceOfElement("//div[@id='wrapper']//div/b", getDriver(), 40).
									getText().replaceAll("[a-zA-Z]", "").replace(" ", "");
							System.out.println("Ord No -->"+orderNoText);
							
							cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='listbuttons']//span[contains(text(),"
									+ "'View Invoice')]", getDriver(), 40), getDriver());
							cLib.WaitForPresenceOfElement("//div[@id='listbuttons']//span[contains(text(),'View Invoice')]", 
									getDriver(), 40).click();
							getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
							if(cLib.WaitForPresenceOfElement("//div[@id='wrapper']//div[contains(text(),'Invoice')]", getDriver(),
									40).isDisplayed()){
								String[] textArr = cLib.WaitForPresenceOfElement("//div[@id='wrapper']//li[@class='li-invoiceinfo']"
										+ "[1]",getDriver(), 40).getText().replaceAll("[a-zA-Z]", "").split(":");
								
								if(orderNoText.trim().equals(textArr[1].trim())){
									System.out.println(" Checkout Test Link1 Passed");
								}
							}else{
								cLib.createDialogbox("Testlink testing Failed", "Getting 500 Error while testing "+
										getDriver().getTitle()+"page");
								}
							}else {
								
								cLib.createDialogbox("500 Error", "Getting 500 Error while testing "+
										getDriver().getTitle()+"page");
							}
						}catch(Exception e){
							e.printStackTrace();
						}
						
						try{
							//Open testlink2 for Checkout
							cLib.openURL(getDriver(), "http://checkout1.uk-plc.net/checkout/receipt.aspx?ordernumber="
									+ "2068287");
							System.out.println("Page title : "+getDriver().getTitle());
							System.out.println(getDriver().getCurrentUrl());
							if(!getDriver().getTitle().contains("500")){
							getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
							
							List<WebElement> downLdBtns =getDriver().findElements(By.xpath("//dt[contains(text(),'Sacko junior')]/"
									+ "../../following-sibling::li//span[contains(text(),'Download Files')]"));
							System.out.println("No of btns : "+downLdBtns.size());
							cLib.highlightElement(downLdBtns.get(1), getDriver());
							downLdBtns.get(1).click();
							Thread.sleep(3000);
							//Runtime.getRuntime().exec("C:\\AutoIT\\AutoItScript\\downLoadPopUp.exe");
							Thread.sleep(4000);
							File dwnLdFile = new File("C:\\Users\\"+System.getProperty("user.name")+"\\Downloads\\c173615x91359.jpg");
							
							//Check if File exist in the specified path
							if(dwnLdFile.exists()){
								System.out.println("File downloaded So Test link Pass");
								System.out.println(dwnLdFile.getAbsolutePath());
								dwnLdFile.delete();
								System.out.println("File Deleted");
								}else{
									System.out.println("File not available in Downloaded path");
									cLib.createDialogbox("Download error", "Unable to download, So Check out Test link failed : "
									+getDriver().getCurrentUrl());
								}
									
							}
						}catch(Exception cloudBuyLinkErr){
							System.out.println("Error on SPS test Link ");
							cloudBuyLinkErr.printStackTrace();
							cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
							getDriver().getTitle()+"page");
						}
						
					}else{
						if(getDriver().findElement(By.xpath("//strong[contains(text(),'Deployment "
								+ "failed')]")).isDisplayed()){
							
						}
					}
					
					/*Navigate to deployment application window*/
					/*getDriver().switchTo().window(cLib.navigateToParentWindow(getDriver()));*/
					cLib.openNewTabJSExecuter(getDriver());
					cLib.switchToNewTabByAryLst(getDriver());
					cLib.openURL(getDriver(), deploymentURL);
					cLib.createDialogbox("Deployment Confirmation: ", "All test links got tested and "
							+ "working as per expected \n Please complete ticket related testing if any"
							+ " and click on 'OK' 'Working' button");
					
					
				/*	cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//button
				 * [contains(text(),'Working')]")), 30);*/
					
					if(cLib.WaitForPresenceOfElement("//div[@id='page']//strong[contains(text(),"
							+ "'Success')]",getDriver(), 1800).isDisplayed()){
						cLib.createDialogbox("Success Message","Preview Deployed on Cressex environment "
								+ "successfully with successful message : "+getDriver().findElement(By.
									xpath("//div[@id='page']//div[@class='alert alert-success']")).
								getText());
					}else{
						cLib.createDialogbox("Failure Message", "Preview is unable to Deploy on Ash "
								+ "environment");
					}
						
						
					
				}while(status.contains("Deploying to first server"));
			}catch(Exception e){
				e.printStackTrace();
				System.out.println(getDriver().getCurrentUrl()+"--->"+getDriver().getTitle());
			}
			
		}catch(Exception e){
			e.printStackTrace();
			System.out.println(getDriver().getCurrentUrl()+"--->"+getDriver().getTitle());
			if(getDriver().getTitle().equals("Server Error")){
				cLib.createDialogbox("Deployment Error : ","Unable to access deployment App due to Server"
						+ " Error");
			}
				
			
		}
		
	}
	//Test
	
	//After class
	@AfterClass
	public void configAfterClassMtd(){
		try {
			getDriver().close();
			getDriver().quit();
			vcLib.stopRecording();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
