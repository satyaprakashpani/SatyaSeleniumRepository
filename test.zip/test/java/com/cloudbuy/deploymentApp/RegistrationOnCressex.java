package com.cloudbuy.deploymentApp;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class RegistrationOnCressex extends DriverSetUpCressx{
	CommonLib cLib =new CommonLib();
	CaptureVideo vcLib=new CaptureVideo();
	/*This will open browser and deployment application  */
	@BeforeClass
	public void configBeforeClass() {
		//Start video recording
		try {
			vcLib.startRecording();
		} catch (Exception videoException) {
			videoException.printStackTrace();
			System.out.println("Problem in video recording");
		}
		try{
			setDriver("https://deployment2.ukplc.corp");
			System.out.println("Inside beforeClass--> "+getDriver().getTitle());
			//cLib.WaitForPresenceOfElement("//input[@id='login']", getDriver(), 30);
			System.out.println("Login screen appears");
			}catch(Exception e){
				System.out.println("---------------------");
				e.printStackTrace();
				if(getDriver().getTitle().equals("Server Error")){
					
					getDriver().navigate().refresh();
				}else{
					cLib.createDialogbox("Deployment Error : ","Unable to access deployment App "
							+"due to deployment app Error");
				}
					
			}
		}
	
	/*Enter credentials to deployment application with valid credential */
	@BeforeMethod
	public void configMethod(){
		System.out.println("Inside before method");
		try{
			cLib.createDialogbox("Deployment Credential ","Please enter your credential and click on 'Submit'"
							+ " button before clicking on OK");
		}catch(Exception e){
				if(getDriver().getTitle().equals("Server Error")){
					cLib.createDialogbox("Websites Error","Unable to Websites");
					getDriver().close();
				}
		}
	}
	
	@Test
	public void deployRegistrationOnCressexTest(){
		System.out.println("Inside deployRegistrationOnCressexTest()");
		try{
			cLib.highlightElement(getDriver().findElement(By.xpath("//div[@id='page']")), getDriver());
			//cLib.WaitForPresenceOfElement("//div[@id='page']", getDriver(), 40);
			cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//a[contains"
					+ "(text(),'Applications')]")), 40);
			Thread.sleep(2000);
			cLib.highlightElement(getDriver().findElement(By.xpath("//a[contains(text(),"
					+ "'Applications')]")), getDriver());
			
			/*Click on Websites if Registration link is enabled*/
			WebElement reg = getDriver().findElement(By.xpath("//div[@id='page']//div[@class='list"
					+ "-group-item']//a[text()='Registration']"));
			if(reg.isEnabled()){
				System.out.println("Registration Link is enabled");
				Thread.sleep(6000);
				cLib.highlightElement(reg, getDriver());
				System.out.println("Registration loc: "+reg.getLocation());
				/*Actions act = new Actions(getDriver());
				act.click(Websites).perform();*/
				JavascriptExecutor executor = (JavascriptExecutor)getDriver();
				executor.executeScript("arguments[0].click()", reg);
				System.out.println("Registration Clicked");
				
				}
			if(cLib.WaitForPresenceOfElement("//div[@id='page']//h1", getDriver(), 30).isDisplayed()){
				cLib.highlightElement(getDriver().findElement(By.xpath("//div[@id='page']//h1")),
						getDriver());
				String oldBNo = getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/"
						+ "following-sibling::td[@class='text-right']")).getText();
				System.out.println("Old Build No : "+oldBNo);
				String data=getDriver().findElement(By.xpath("//tr[td[a[text()='Cressex']]]/td[contains"
						+ "(text(),'Registration-Build')]")).getText();
				/*System.out.println("Data-->"+data);
				System.out.println(data.split("-")[data.split("-").length-1]);*/
				
				/*Highlight and Click on build number drop-down*/
				cLib.highlightElement(getDriver().findElement(By.xpath("//td[a[contains(text(),"
						+ "'Cressex')]]/following-sibling::td//button[@class='btn dropdown-toggle "
						+ "btn-default']")), getDriver());
				Thread.sleep(2000);
				getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/following-sibling"
						+ "::td//button[@class='btn dropdown-toggle btn-default']/span")).click();
				
				if(cLib.checkForOldBuild("//td[a[contains(text(),'Cressex')]]/following-sibling::td//"
						+ "span[@class='text']", getDriver(),Integer.valueOf(oldBNo))){
					System.out.println("Build number present");
					//Test
					try{
					//cLib.clickOnOldBuild(oldBNo, getDriver());
						cLib.createDialogbox("Build Selection","Please change it manually");
					}catch(Exception selectBtn){
						cLib.createDialogbox("Build Not Found", "Dropdown is not enable to click");
						cLib.select("//tr[td[a[text()='Cressex']]]/td/form/select[@name='build']", 
								data.split("-")[data.split("-").length-1], getDriver());
					}
						}else{
							cLib.createDialogbox("Build Not Found", "Please change it manually");
							cLib.clickOnOldBuild(oldBNo, getDriver());
						}
				//Click on Deploy button
				try{
					cLib.highlightElement(getDriver().findElement(By.xpath("//td[a[contains(text(),"
							+ "'Cressex')]]/following-sibling::td//button[contains(text(),'Deploy')]"
							)),getDriver());
					System.out.println("Highlighted");
					
					/*Actions deploy = new Actions(getDriver());
					deploy.click(getDriver().findElement(By.xpath("//tr[td[a[text()='Cressex']]]/td/form"
							+ "/button[text()='Deploy' and @class='btn']"))).perform();*/
					getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/following-"
							+ "sibling::td//button[contains(text(),'Deploy')]")).click();
					System.out.println("Cliclked on 'Deploy'");
					
				}catch(Exception deploymentButton){
					cLib.createDialogbox("DeployButton", "Deploy Button is not Clickable");
					deploymentButton.printStackTrace();
				}
				
				/*Confirm deployment application, environment and build*/
				try{
					if(cLib.WaitForPresenceOfElement("//h2[text()='Confirm Deployment']", getDriver(),
							40).isDisplayed()){
						cLib.highlightElement(getDriver().findElement(By.xpath("//h2[text()='Confirm "
								+ "Deployment']")), getDriver());
						
						
						cLib.createDialogbox("Confirm deployment ", "If Application, Environment and Build "
								+ "No. are correct then click OK in dialog box, \nElse click 'Cancel' on "
								+ "deployment App then click on 'Ok' in dialoge ");
						
					}
				}catch(Exception e){
					e.printStackTrace();
					cLib.createDialogbox("Error :","Error in : "+getDriver().getCurrentUrl());
				}
				
				
				//Click on Continue button to deploy Registration on First server
				cLib.waitAndClickElement(getDriver(),getDriver().findElement(By.xpath("//button[text()="
					+ "'Continue']")),40);
				
				System.out.println("Continue button clicked");
				
				
				try{
					String status = getDriver().findElement(By.xpath("//div[strong[contains(text(),"
							+ "'Status')]]/following-sibling::div/span")).getText();
					System.out.println("Status-->"+status);
					do{
						String deploymentURL = getDriver().getCurrentUrl();
						System.out.println("Dep Url --> "+deploymentURL);
						
						if(cLib.WaitForPresenceOfElement("//div[@id='deployment-actions']/a[contains(text(),"
								+ "'Working')]", getDriver(),5400).isDisplayed()){
							cLib.createDialogbox("Health Check", "For health check failure, click on 'Go' button once, if still persists then Report in deployment channel or developer"
									+ "\n Click on 'OK' button of dialog box to proceed");
							
							try{
								//Open testlink for Registration test link1
								System.out.println("Navigating to Registration test link1");
								cLib.openNewWindow(getDriver());
								cLib.switchToNewWindow(getDriver());
								cLib.openURL(getDriver(), "http://signup1.uk-plc.net/Step/EnterDetails.aspx?RegisterWith=1140");
								//cLib.openUrlInNewTab(getDriver(), "http://signup1.uk-plc.net/Step/EnterDetails.aspx?RegisterWith=1140");
								getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
								
								if((!getDriver().getTitle().contains("500"))){
									
									try{
										if(cLib.WaitForPresenceOfElement("//h3[contains(text(),'Enter Your Details')]", getDriver(), 40).isDisplayed()){
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='FirstName']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='FirstName']",getDriver(), 30).sendKeys("TestLink1");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Surname']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Surname']",getDriver(), 30).sendKeys("Link1SurName");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='EmailAddress']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='EmailAddress']",getDriver(), 30).clear();
											cLib.WaitForPresenceOfElement("//input[@id='EmailAddress']",getDriver(), 30).sendKeys("satyaprakash.pani@cloudbuy.com");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='CompanyName']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='CompanyName']",getDriver(), 30).sendKeys("AutomationTest Link1 Ltd.");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Submit']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Submit']",getDriver(), 30).click();
										}else{
											System.out.println("Enter detail not appeared");
											cLib.createDialogbox("Enter details not appeared", "Enter Details tab not appeared, please report to developer "+getDriver().getCurrentUrl()
													+"' page");
										}
									}catch (Exception dtlEntryError){
										dtlEntryError.printStackTrace();
										cLib.createDialogbox("Enter details Error : ","Unable to enter details," 
												+"Please report to developer");
									}
									
									try{
										if(cLib.WaitForPresenceOfElement("//h3[contains(text(),'Enter Your Business Address')]", getDriver(), 40).isDisplayed()){
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='AddressLine1']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='AddressLine1']",getDriver(), 30).sendKeys("Link1 address");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//select[@id='CountryCode']",getDriver(), 30), getDriver());
											cLib.select("//select[@id='CountryCode']", "IN", getDriver());
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Postcode']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Postcode']",getDriver(), 30).sendKeys("001101");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='TelephoneNumber']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='TelephoneNumber']",getDriver(), 30).sendKeys("9883256785");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Submit']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Submit']",getDriver(), 30).click();
										}else{
											System.out.println("Enter your business address not appeared");
											cLib.createDialogbox("Enter your business address not appeared", "Enter your business address tab not appeared, please report to developer "+getDriver().getCurrentUrl()
													+"' page");
										}
									}catch (Exception bsnsAdrsErr){
										bsnsAdrsErr.printStackTrace();
										cLib.createDialogbox("Business address Error : ","Unable to set business address," 
												+"Please report to developer");
									}
									
									
									getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
									String userName = "AutomationTestlink1-User"+Math.round(Math.random()*100);
									try{
										if(cLib.WaitForPresenceOfElement("//h3[contains(text(),'Set Up Account')]", getDriver(), 40).isDisplayed()){
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Username']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Username']",getDriver(), 30).clear();
											cLib.WaitForPresenceOfElement("//input[@id='Username']",getDriver(), 30).sendKeys(userName);
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Password']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Password']",getDriver(), 30).sendKeys("Satya@1234!");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Password2']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Password2']",getDriver(), 30).sendKeys("Satya@1234!");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//select[@id='SecurityQuestion']",getDriver(), 30), getDriver());
											cLib.select("//select[@id='SecurityQuestion']", "8", getDriver());
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='SecurityQuestionAnswer']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='SecurityQuestionAnswer']",getDriver(), 30).sendKeys("123456");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Terms']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Terms']",getDriver(), 30).click();
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Submit']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Submit']",getDriver(), 30).click();
										}else{
											System.out.println("Set Up Account not appeared");
											cLib.createDialogbox("Set Up Account not appeared", "Set Up Account tab not appeared, please report to developer "+getDriver().getCurrentUrl()
													+"' page");
										}
									}catch (Exception acntStUpErr){
										acntStUpErr.printStackTrace();
										cLib.createDialogbox("Account SetUp Error : ","Unable to setup account," 
												+"Please report to developer");
									}
									
									try{
										if(cLib.WaitForPresenceOfElement("//h3[contains(text(),'Choose Default Category')]", getDriver(), 40).isDisplayed()){
											Thread.sleep(10000);
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='CategoryElementRow']//a[contains(text(),'Pick Category')]",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//div[@id='CategoryElementRow']//a[contains(text(),'Pick Category')]",getDriver(), 30).click();
											
											if(cLib.WaitForPresenceOfElement("//div[@id='categoryTree']", getDriver(), 40).isDisplayed()){
												
												cLib.highlightElement(cLib.WaitForPresenceOfElement("//span[contains(text(),'Lifestyle')]",getDriver(), 30), getDriver());
												cLib.WaitForPresenceOfElement("//span[contains(text(),'Lifestyle')]",getDriver(), 30).click();
												
												cLib.highlightElement(cLib.WaitForPresenceOfElement("//span[contains(text(),'Transport')]",getDriver(), 30), getDriver());
												cLib.WaitForPresenceOfElement("//span[contains(text(),'Transport')]",getDriver(), 30).click();
												
												cLib.highlightElement(cLib.WaitForPresenceOfElement("//button[span[contains(text(),'Save')]]",getDriver(), 30), getDriver());
												cLib.WaitForPresenceOfElement("//button[span[contains(text(),'Save')]]",getDriver(), 30).click();
																				
												
												
											}else{
												System.out.println("Catagory tree not appeared");
												cLib.createDialogbox("Catagory tree not appeared", "Catagory tree tab not appeared, please report to developer "+getDriver().getCurrentUrl()
														+"' page");
											}
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Submit' and @value='Next']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Submit' and @value='Next']",getDriver(), 30).click();
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Submit' and @value='Complete Registration']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Submit' and @value='Complete Registration']",getDriver(), 30).click();
											
										}else{
											System.out.println("Pick Catagory not appeared");
											cLib.createDialogbox("Pick Catagory not appeared", "Choose Default Category tab not appeared, please report to developer "+getDriver().getCurrentUrl()
													+"' page");
										}
										
									}catch (Exception pickCatErr){
										pickCatErr.printStackTrace();
										cLib.createDialogbox("Pick Catagory Error : ","Unable to pick catagory," 
												+"Please report to developer");
									}
									
									if(!getDriver().getTitle().contains("500")){
									
									if(getDriver().getCurrentUrl().contains("controlcentre.uk-plc.net")){
										System.out.println("Test link 1 Passed");
										}else{
											cLib.createDialogbox("Test Link Failed", "After successful registration the site is not landed on control centre '"+getDriver().getCurrentUrl()
													+"' page");
											}
									}else{
										cLib.createDialogbox("500 Error", "Getting 500 error for '"+getDriver().getCurrentUrl()
												+"' page");
										}
								}else{
									cLib.createDialogbox("500 Error", "Getting 500 error for '"+getDriver().getCurrentUrl()
											+"' page");
									}

							}catch(Exception RgstrnLink1Error){
								RgstrnLink1Error.printStackTrace();
								if(getDriver().getTitle().equals("Server Error")){
									cLib.createDialogbox("Deployment Error : ","Unable to access deployment App" 
									+"due to Server Error");
									System.out.println("Error");
									getDriver().get("https://deployment.ukplc.corp");
								}else if(getDriver().getTitle().equals("502 Bad Gateway")){
									cLib.createDialogbox("Deployment App Error : ","502 Bad Gateway");
											System.out.println("Error");
								}
							}
							
							try{
								//Open testlink for Registration test link2
								System.out.println("Navigating to Registration test link2");
								cLib.openUrlInNewTab(getDriver(), "http://signup1.uk-plc.net/Step/EnterDetails.aspx?RegisterWith=1136");
								getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
								
								if((!getDriver().getTitle().contains("500"))){
									try{
										/*code for Cookie pop-up close*/
										if(cLib.WaitForPresenceOfElement("//div[@id='CookiePolicyPopup']", getDriver(), 40).isDisplayed()){
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='CookiePolicyPopup']", getDriver(), 40), getDriver());
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='CookiePolicyPopup']//button[@class='close']", getDriver(), 40), getDriver());
											cLib.WaitForPresenceOfElement("//div[@id='CookiePolicyPopup']//button[@class='close']", getDriver(), 40).click();
										}
									}catch(Exception cookiesPlcyError){
										System.out.println("Cookies Policy not appeared");
										cookiesPlcyError.printStackTrace();
									}
									
									try{
										if(cLib.WaitForPresenceOfElement("//h3[contains(text(),'Enter Your Details')]", getDriver(), 40).isDisplayed()){
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='FirstName']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='FirstName']",getDriver(), 30).sendKeys("Test");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Surname']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Surname']",getDriver(), 30).sendKeys("Test123");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='EmailAddress']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='EmailAddress']",getDriver(), 30).clear();
											cLib.WaitForPresenceOfElement("//input[@id='EmailAddress']",getDriver(), 30).sendKeys("satyaprakash.pani@cloudbuy.com");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='CompanyName']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='CompanyName']",getDriver(), 30).sendKeys("MoCompany");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Submit']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Submit']",getDriver(), 30).click();
										}else{
											System.out.println("Enter detail not appeared");
											cLib.createDialogbox("Enter details not appeared", "Enter Details tab not appeared, please report to developer "+getDriver().getCurrentUrl()
													+"' page");
										}
									}catch (Exception dtlEntryError){
										dtlEntryError.printStackTrace();
										cLib.createDialogbox("Enter details Error : ","Unable to enter details," 
												+"Please report to developer");
									}
									
									try{
										if(cLib.WaitForPresenceOfElement("//h3[contains(text(),'Enter Your Business Address')]", getDriver(), 40).isDisplayed()){
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='AddressLine1']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='AddressLine1']",getDriver(), 30).sendKeys("Jodhpur");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//select[@id='CountryCode']",getDriver(), 30), getDriver());
											cLib.select("//select[@id='CountryCode']", "IN", getDriver());
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Postcode']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Postcode']",getDriver(), 30).sendKeys("001101");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='TelephoneNumber']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='TelephoneNumber']",getDriver(), 30).sendKeys("9883256785");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Submit']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Submit']",getDriver(), 30).click();
										}else{
											System.out.println("Enter your business address not appeared");
											cLib.createDialogbox("Enter your business address not appeared", "Enter your business address tab not appeared, please report to developer "+getDriver().getCurrentUrl()
													+"' page");
										}
									}catch (Exception bsnsAdrsErr){
										bsnsAdrsErr.printStackTrace();
										cLib.createDialogbox("Business address Error : ","Unable to set business address," 
												+"Please report to developer");
									}
									
									
									getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
									String userName = "AutomationTestlink2-User"+Math.round(Math.random()*1000);
									try{
										if(cLib.WaitForPresenceOfElement("//h3[contains(text(),'Set Up Account')]", getDriver(), 40).isDisplayed()){
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Username']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Username']",getDriver(), 30).clear();
											cLib.WaitForPresenceOfElement("//input[@id='Username']",getDriver(), 30).sendKeys(userName);
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Password']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Password']",getDriver(), 30).sendKeys("Satya@1234!");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Password2']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Password2']",getDriver(), 30).sendKeys("Satya@1234!");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//select[@id='SecurityQuestion']",getDriver(), 30), getDriver());
											cLib.select("//select[@id='SecurityQuestion']", "8", getDriver());
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='SecurityQuestionAnswer']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='SecurityQuestionAnswer']",getDriver(), 30).sendKeys("123456");
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Terms']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Terms']",getDriver(), 30).click();
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Submit']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Submit']",getDriver(), 30).click();
										}else{
											System.out.println("Set Up Account not appeared");
											cLib.createDialogbox("Set Up Account not appeared", "Set Up Account tab not appeared, please report to developer "+getDriver().getCurrentUrl()
													+"' page");
										}
									}catch (Exception acntStUpErr){
										acntStUpErr.printStackTrace();
										cLib.createDialogbox("Account SetUp Error : ","Unable to setup account," 
												+"Please report to developer");
									}
									
									try{
										if(cLib.WaitForPresenceOfElement("//div[@id='appPageItems']//form/h3", getDriver(), 40).isDisplayed()){
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='appPageItems']//form/h3",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//div[@id='CategoryElementRow']//a[contains(text(),'Pick Category')]",getDriver(), 30).click();
											
											if(cLib.WaitForPresenceOfElement("//li[@id='personal-computing']", getDriver(), 40).isDisplayed()){
												
												cLib.highlightElement(cLib.WaitForPresenceOfElement("//li[@id='personal-computing']/a",getDriver(), 30), getDriver());
												cLib.WaitForPresenceOfElement("//li[@id='personal-computing']/a",getDriver(), 30).click();
												
												cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Submit']",getDriver(), 30), getDriver());
												cLib.WaitForPresenceOfElement("//input[@id='Submit']",getDriver(), 30).click();
												
																				
												
												
											}else{
												System.out.println("Catagory tree not appeared");
												cLib.createDialogbox("Catagory tree not appeared", "Catagory tree tab not appeared, please report to developer "+getDriver().getCurrentUrl()
														+"' page");
											}
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Submit' and @value='Complete Registration']",getDriver(), 30), getDriver());
											cLib.WaitForPresenceOfElement("//input[@id='Submit' and @value='Complete Registration']",getDriver(), 30).click();
											
											
										}else{
											System.out.println("Pick Catagory not appeared");
											cLib.createDialogbox("Pick Catagory not appeared", "Choose Default Category tab not appeared, please report to developer "+getDriver().getCurrentUrl()
													+"' page");
										}
										
									}catch (Exception pickCatErr){
										pickCatErr.printStackTrace();
										cLib.createDialogbox("Pick Catagory Error : ","Unable to pick catagory," 
												+"Please report to developer");
									}
									
									if(!getDriver().getTitle().contains("500")){
									
									if(getDriver().getCurrentUrl().contains("controlcentre.uk-plc.net")){
										System.out.println("Successfully registered and safely landed on controlcentre, Hence Test link 2 Passed");
										}else{
											cLib.createDialogbox("Test Link Failed", "After successful registration the site is not landed on control centre '"+getDriver().getCurrentUrl()
													+"' page");
											}
									}else{
										cLib.createDialogbox("500 Error", "Getting 500 error for '"+getDriver().getCurrentUrl()
												+"' page");
										}
								}else{
									cLib.createDialogbox("500 Error", "Getting 500 error for '"+getDriver().getCurrentUrl()
											+"' page");
									}

							}catch(Exception BLinkError1){
								BLinkError1.printStackTrace();
								if(getDriver().getTitle().equals("Server Error")){
									cLib.createDialogbox("Deployment Error : ","Unable to access deployment App" 
									+"due to Server Error");
									System.out.println("Error");
									getDriver().get("https://deployment.ukplc.corp");
								}else if(getDriver().getTitle().equals("502 Bad Gateway")){
									cLib.createDialogbox("Deployment App Error : ","502 Bad Gateway");
											System.out.println("Error");
								}
							}
							
							/*Navigate to deployment application window*/
							/*getDriver().switchTo().window(cLib.navigateToParentWindow(getDriver()));*/
							cLib.openNewTabJSExecuter(getDriver());
							cLib.switchToNewTabByAryLst(getDriver());
							cLib.openURL(getDriver(), deploymentURL);
							
							cLib.createDialogbox("Deployment Confirmation: ", "All test links got tested and "
									+ "working as per expected \n Please complete ticket related testing if any"
									+ " and click on 'OK' 'Working' button");
							
							cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='deployment-actions']"
									+ "/a[contains(text(),'Working')]", getDriver(), 40), getDriver());
				/*			cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//div[@id='page']"
									+ "//div[@id='deployment-actions']/a[contains(text(),'Working')]")), 40);*/
							
							cLib.clickElemntByMouseMovement(getDriver(), cLib.WaitForPresenceOfElement("//div[@id='page']"
									+ "//div[@id='deployment-actions']/a[contains(text(),'Working')]", getDriver(), 40));
							
							if(cLib.WaitForPresenceOfElement("//div[@id='page']//div[@class='alert alert-success']"
									+ "//strong",getDriver(), 1800).isDisplayed()){
								cLib.createDialogbox("Success Message","Registration Deployed on Cressex environment "
										+ "successfully with successful message : "+getDriver().findElement(By.
											xpath("//div[@id='page']//div[@class='alert alert-success']//strong")).
										getText());
							}else{
								cLib.createDialogbox("Failure Message", "Registration is unable to Deploy on Cressex "
										+ "environment");
							}
							
							
						}else{				//Else for 'Working' button availability 
							System.out.println("Working button is not available");
							cLib.createDialogbox("Working button Error", "Working button is not available, kindly check the "
									+ "deployment app for more info...");
							}
						}while(status.contains("Deploying to first server"));
					}catch(Exception e){
						e.printStackTrace();
						if(getDriver().findElement(By.xpath("//h1[contains(text(),'502 Bad Gateway')]")).isDisplayed()){
							cLib.createDialogbox("Bad Gateway Error", "502 Bad Gateway : Report to Infra or Dev team");
							}	
						}
				
			}else{
				cLib.createDialogbox("Navigation Error", "Unable to navigate Registration page ");
			}
			
			}catch(Exception wbErr){
				wbErr.printStackTrace();
				if(getDriver().getTitle().equals("Server Error")){
					cLib.createDialogbox("Deployment Error : ","Unable to access deployment App" 
					+"due to Server Error");
					System.out.println("Error");
					getDriver().get("https://deployment2.ukplc.corp");
					}
			}
		}
	
	@AfterClass
	public void configAfterClassMtd(){
		try {
			getDriver().close();
			getDriver().quit();
			vcLib.stopRecording();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
