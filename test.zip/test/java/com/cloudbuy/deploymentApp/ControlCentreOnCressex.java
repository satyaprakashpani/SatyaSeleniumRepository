package com.cloudbuy.deploymentApp;

import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class ControlCentreOnCressex extends DriverSetUpCressx{
	CommonLib cLib =new CommonLib();
	CaptureVideo vcLib=new CaptureVideo();
	
	/*This will open browser and deployment application  */
	@BeforeClass
	public void configBeforeClass() {
		//Start video recording
		try {
			vcLib.startRecording();
		} catch (Exception videoException) {
			videoException.printStackTrace();
			System.out.println("Problem in video recording");
		}
		try{
			setDriver("https://deployment2.ukplc.corp");
			getDriver().navigate().refresh();
			System.out.println("Inside beforeClass--> "+getDriver().getTitle());
			cLib.WaitForPresenceOfElement("//input[@id='login']", getDriver(), 20);
			}catch(Exception e){
				e.printStackTrace();
				if(getDriver().getTitle().equals("Server Error")){
					System.out.println("Inside Catch if Server error");
					cLib.createDialogbox("Deployment Error : ","Unable to access deployment App "
					+"due to Server Error");
					getDriver().navigate().refresh();
				}else{
					cLib.createDialogbox("Deployment Error : ","Unable to access deployment App "
							+"due to deployment app Error");
				}
					
			}
		}
	

	/*Login to deployment application with valid credential */
	@BeforeMethod
	public void configMethod(){
		System.out.println("Inside before method");
		try{
			cLib.createDialogbox("Login Screen ","Please enter your credential and click on 'Submit'"
							+ " button before clicking on dialogbox 'OK' button");
			//cLib.WebsitesToDepllomentApp(getDriver(), "satyaprakash.pani", "Kila@999!");
			/*if(getDriver().findElement(By.xpath("//a[contains(text(),'Applications')]")).getText().
					equals("")){
				System.out.println("Logged in to tha app");
			}*/
		}catch(Exception e){
				if(getDriver().getTitle().equals("Server Error")){
					cLib.createDialogbox("Login Error","Unable to Login");
					getDriver().close();
				}
		}
	}
		
	@Test
	public void DeployControlCentreTest(){
		
		try{
			cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//a[contains"
					+ "(text(),'Applications')]")), 40);
			/*Thread.sleep(10000);*///application response is not same so need to wait long time to	
			//synchronize
			Thread.sleep(2000);
			cLib.highlightElement(getDriver().findElement(By.xpath("//a[contains(text(),"
					+ "'Applications')]")), getDriver());
			
			/*Click on Sites if Sites link is enabled*/
			WebElement cc = getDriver().findElement(By.xpath("//div[@id='page']//div[@class='list-group-item']"
					+ "//a[contains(text(),'Control Centre')]"));
			
			if(cc.isEnabled()){
				System.out.println("sites Link is enabled");
				Thread.sleep(10000);
				cLib.highlightElement(cc, getDriver());
				System.out.println("sites loc: "+cc.getLocation());
				/*Actions act = new Actions(getDriver());
				act.click(sites).perform();*/
				JavascriptExecutor executor = (JavascriptExecutor)getDriver();
				executor.executeScript("arguments[0].click()", cc);
				System.out.println("CC Clicked");
				
				}
			
			
			
			if(cLib.WaitForPresenceOfElement("//div[@id='page']//h1", getDriver(), 30).isDisplayed()){
				cLib.highlightElement(getDriver().findElement(By.xpath("//div[@id='page']//h1")),
						getDriver());
				String oldBNo = getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/"
						+ "following-sibling::td[@class='text-right']")).getText();
				System.out.println("Old Build No : "+oldBNo);
				//String data=getDriver().findElement(By.xpath("//tr[td[a[text()='Cressex']]]/td[contains(text(),'ControlCentre')]")).getText();
				/*System.out.println("Data-->"+data);
				System.out.println(data.split("-")[data.split("-").length-1]);*/
				
				/*Highlight and Click on build number drop-down*/
				cLib.highlightElement(getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]"
						+ "/following-sibling::td//button[@class='btn dropdown-toggle btn-default']/span")), getDriver());
				getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/following-sibling"
						+ "::td//button[@class='btn dropdown-toggle btn-default']/span")).click();
				
				/*if(cLib.checkForOldBuild("//td[a[contains(text(),'Cressex')]]/following-sibling::td//"
						+ "span[@class='text']", getDriver(),Integer.valueOf(oldBNo))){
					System.out.println("Build number present");
					try{
					
					cLib.clickOnOldBuild(oldBNo, getDriver());
					}catch(Exception selectBtn){
						cLib.createDialogbox("Build Not Found", "Dropdown is not enable to click");
						cLib.select("//tr[td[a[text()='Cressex']]]/td/form/select[@name='build']", 
								data.split("-")[data.split("-").length-1], getDriver());
					}
						}else{
							cLib.createDialogbox("Build Not Found", "Please change it manually");
							cLib.clickOnOldBuild(oldBNo, getDriver());
						}*/
				cLib.createDialogbox("Build Selection","Please Click on suitable build no. manually");
				
				//Click on Deploy button
				try{
					cLib.highlightElement(getDriver().findElement(By.xpath("//td[a[contains(text(),"
							+ "'Cressex')]]/following-sibling::td//button[contains(text(),'Deploy')]"
							)),getDriver());
					System.out.println("Highlighted");
					
					/*Actions deploy = new Actions(getDriver());
					deploy.click(getDriver().findElement(By.xpath("//tr[td[a[text()='Cressex']]]/td/form"
							+ "/button[text()='Deploy' and @class='btn']"))).perform();*/
					getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/following-"
							+ "sibling::td//button[contains(text(),'Deploy')]")).click();
					System.out.println("Cliclked on 'Deploy'");
					
					
				}catch(Exception deploymentButton){
					cLib.createDialogbox("DeployButton", "Deploy Button is not Clickable");
					deploymentButton.printStackTrace();
				}
				
				/*Confirm deployment application, environment and build*/
				try{
					if(cLib.WaitForPresenceOfElement("//h2[text()='Confirm Deployment']", getDriver(),
							40).isDisplayed()){
						cLib.highlightElement(getDriver().findElement(By.xpath("//h2[text()='Confirm "
								+ "Deployment']")), getDriver());
						
						
						cLib.createDialogbox("Confirm deployment ", "If Application, Environment and Build "
								+ "No. are correct then click OK in dialog box, \nElse click 'Cancel' on "
								+ "deployment App then click on 'Ok' in dialoge ");
						
					}
				}catch(Exception e){
					e.printStackTrace();
					cLib.createDialogbox("Error :","Error in : "+getDriver().getCurrentUrl());
				}
				
				//Click on Continue button to deploy CC on First server
				cLib.waitAndClickElement(getDriver(),getDriver().findElement(By.xpath("//button[text()="
					+ "'Continue']")),40);
				
				System.out.println("Continue button clicked");
				
				
				try{
					String status = getDriver().findElement(By.xpath("//div[strong[contains(text(),"
							+ "'Status')]]/following-sibling::div/span")).getText();
					System.out.println("Status-->"+status);
					do{
						if(cLib.WaitForPresenceOfElement("//div[@id='deployment-actions']/a[contains(text(),"
								+ "'Working')]", getDriver(),10000).isDisplayed()){
							cLib.createDialogbox("Health Check", "Health Check for OK : Report in deployment channel or developer"
									+ " for health check failure");
							
							String deploymentURL = getDriver().getCurrentUrl();
							System.out.println("Dep Url --> "+deploymentURL);
							
							try{
								/*Open a new window and open Account Lookup*/
								cLib.openNewTabJSExecuter(getDriver());
								cLib.switchToNewTabByAryLst(getDriver());
								
								/*Runtime.getRuntime().exec("C:\\AutoIT\\AutoItScript\\Test.exe");
								 Thread.sleep(1000);*/
								System.out.println("Opening Acc Lookup to log into application");
								/*getDriver().navigate().to("http://satyaprakash.pani:Kila@888!@intranet/"
										+ "AccountLookUp/AccountLookUp.aspx");*/
								cLib.openURL(getDriver(), "http://intranet/AccountLookUp/AccountLookUp.aspx");
								
								
								/*Search with ha.cms in Customer's User name field and click on Control Centre 	*/	
								getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
								getDriver().findElement(By.xpath("//input[@id='element71167']")).sendKeys("testmajorsupplier");
								getDriver().findElement(By.xpath("//span[@id='div71174']/li/span/input")).click();
								cLib.waitAndClickElement(getDriver(),getDriver().findElement(By.xpath("//a[contains"
										+ "(text(),'Control centre')]")), 10);
								
								getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
							}catch(Exception accLookUpError){
								accLookUpError.printStackTrace();
							}
							
							getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
							try{
								//Open testlink for Control Centre test link1
								System.out.println("Navigating to CC link1");
								getDriver().navigate().to( "http://controlcentre1.uk-plc.net/homepage.aspx");
								
								getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
								
								if((!getDriver().getTitle().contains("500"))){
									try{
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//button[@id='CloseMenuNotification']", 
											getDriver(), 30),	getDriver());
									cLib.WaitForPresenceOfElement("//button[@id='CloseMenuNotification']", getDriver(), 30).click();
									}catch(Exception E){
										System.out.println("No CloseMenuNotification");
										E.printStackTrace();
									}
									Thread.sleep(1000);
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='appRow2']//td[a[contains"
											+ "(text(),'Blocks')]]/following-sibling::td/a", getDriver(), 40), getDriver());
									cLib.WaitForPresenceOfElement("//div[@id='appRow2']//td[a[contains(text(),'Blocks')]]"
											+ "/following-sibling::td/a", getDriver(), 40).click();
									if(cLib.WaitForPresenceOfElement("//div[@id='appPageTitle']/h1[contains(text(),'Blocks')]",
											getDriver(), 40).isDisplayed()){
										cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='appPageTitle']/h1"
												+ "[contains(text(),'Blocks')]", getDriver(), 40), getDriver());
										cLib.highlightElement(cLib.WaitForPresenceOfElement("//select[@id='BlockType']", 
												getDriver(), 40), getDriver());
										cLib.select("//select[@id='BlockType']", "Custom", getDriver());
										cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='BlockName']", 
												getDriver(), 40), getDriver());
										cLib.WaitForPresenceOfElement("//input[@id='BlockName']", getDriver(), 40).sendKeys
										("Test");
										cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Submit']", getDriver(),
												40), getDriver());
										cLib.WaitForPresenceOfElement("//input[@id='Submit']", getDriver(), 40).click();
										if(!getDriver().getTitle().contains("500")){
											System.out.println("No 500 Error : testlink1 for CC Passed");
										}
									}else{
										cLib.createDialogbox("Element not found", "Unable to view Blocks section");
									}
								}
								
							}catch(Exception CCLink1Err){
								System.out.println("Error on CC test Link1 ");
								CCLink1Err.printStackTrace();
								cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
								getDriver().getTitle()+"page");
							}
							
							try{
								//Open testlink for Control Centre test link2
								System.out.println("Navigating to CC link2");
								cLib.openUrlInNewTab(getDriver(), "http://controlcentre1.uk-plc.net/myaccount/ManageUsers.aspx");
								
								getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
								
								if((!getDriver().getTitle().contains("500"))){
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='appPageTitle']/h1[contains"
											+ "(text(),'Manage Users')]",getDriver(), 30),	getDriver());
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='appContainer']//select[@id"
											+ "='SearchType']", getDriver(), 30), getDriver());
									
									WebElement select = cLib.WaitForPresenceOfElement("//div[@id='appContainer']//select[@id="
											+ "'SearchType']", getDriver(), 40);
									
									((JavascriptExecutor)getDriver()).executeScript("var select = arguments[0]; for(var i = 0; i"
											+ "< select.options.length;i++){ if(select.options[i].text == arguments[1])"
											+ "{ select.options[i].selected = true; } }", select, "Name");
									Thread.sleep(2000);
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='SearchString']",
											getDriver(), 40), getDriver());
									cLib.WaitForPresenceOfElement("//input[@id='SearchString']", getDriver(), 40).sendKeys
									("Test");
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Submit']", 
											getDriver(), 40), getDriver());
									cLib.WaitForPresenceOfElement("//input[@id='Submit']", getDriver(), 40).click();
									getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
									if(!getDriver().getTitle().contains("500")){
											System.out.println("No 500 Error : testlink1 for CC Passed");
									}else{
										cLib.createDialogbox("500 Error", "testlink1 for CC Failed");
									}
								}
								
							}catch(Exception CCLink2Err){
								System.out.println("Error on CC test Link ");
								CCLink2Err.printStackTrace();
								cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
								getDriver().getTitle()+"page");
							}
							
							try{
								//Open testlink for Control Centre test link3
								System.out.println("Navigating to CC link3");
								cLib.openUrlInNewTab(getDriver(), "http://controlcentre1.uk-plc.net/myaccount/"
										+ "PaymentCardDetails.aspx");
								
								getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
								
								if((!getDriver().getTitle().contains("500"))){
									
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//span[contains(text(),'Test Card-automation')]", 	getDriver(), 40), getDriver());
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//span[contains(text(),'Test Card-automation')]/ancestor::td/following-sibling::td//a[contains(text(),'Edit')]",
											getDriver(), 30),getDriver());
									
									
									cLib.WaitForPresenceOfElement("//span[contains(text(),'Test Card-automation')]/"
									+ "ancestor::td/following-sibling::td//a[contains(text(),'Edit')]",getDriver(), 30).click();
									
									if(!getDriver().getTitle().contains("500")){
										cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='appPageTitle']/h1",
												getDriver(), 40), getDriver());
										cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='strCV2ElementRow']/"
												+ "/input[@id='strCV2']", getDriver(), 40), getDriver());
										cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='savechange']",
												getDriver(), 40),getDriver());
										cLib.WaitForPresenceOfElement("//div[@id='strCV2ElementRow']//input[@id='strCV2']", 
												getDriver(), 40).sendKeys("012");
										Thread.sleep(4000);
										cLib.WaitForPresenceOfElement("//input[@id='savechange']", getDriver(), 40).click();
									}else{
									cLib.createDialogbox("500 Error", "Getting 500 error for '"+getDriver().getCurrentUrl()
											+"' page");
									}
									
									getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
									if(!getDriver().getTitle().contains("500")){
											System.out.println("No 500 Error : testlink1 for CC Passed");
									}else{
										cLib.createDialogbox("500 Error", "Getting 500 error for '"+getDriver().getCurrentUrl()
												+"' page");
									}
								}
								
							}catch(Exception CCLink3Err){
								System.out.println("Error on CC test Link ");
								CCLink3Err.printStackTrace();
								cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
								getDriver().getTitle()+"page");
							}
							
							try{
								//Open testlink for Control Centre test link4
								System.out.println("Navigating to CC link4");
								cLib.openUrlInNewTab(getDriver(), "http://controlcentre1.uk-plc.net/myaccount/previousorders.aspx");
								
								getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
								
								if((!getDriver().getTitle().contains("500"))){
									
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='startdateElementRow']//input", 
											getDriver(), 30), getDriver());
									
									cLib.WaitForPresenceOfElement("//div[@id='startdateElementRow']//input[1]",getDriver(), 30)
									.clear();
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@class='header']//span",
											getDriver(), 30), getDriver());
									cLib.WaitForPresenceOfElement("//div[@class='header']//span",getDriver(), 30).click();
									cLib.WaitForPresenceOfElement("//div[@class='header']//span",getDriver(), 30).click();
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[contains(text(),'2012')]",
											getDriver(), 30), getDriver());
									cLib.WaitForPresenceOfElement("//div[contains(text(),'2012')]",getDriver(), 30).click();
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@class='months']/div[contains"
											+ "(text(),'Feb')]",getDriver(), 30), getDriver());
									cLib.WaitForPresenceOfElement("//div[@class='months']/div[contains(text(),'Feb')]",
											getDriver(), 30).click();
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[contains(text(),'17')]",
											getDriver(), 30), getDriver());
									cLib.WaitForPresenceOfElement("//div[contains(text(),'17')]",getDriver(), 30).click();
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='EndDateElementRow']//"
											+ "input[1]", getDriver(), 30), getDriver());
									cLib.WaitForPresenceOfElement("//div[@id='EndDateElementRow']//input[1]",getDriver(), 30)
									.clear();
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='purchaseorderId']",
											getDriver(), 30), getDriver());
									cLib.WaitForPresenceOfElement("//input[@id='purchaseorderId']",getDriver(), 30).
									sendKeys("2339945");
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='go']",getDriver(), 30),
											getDriver());
									cLib.WaitForPresenceOfElement("//input[@id='go']",getDriver(), 30).click();
									getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
									if(!getDriver().getTitle().contains("500")){
										cLib.highlightElement(cLib.WaitForPresenceOfElement("//tbody[@id='tableBody192']"
												+ "//a[contains(text(),'View invoice')]",getDriver(), 30), getDriver());
										cLib.WaitForPresenceOfElement("//tbody[@id='tableBody192']//a[contains(text(),"
												+ "'Leave feedback')]",getDriver(), 30).click();
									}else{
									cLib.createDialogbox("500 Error", "Getting 500 error for '"+getDriver().getCurrentUrl()+
											"' page");
									}
									
									getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
									if(!getDriver().getTitle().contains("500")){
											System.out.println("No 500 Error : testlink1 for CC Passed");
									}else{
										cLib.createDialogbox("500 Error", "Getting 500 error for '"+getDriver().getCurrentUrl()
												+"' page");
									}
								}
								
							}catch(Exception CCLink4Err){
								System.out.println("Error on CC test Link ");
								CCLink4Err.printStackTrace();
								cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
								getDriver().getTitle()+"page");
							}
							
							try{
								//Open test link for Control Centre test link5
								System.out.println("Navigating to CC link5");
								cLib.openURL(getDriver(), "http://controlcentre1.uk-plc.net/Blogs/Blogs.aspx");
								
								getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
								
								if((!getDriver().getTitle().contains("500"))){
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='appPageTitle']/h1", 
											getDriver(), 30), getDriver());
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='PageItem1']//h3",
											getDriver(), 30),getDriver());
									
									
									cLib.WaitForPresenceOfElement("//tbody[@id='tableBody48']//span[text()='TestBlog']/"
											+ "../../following-sibling::td//a[contains(text(),'Edit')]",getDriver(), 30).click();
									getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
									
									int sr = new Random().nextInt(999);
									if(!getDriver().getTitle().contains("500")){
										cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='AjaxFormContent']", 
												getDriver(),40), getDriver());
										cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='UniqueName']",
												getDriver(), 40),getDriver());
										cLib.WaitForPresenceOfElement("//input[@id='UniqueName']", getDriver(), 40).clear();
										cLib.WaitForPresenceOfElement("//input[@id='UniqueName']", getDriver(), 40).
										sendKeys("AutomationTest-"+sr);
										cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Submit']", getDriver()
												, 40), getDriver());
										cLib.WaitForPresenceOfElement("//input[@id='Submit']", getDriver(), 40).click();
										
										if(!getDriver().getTitle().contains("500")){
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//tbody[@id='tableBody48']"
													+ "//span[contains(text(),"
													+ "'AutomationTest')]", getDriver(), 40), getDriver());
											
											Thread.sleep(20000);
											
											String actualURL = cLib.WaitForPresenceOfElement("//tbody[@id='tableBody48']//span"
													+ "[contains(text(),"
													+ "'AutomationTest')]", getDriver(), 40).getText();
											System.out.println(actualURL.replaceAll("[^0-9]", ""));
											if(String.valueOf(sr).equals(actualURL.replaceAll("[^0-9]", ""))){
												System.out.println("Unique Name is matched with the name provided during Edit");
												System.out.println("Testlink5 for CC Passed");
											}else{
												cLib.createDialogbox("Data Mismatch", " Saved Unique name is not matched with "
														+ "the name provided during Edit'"+getDriver().getCurrentUrl()+"' page");
											}
										}else{
											cLib.createDialogbox("500 Error", "Getting 500 error for '"+getDriver().getCurrentUrl()
													+"' page");
										}
									}else{
									cLib.createDialogbox("500 Error", "Getting 500 error for '"+getDriver().getCurrentUrl()
											+"' page");
									}
								}
							}catch(Exception CCLink5Err){
								System.out.println("Error on CC test Link ");
								CCLink5Err.printStackTrace();
								cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
								getDriver().getTitle()+"page");
							}
							
							
							try{
								//Open test link for Control Centre test link6
								System.out.println("Navigating to CC link6");
								cLib.openUrlInNewTab(getDriver(), "http://controlcentre1.uk-plc.net/Cms/Javascript.aspx");
								
								getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
								
								if((!getDriver().getTitle().contains("500"))){
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Search']", 
											getDriver(), 30), getDriver());
									String searchedFilename = "automationtest";
									cLib.WaitForPresenceOfElement("//input[@id='Search']",getDriver(), 30).sendKeys
									(searchedFilename);
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Submit']", getDriver(),
											40), getDriver());
									cLib.WaitForPresenceOfElement("//input[@id='Submit']", getDriver(), 40).click();
									getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
									if(!getDriver().getTitle().contains("500")){
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//tbody[@id='tableBody234']//"
											+ "span[contains(text(),'automationtest')]", getDriver(),40), getDriver());
									String fileName = cLib.WaitForPresenceOfElement("//tbody[@id='tableBody234']//"
											+ "span[contains(text(),'automationtest')]", getDriver(), 40).getText();
									System.out.println("File Name--> "+fileName);
									if(fileName.substring(0, fileName.indexOf('.')).equals(searchedFilename)){
										System.out.println("Searched filename present");
										System.out.println("Testlink6 for CC Passed");
									}else{
										cLib.createDialogbox(searchedFilename+" not found", " Searched filename is not found "
												+ "during Edit'"+getDriver().getCurrentUrl()+"' page");
										}
									}else{
									cLib.createDialogbox("500 Error", "Getting 500 error for '"+getDriver().getCurrentUrl()
											+"' page");
									}
								}
							}catch(Exception CCLink6Err){
								System.out.println("Error on CC test Link ");
								CCLink6Err.printStackTrace();
								cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
								getDriver().getTitle()+"page");
							}
							//Test
							try{
								//Open testlink for Control Centre test link7
								System.out.println("Navigating to CC link7");
								getDriver().navigate().to( "http://controlcentre1.uk-plc.net/Cms/JavascriptEditor.aspx"
										+ "?GuidItem=67e29976-5a0f-437c-9aea-06ee9b4798d6");
								
								getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
								
								if((!getDriver().getTitle().contains("500"))){
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//form[@id='Form350']", 
											getDriver(), 30), getDriver());
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//textarea[@id='RevisionComment']",
											getDriver(), 30),getDriver());
									cLib.WaitForPresenceOfElement("//textarea[@id='RevisionComment']",
											getDriver(), 30).sendKeys("Automation Test");
									
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Submit']", getDriver(),
											40), getDriver());
									cLib.WaitForPresenceOfElement("//input[@id='Submit']", getDriver(), 40).click();
									getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
									if(!getDriver().getTitle().contains("500")){
										Thread.sleep(2000);
										System.out.println("Pass");
									}else{
									cLib.createDialogbox("500 Error", "Getting 500 error for '"+getDriver().getCurrentUrl()
											+"' page");
									}
								}
							}catch(Exception CCLink7Err){
								System.out.println("Error on CC test Link7 ");
								CCLink7Err.printStackTrace();
								cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
								getDriver().getTitle()+"page");
							}
							
							try{
								//Open testlink for Control Centre test link8
								System.out.println("Navigating to CC link8");
								Random randomNo = new Random();
								cLib.openUrlInNewTab(getDriver(), "http://controlcentre1.uk-plc.net/SiteSettings/"
										+ "SetupMerchantAccounts.aspx");
								
								getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
								
								if((!getDriver().getTitle().contains("500"))){
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='PageItem1']", 
											getDriver(), 30), getDriver());
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//tbody[@id='tableBody213']//"
											+ "span[contains(text(),'HDFC')]/../../following-sibling::td//a[contains"
											+ "(text(),'Edit')]",getDriver(), 30),getDriver());
									cLib.WaitForPresenceOfElement("//tbody[@id='tableBody213']//span[contains(text(),'HDFC')]"
											+ "/../../following-sibling::td//a[contains(text(),'Edit')]",getDriver(), 30).click();
									
									if(!getDriver().getTitle().contains("500")){
										cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='strUserName']",
												getDriver(), 30),getDriver());
										cLib.WaitForPresenceOfElement("//input[@id='strUserName']",getDriver(), 30).clear();
										cLib.WaitForPresenceOfElement("//input[@id='strUserName']",getDriver(), 30)
										.sendKeys("AutomationTest-"+
										randomNo.nextInt(99));
										cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Submit']", getDriver(),
												40), getDriver());
										cLib.WaitForPresenceOfElement("//input[@id='Submit']", getDriver(), 40).click();
										
										if(!getDriver().getTitle().contains("500")){
											Thread.sleep(2000);
											System.out.println("No 500 Error : Hence this test link PASS");
										}else{
										cLib.createDialogbox("500 Error", "Getting 500 error for '"+getDriver().getCurrentUrl()
												+"' page");
										}
									}else{
									cLib.createDialogbox("500 Error", "Getting 500 error for '"+getDriver().getCurrentUrl()
											+"' page");
									}
								}
							}catch(Exception CCLink8Err){
								System.out.println("Error on CC test Link8 ");
								CCLink8Err.printStackTrace();
								cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
								getDriver().getTitle()+"page");
							}
							
							try{
								//Open testlink for Control Centre test link9
								System.out.println("Navigating to CC link9");
								getDriver().navigate().to( "http://controlcentre1.uk-plc.net/ServiceManagement/Actuals.aspx");
								
								getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
								
								if((!getDriver().getTitle().contains("500"))){
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='app']//li/a[contains"
											+ "(text(),'Service Bookings')]",
											getDriver(), 30), getDriver());
									cLib.WaitForPresenceOfElement("//div[@id='app']//li/a[contains(text(),'Service "
											+ "Bookings')]", getDriver(), 30).click();
									if(!getDriver().getTitle().contains("500")){
										cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='appColumnContainer']"
												+ "//a[contains(text(),'View Service Requests')]",getDriver(), 30),getDriver());
										cLib.WaitForPresenceOfElement("//div[@id='appColumnContainer']//a[contains(text(),"
												+ "'View Service Requests')]",getDriver(), 30).click();
										
										if(!getDriver().getTitle().contains("500")){
											System.out.println("No 500 Error : Hence this test link PASS");
										}else{
										cLib.createDialogbox("500 Error", "Getting 500 error for '"+getDriver().getCurrentUrl()
												+"' page");
										}
									}else{
									cLib.createDialogbox("500 Error", "Getting 500 error for '"+getDriver().getCurrentUrl()
											+"' page");
									}
								}else{
									cLib.createDialogbox("500 Error", "Getting 500 error for '"+getDriver().getCurrentUrl()
											+"' page");
									}
							}catch(Exception CCLink9Err){
								System.out.println("Error on CC test Link9 ");
								CCLink9Err.printStackTrace();
								cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
								getDriver().getTitle()+"page");
							}
							
							try{
								//Open test link for Control Centre to test login module
								System.out.println("Navigating to CC homepage to test login module");
								getDriver().navigate().to("http://controlcentre1.uk-plc.net/homepage.aspx");
								getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
								
								if((!getDriver().getTitle().contains("500"))){
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//li[@id='logoutLink']/a", getDriver(), 30), getDriver());
									cLib.WaitForPresenceOfElement("//li[@id='logoutLink']/a",getDriver(), 30).click();
									
									getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
									
									if(!getDriver().getTitle().contains("500")){
										cLib.highlightElement(cLib.WaitForPresenceOfElement("//a[contains(text(),' Forgot your password')]",getDriver(),40), getDriver());
										cLib.WaitForPresenceOfElement("//a[contains(text(),' Forgot your password')]", getDriver(), 40).click();
										
										cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='Username_Username']",getDriver(), 40),getDriver());
										cLib.WaitForPresenceOfElement("//input[@id='Username_Username']", getDriver(), 40).sendKeys("testmajorsupplier");
										
										cLib.highlightElement(cLib.WaitForPresenceOfElement("//button[contains(text(),' Send recovery e-mail')]", getDriver()
												, 40), getDriver());
										cLib.WaitForPresenceOfElement("//button[contains(text(),' Send recovery e-mail')]", getDriver(), 40).click();
										
										Thread.sleep(6000);
										if(!getDriver().getTitle().contains("500")){
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//h1[contains(text(),'Account recovery initiated')]", getDriver(), 40), getDriver());
											
											cLib.highlightElement(cLib.WaitForPresenceOfElement("//a[contains(text(),'here')]", getDriver()
													, 40), getDriver());
											cLib.WaitForPresenceOfElement("//a[contains(text(),'here')]", getDriver(), 40).click();
											if(!getDriver().getTitle().contains("500")){
												cLib.highlightElement(cLib.WaitForPresenceOfElement("//h1[contains(text(),'log in')]", getDriver(), 40), getDriver());
											}else{
												cLib.createDialogbox("500 Error", "Getting 500 error for '"+getDriver().getCurrentUrl()
														+"' page");
											}
										}else{
											cLib.createDialogbox("500 Error", "Getting 500 error for '"+getDriver().getCurrentUrl()
													+"' page");
										}
									}else{
									cLib.createDialogbox("500 Error", "Getting 500 error for '"+getDriver().getCurrentUrl()
											+"' page");
									}
								}
							}catch(Exception CCLogoutLinkErr){
								System.out.println("Error on CC test Link ");
								CCLogoutLinkErr.printStackTrace();
								cLib.createDialogbox("Link Test Error", "Getting Error while testing "+ getDriver().getTitle()+"page");
							}
							
							/*try{
								//Open testlink for Control Centre test link10
								System.out.println("Navigating to CC link10");
								cLib.openUrlInNewTab(getDriver(), "http://controlcentre1.uk-plc.net/statistics/graph.aspx");
								
								getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
								
								if((!getDriver().getTitle().contains("500"))){
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//select[@id='dropDownSelect']",
											getDriver(), 30), getDriver());
									cLib.select("//select[@id='dropDownSelect']", 3, getDriver());
									cLib.highlightElement(cLib.WaitForPresenceOfElement("//input[@id='go']",getDriver(),
											30), getDriver());
									cLib.WaitForPresenceOfElement("//input[@id='go']", getDriver(), 30).click();
								
									if(!getDriver().getTitle().contains("500")){
										Thread.sleep(2000);
										List<WebElement> asd= getDriver().findElements(By.xpath("//div[@id='appColumnContainer']"
												+ "//a/span/../../.."));
										cLib.highlightElements(asd, getDriver());
										if(!getDriver().getTitle().contains("500")){
											System.out.println("No 500 Error : Hence this test link PASS");
										}else{
										cLib.createDialogbox("500 Error", "Getting 500 error for '"+getDriver().getCurrentUrl()
												+"' page");
										}
									}else{
									cLib.createDialogbox("500 Error", "Getting 500 error for '"+getDriver().getCurrentUrl()
											+"' page");
									}
								}else{
									cLib.createDialogbox("500 Error", "Getting 500 error for '"+getDriver().getCurrentUrl()
											+"' page");
									}
							}catch(Exception CCLink10Err){
								System.out.println("Error on CC test Link10 ");
								CCLink10Err.printStackTrace();
								cLib.createDialogbox("Link Test Error", "Getting Error while testing "+
								getDriver().getTitle()+"page");
							}*/
							
							/*Navigate to deployment application window*/
							cLib.openNewTabJSExecuter(getDriver());
							cLib.switchToNewTabByAryLst(getDriver());
							cLib.openURL(getDriver(), deploymentURL);
							cLib.createDialogbox("Deployment Confirmation: ", "All test links got tested and "
									+ "working as per expected \n Please complete ticket related testing if any"
									+ " and click on 'OK' 'Working' button");
							
							cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='deployment-actions']"
									+ "/a[contains(text(),'Working')]", getDriver(), 40), getDriver());
							cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//div[@id='page']"
									+ "//div[@id='deployment-actions']/a[contains(text(),'Working')]")), 40);
							
							if(cLib.WaitForPresenceOfElement("//div[@id='page']//div[@class='alert alert-success']"
									+ "//strong",getDriver(), 3000).isDisplayed()){
								cLib.createDialogbox("Success Message","Control Centre Deployed on Cressex environment "
										+ "successfully with successful message : "+getDriver().findElement(By.
											xpath("//div[@id='page']//div[@class='alert alert-success']//strong")).
										getText());
							}else{
								cLib.createDialogbox("Failure Message", "Control Centre is unable to Deploy on Cressex "
										+ "environment");
							}
							
						}else{				//Else for 'Working' button availability 
							System.out.println("Working button is not available");
							cLib.createDialogbox("Working button Error", "Working button is not available, kindly check the "
									+ "deployment app for more info...");
						}
							
							
							
						}while(status.contains("Deploying to first server"));
				}catch(Exception e){
					e.printStackTrace();
					if(getDriver().findElement(By.xpath("//h1[contains(text(),'502 Bad Gateway')]")).isDisplayed()){
						cLib.createDialogbox("Bad Gateway Error", "502 Bad Gateway : Report to Infra or Dev team");
					}
				}
		}else{
			cLib.createDialogbox("Navigation Error", "Unable to navigate Control Centre page ");
		}
		
		
	}catch(Exception controlCentreErr){
		controlCentreErr.printStackTrace();
		if(getDriver().getTitle().equals("Server Error")){
			cLib.createDialogbox("Deployment Error : ","Unable to access deployment App" 
			+"due to Server Error");
			System.out.println("Error");
			getDriver().get("https://deployment.ukplc.corp");
			}
		}
	}
	
	@AfterClass
	public void configAfterClassMtd(){
		try {
			getDriver().close();
			getDriver().quit();
			vcLib.stopRecording();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}