package com.cloudbuy.deploymentApp;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class EPDQOnCressex extends DriverSetUpCressx {

	CommonLib cLib =new CommonLib();
	CaptureVideo vcLib=new CaptureVideo();
	/*This will open browser and deployment application  */
	@BeforeClass
	public void configBeforeClass() {
		//Start video recording
		try {
			vcLib.startRecording();
		} catch (Exception videoException) {
			videoException.printStackTrace();
			System.out.println("Problem in video recording");
		}
		try{
			setDriver("https://deployment2.ukplc.corp");
			System.out.println("Inside beforeClass--> "+getDriver().getTitle());
			cLib.WaitForPresenceOfElement("//input[@id='login']", getDriver(), 30);
			System.out.println("Login screen appears");
			}catch(Exception e){
				System.out.println("---------------------");
				e.printStackTrace();
				if(getDriver().getTitle().equals("Server Error")){
					
					getDriver().navigate().refresh();
				}else{
					cLib.createDialogbox("Deployment Error : ","Unable to access deployment App "
							+"due to deployment app Error");
				}
					
			}
		}
	
	/*Websites to deployment application with valid credential */
	@BeforeMethod
	public void configBeforeMethod(){
		System.out.println("Inside before method");
		try{
			cLib.createDialogbox("Login Screen ","Please enter your credential and click on 'Submit'"
							+ " button before clicking on OK");
			//cLib.WebsitesToDepllomentApp(getDriver(), "satyaprakash.pani", "Kila@999!");
			/*if(getDriver().findElement(By.xpath("//a[contains(text(),'Applications')]")).getText().
					equals("")){
				System.out.println("Logged in to tha app");
			}*/
		}catch(Exception e){
				if(getDriver().getTitle().equals("Server Error")){
					cLib.createDialogbox("Login Error","Unable to Login");
					getDriver().close();
				}
		}
	}
	
	@Test
	public void deployEPDQServiceOnCressexTest(){
		System.out.println("Inside deployWebsitesOnCressexTest()");
		try{
			cLib.highlightElement(getDriver().findElement(By.xpath("//div[@id='page']")), getDriver());
			//cLib.WaitForPresenceOfElement("//div[@id='page']", getDriver(), 40);
			cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//a[contains"
					+ "(text(),'Applications')]")), 40);
			Thread.sleep(2000);
			cLib.highlightElement(getDriver().findElement(By.xpath("//a[contains(text(),"
					+ "'Applications')]")), getDriver());
			
			/*Click on Websites if Websites link is enabled*/
			WebElement epdq = getDriver().findElement(By.xpath("//div[@id='page']//div[@class='list"
					+ "-group-item']//a[text()='EpdqService']"));
			if(epdq.isEnabled()){
				System.out.println("EPDQ Link is enabled");
				Thread.sleep(5000);
				cLib.highlightElement(epdq, getDriver());
				System.out.println("EPDQ loc: "+epdq.getLocation());
				JavascriptExecutor executor = (JavascriptExecutor)getDriver();
				executor.executeScript("arguments[0].click()", epdq);
				System.out.println("EPDQService Clicked");
			}
			
			if(cLib.WaitForPresenceOfElement("//div[@id='page']//h1", getDriver(), 30).isDisplayed()){
				cLib.highlightElement(getDriver().findElement(By.xpath("//div[@id='page']//h1")),
						getDriver());
				String oldBNo = getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/"
						+ "following-sibling::td[@class='text-right']")).getText();
				System.out.println("Old Build No : "+oldBNo);
				/*String data=getDriver().findElement(By.xpath("//tr[td[a[text()='Cressex']]]/td[contains"
						+ "(text(),'Basket-Build')]")).getText();*/
				/*System.out.println("Data-->"+data);
				System.out.println(data.split("-")[data.split("-").length-1]);*/
				
				/*Highlight and Click on build number drop-down*/
				cLib.highlightElement(getDriver().findElement(By.xpath("//td[a[contains(text(),"
						+ "'Cressex')]]/following-sibling::td//button[@class='btn dropdown-toggle "
						+ "btn-default']")), getDriver());
				getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/following-sibling"
						+ "::td//button[@class='btn dropdown-toggle btn-default']")).click();
				
				cLib.createDialogbox("Build number selection", "Please select appropriate build number");
				/*if(cLib.checkForOldBuild("//td[a[contains(text(),'Cressex')]]/following-sibling::td//"
						+ "span[@class='text']", getDriver(),Integer.valueOf(oldBNo))){
					System.out.println("Build number present");
					
					try{
						cLib.createDialogbox("Build Not Found", "Dropdown is not enable to click");
						cLib.clickOnOldBuild(oldBNo, getDriver());
					}catch(Exception selectBtn){
						cLib.createDialogbox("Build Not Found", "Dropdown is not enable to click");
						cLib.select("//tr[td[a[text()='Cressex']]]/td/form/select[@name='build']", 
								data.split("-")[data.split("-").length-1], getDriver());
					}
						}else{
							cLib.createDialogbox("Build Not Found", "Please change it manually");
							cLib.clickOnOldBuild(oldBNo, getDriver());
						}*/
				
				//Click on Deploy button
				try{
					cLib.highlightElement(getDriver().findElement(By.xpath("//td[a[contains(text(),"
							+ "'Cressex')]]/following-sibling::td//button[contains(text(),'Deploy')]"
							)),getDriver());
					System.out.println("Highlighted");
					
					/*Actions deploy = new Actions(getDriver());
					deploy.click(getDriver().findElement(By.xpath("//tr[td[a[text()='Cressex']]]/td/form"
							+ "/button[text()='Deploy' and @class='btn']"))).perform();*/
					getDriver().findElement(By.xpath("//td[a[contains(text(),'Cressex')]]/following-"
							+ "sibling::td//button[contains(text(),'Deploy')]")).click();
					System.out.println("Cliclked on 'Deploy'");
					
				}catch(Exception deploymentButton){
					cLib.createDialogbox("DeployButton", "Deploy Button is not Clickable");
					deploymentButton.printStackTrace();
				}
				
				/*Confirm deployment application, environment and build*/
				try{
					if(cLib.WaitForPresenceOfElement("//h2[text()='Confirm Deployment']", getDriver(),
							40).isDisplayed()){
						cLib.highlightElement(getDriver().findElement(By.xpath("//h2[text()='Confirm "
								+ "Deployment']")), getDriver());
						
						
						cLib.createDialogbox("Confirm deployment ", "If Application, Environment and Build "
								+ "No. are correct then click OK in dialog box, \nElse click 'Cancel' on "
								+ "deployment App then click on 'Ok' in dialoge ");
						
					}
				}catch(Exception e){
					e.printStackTrace();
					cLib.createDialogbox("Error :","Error in : "+getDriver().getCurrentUrl());
				}
				
				
				//Click on Continue button to deploy Websites on First server
				cLib.waitAndClickElement(getDriver(),getDriver().findElement(By.xpath("//button[text()="
					+ "'Continue']")),40);
				
				System.out.println("Continue button clicked");
				
				
				try{
					String status = getDriver().findElement(By.xpath("//div[strong[contains(text(),"
							+ "'Status')]]/following-sibling::div/span")).getText();
					System.out.println("Status-->"+status);
					do{
						if(cLib.WaitForPresenceOfElement("//div[@id='deployment-actions']/a[contains(text(),"
								+ "'Working')]", getDriver(),5400).isDisplayed()){
							cLib.createDialogbox("Health Check", "Health Check for OK : Report in deployment channel or developer"
									+ " for health check failure");
							
							
							cLib.createDialogbox("Deployment Confirmation: ", "All test links got tested and "
									+ "working as per expected \n Please complete ticket related testing if any"
									+ " and click on 'OK' 'Working' button");
							
							cLib.highlightElement(cLib.WaitForPresenceOfElement("//div[@id='deployment-actions']"
									+ "/a[contains(text(),'Working')]", getDriver(), 40), getDriver());
				/*			cLib.waitAndClickElement(getDriver(), getDriver().findElement(By.xpath("//div[@id='page']"
									+ "//div[@id='deployment-actions']/a[contains(text(),'Working')]")), 40);*/
							
							cLib.clickElemntByMouseMovement(getDriver(), cLib.WaitForPresenceOfElement("//div[@id='page']"
									+ "//div[@id='deployment-actions']/a[contains(text(),'Working')]", getDriver(), 40));
							
							if(cLib.WaitForPresenceOfElement("//div[@id='page']//div[@class='alert alert-success']"
									+ "//strong",getDriver(), 1800).isDisplayed()){
								cLib.createDialogbox("Success Message","Websites Deployed on Cressex environment "
										+ "successfully with successful message : "+getDriver().findElement(By.
											xpath("//div[@id='page']//div[@class='alert alert-success']//strong")).
										getText());
							}else{
								cLib.createDialogbox("Failure Message", "Websites is unable to Deploy on Cressex "
										+ "environment");
							}
							
										}else{				//Else for 'Working' button availability 
											System.out.println("Working button is not available");
											cLib.createDialogbox("Working button Error", "Working button is not available, kindly check the "
													+ "deployment app for more info...");
										}
						//Test
										}while(status.contains("Deploying to first server"));
									
									}catch(Exception e){
										e.printStackTrace();
										if(getDriver().findElement(By.xpath("//h1[contains(text(),'502 Bad Gateway')]")).isDisplayed()){
											cLib.createDialogbox("Bad Gateway Error", "502 Bad Gateway : Report to Infra or Dev team");
										}	
									}
			}else{
				cLib.createDialogbox("Navigation Error", "Unable to navigate Basket page ");
			}
		}catch(Exception epdqErr){
			epdqErr.printStackTrace();
			if(getDriver().getTitle().equals("Server Error")){
				cLib.createDialogbox("Deployment Error : ","Unable to access deployment App" 
				+"due to Server Error");
				System.out.println("Error");
				getDriver().get("https://deployment2.ukplc.corp");
				}
		}
	}
	
	@AfterClass
	public void configAfterClassMtd(){
		try {
			getDriver().close();
			getDriver().quit();
			vcLib.stopRecording();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
}
