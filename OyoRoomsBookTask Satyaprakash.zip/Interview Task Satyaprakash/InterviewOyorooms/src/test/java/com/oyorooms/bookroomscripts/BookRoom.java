package com.oyorooms.bookroomscripts;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.oyorooms.businessLib.GuestDetails;
import com.oyorooms.businessLib.Homepage;
import com.oyorooms.businessLib.SearchResult;
import com.oyorooms.genericLib.DriverSetup;
import com.oyorooms.genericLib.ExcelLib;
import com.oyorooms.genericLib.WebdriverCommonLib;
import com.oyorooms.genericLib.configFileSetup;

public class BookRoom extends DriverSetup {
	
	String filePath = System.getProperty("user.dir")+"\\TestData\\TestDataSheet.xlsx";
	String sheetName ="TestData";
	String colName = "actualText";
	int rowNum = 1;
	Homepage homepage = new Homepage();
	SearchResult searchPage = new SearchResult();
	GuestDetails guestDtls = new GuestDetails();
	configFileSetup conFile = new configFileSetup();
	WebdriverCommonLib wLib = new WebdriverCommonLib();
	ExcelLib  td = new ExcelLib();
	

	@BeforeMethod
	public void configBeforeMethod() throws IOException {
		setDriver(conFile.getValue("url"), "chrome");
		getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Test
	public void bookRoomTest() throws InterruptedException, IOException {
		System.out.println("Inside Test");
		String actualText = td.getCellData(filePath, sheetName, "actualText", 2);
		System.out.println(actualText);
		homepage.searchCity(getDriver(), conFile.getValue("city"));
		homepage.dateSelection(getDriver());
		homepage.guestSelection(getDriver());
		homepage.clickSerchBtn(getDriver());
		getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		searchPage.clickBookNow(getDriver());
		
		wLib.switchToNextWindow(getDriver());
		
		getDriver().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		
		guestDtls.enterGuestDetsils(getDriver());
		guestDtls.clickPayAtHotelBtn(getDriver());
		
		Thread.sleep(5000);
		
		String expectedText = guestDtls.getPayAtHotelTextFromConfirmationWindow(getDriver());
		 
		Assert.assertEquals(actualText, expectedText,"Expected text does not match with actual text");
		
		 
	}

	@AfterMethod
	public void afterMethodConfig() {
		getDriver().close();
		getDriver().quit();
	}

}
