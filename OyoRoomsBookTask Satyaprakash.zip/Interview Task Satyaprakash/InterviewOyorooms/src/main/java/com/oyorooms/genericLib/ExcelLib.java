package com.oyorooms.genericLib;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class ExcelLib {
	public String getCellData(String filePath,String sheetName, String colName, int rowNum) throws IOException
    {
	  File file = new File(filePath);
      FileInputStream fis = new FileInputStream(file); 
      XSSFWorkbook workbook = new XSSFWorkbook(fis);

      try
      {
             int col_Num = -1;
             Sheet   sheet = workbook.getSheet(sheetName);
             Row  row = sheet.getRow(0);
             for(int i = 0; i < row.getLastCellNum(); i++)
             {
                   if(row.getCell(i).getStringCellValue().trim().equals(colName.trim()))
                          col_Num = i;
             }

             row = sheet.getRow(rowNum - 1);
             Cell  cell = row.getCell(col_Num);

             if(cell.getCellTypeEnum() == CellType.STRING)
                   return cell.getStringCellValue();
             
             else if(cell.getCellTypeEnum() == CellType.NUMERIC || cell.getCellTypeEnum() == CellType.FORMULA)
             {
                   String cellValue = String.valueOf(cell.getNumericCellValue());
                   
                   if(HSSFDateUtil.isCellDateFormatted(cell))
                   {
                          DateFormat df = new SimpleDateFormat("dd/MM/yy");
                          Date date = cell.getDateCellValue();
                          cellValue = df.format(date);
                   }
                   return cellValue;
             }
             
             
             else if(cell.getCellTypeEnum() == CellType.BLANK)
                   return "";
             
             else
                   return String.valueOf(cell.getBooleanCellValue());
      }
      catch(Exception e)
      {
             e.printStackTrace();
             return "row "+rowNum+" or column "+colName +" does not exist  in Excel";
      }
}
}
