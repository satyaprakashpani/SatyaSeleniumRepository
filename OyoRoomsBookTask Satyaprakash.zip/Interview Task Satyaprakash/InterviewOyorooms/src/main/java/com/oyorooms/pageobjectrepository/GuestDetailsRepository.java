package com.oyorooms.pageobjectrepository;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class GuestDetailsRepository {
	@FindBy(id="js-user-name")
	WebElement userName;

	public WebElement getUserName() {
		return userName;
	}
	
	@FindBy(id="js-user-phone")
	WebElement phoneNo;

	public WebElement getPhoneNo() {
		return phoneNo;
	}
	
	@FindBy(id="js-user-email")
	WebElement userEmailId;

	public WebElement getuserEmailId() {
		return userEmailId;
	}

	@FindBy(id="js-pay-hotel")
	WebElement payAtHotelBtn;

	public WebElement getpayAtHotelBtn() {
		return payAtHotelBtn;
	}
	@FindBy(xpath="//*[@id=\'js-otpBox\']/div/div/div[2]/div/div")
	WebElement payAtHotelText;

	public WebElement getpayAtHotelTextfromConfirmationWindow() {
		return payAtHotelText;
	}
	
}
