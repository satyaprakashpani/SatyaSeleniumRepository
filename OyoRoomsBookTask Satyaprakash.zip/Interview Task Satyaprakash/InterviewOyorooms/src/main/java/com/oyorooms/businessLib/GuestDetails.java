package com.oyorooms.businessLib;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.oyorooms.genericLib.configFileSetup;
import com.oyorooms.pageobjectrepository.GuestDetailsRepository;

public class GuestDetails {
	configFileSetup conFile = new configFileSetup();

	public void enterGuestDetsils(WebDriver driver) throws IOException {
		GuestDetailsRepository guest =PageFactory.initElements(driver, GuestDetailsRepository.class);
		guest.getUserName().sendKeys(conFile.getValue("UserName"));
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		guest.getPhoneNo().sendKeys(conFile.getValue("phone"));
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		guest.getuserEmailId().sendKeys(conFile.getValue("mailId"));
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	
	public void clickPayAtHotelBtn(WebDriver driver) {
		GuestDetailsRepository guest =PageFactory.initElements(driver, GuestDetailsRepository.class);
		guest.getpayAtHotelBtn().click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	
	public String getPayAtHotelTextFromConfirmationWindow(WebDriver driver) {
		GuestDetailsRepository guest =PageFactory.initElements(driver, GuestDetailsRepository.class);
		return guest.getpayAtHotelTextfromConfirmationWindow().getText();
	}
}
