package com.oyorooms.genericLib;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DriverSetup {
	private WebDriver driver;
	
	public void setDriver(String URL, String browserType) {
		if(driver!=null) {
			System.out.println("Driver instance is running");
		}else if(browserType.equalsIgnoreCase("chrome")) {
			driver = initChromeDriver(URL) ;
		}else if (browserType.equalsIgnoreCase("firefox")) {
			driver = initFirefoxDriver(URL);
		}
	}
	
	public WebDriver getDriver() {
		return driver;
	}
	public WebDriver initChromeDriver(String appURL) {
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\Reference\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get(appURL);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		return driver;
		
	}
	public WebDriver initFirefoxDriver(String appURL) {
		//Code to initiate Firefox browser
		return driver;
	}
	

}
