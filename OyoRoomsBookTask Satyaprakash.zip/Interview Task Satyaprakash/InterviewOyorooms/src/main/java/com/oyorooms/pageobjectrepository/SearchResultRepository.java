package com.oyorooms.pageobjectrepository;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SearchResultRepository {
	@FindBy(xpath="//span[contains(text(),'Book Now')]")
	WebElement bookNowBtn;

	public WebElement getBookNowBtn() {
		return bookNowBtn;
	}

}
