package com.cloudbuy.cbmarketplace.genericlib;

import java.io.File;
import java.io.FileFilter;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebdriverCommonLib {

	public void WaitForPageToLoad(WebDriver driver){
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);	
	}
	
	public void WaitForPresenceOfElement(String xPath,WebDriver driver){
		WebDriverWait wait = new WebDriverWait( driver, 40);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xPath)));
		System.out.println("WaitForPresenceOfElement executed");
	}
	
	
		
	public void waitAndClickElement(WebDriver driver,WebElement element) {
		WebDriverWait wait = new WebDriverWait( driver, 60);
	    wait.until(ExpectedConditions.elementToBeClickable(element)).click();
	}
	
	public void WaitForWbLinkTextPresent(String linkName,WebDriver driver){
		WebDriverWait wait = new WebDriverWait( driver, 40);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(linkName)));
	}
	
	public void normalWait(long durationinmillisec) throws InterruptedException{
		Thread.sleep(durationinmillisec);
	}
	
	public void select(String wbXpath,String value, WebDriver driver){
		Select selWb = new Select(driver.findElement(By.xpath(wbXpath)));	
		selWb.selectByValue(value);
	}
	
	public void select(String wbXpath, int index, WebDriver driver){
		Select selWb = new Select(driver.findElement(By.xpath(wbXpath)));
		selWb.selectByIndex(index);	
	}
	
	public void select(WebElement selWbEle, String visibleText){
		Select selWb = new Select(selWbEle);  
		selWb.selectByVisibleText(visibleText);
	}
	
	public FirefoxBinary setBinaryPath(String path){
		File pathToBinary = new File(path);
		FirefoxBinary setBinary = new FirefoxBinary(pathToBinary);
		return setBinary;
	}
	public  FirefoxProfile setProfile(){
	FirefoxProfile profile = new FirefoxProfile();
	profile.setPreference("browser.download.folderList",2);
	profile.setPreference("browser.helperApps.neverAsk.saveToDisk","application/csv");
	return profile;
	}
	
	/*Script to highlight an element */
	public void highlightElement(WebElement element, WebDriver driver) throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
	    String OriginalStyle   = element.getAttribute("style");
	    //String HighlightedStyle = OriginalStyle + "border: 7px solid red;";	 
	    String HighlightedStyle = OriginalStyle + "background: #D88F4E;";
	    js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, HighlightedStyle); 
		js.executeScript("arguments[0].setAttribute('style','border: solid 4px #ff00ff')", element); 
	}
	
	/*This method is designed to highlight group of elements */
	public void highlightElements(List<WebElement> elements, WebDriver driver) throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		for(WebElement element:elements){
			 String OriginalStyle   = element.getAttribute("style");
			    String HighlightedStyle = OriginalStyle + "background: #D88F4E;";	   
			    js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, HighlightedStyle); 
		}
	}
	
	/*This method is designed to get last modified file name of a folder by providing folder path and extension*/
	public File getLastModifiedFileName(File dir, String extension) {
        File filename = null;
        String lattestModifiedFile="";
        FileFilter fileFilter = new WildcardFileFilter("*." + extension);
        File[] filess = dir.listFiles(fileFilter);

        if (filess.length > 0) {
            /** The newest file comes first **/
            Arrays.sort(filess, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
            filename = filess[0];
            System.out.println(filename);
            lattestModifiedFile = filename.getName();
            System.out.println(lattestModifiedFile);
        }
        return filename;
    }
	
	public String getSuccessPercentage(int pass, int fail){
		double totalRun = pass+fail;
		double succPercent = ((totalRun-fail)/totalRun)*100;
		System.out.println("success-->"+succPercent);
		DecimalFormat f = new DecimalFormat("##.00");
		if(pass==0)
			return Integer.toString(pass);
		else
			return   f.format(succPercent);
	}
	
	/*This method is designed to mousehover on a given element*/
	public void mousehoverToElement(WebDriver driver,WebElement element){
		Actions act = new Actions(driver);
		act.moveToElement(element).build().perform();
	}
}
