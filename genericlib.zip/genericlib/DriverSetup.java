package com.cloudbuy.cbmarketplace.genericlib;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

public class DriverSetup extends WebdriverCommonLib {
	WebdriverCommonLib wclib = new WebdriverCommonLib();
	private WebDriver driver;

	
	public WebDriver getDriver() { 		
    return driver; 
	}
	
	
	
	
	
	protected void openBrowserWithURL(String browserType, String appURL) {
		if(driver != null)
			System.out.println("Already driver instance initialized");
		else{
				String browserTypeLowerCase = browserType.toLowerCase();
				switch (browserTypeLowerCase) {
			case "chrome":
					driver = initChromeDriver(appURL);
				break;
				case "firefox":
					driver = initFirefoxDriver(appURL);
					break;
				default: 
					System.out.println("browser : " + browserType
							+ " is invalid, Launching Firefox as browser of choice..");
					driver = initFirefoxDriver(appURL);
			}
		}  
	   		
	}
	private static WebDriver initChromeDriver(String appURL) {
		System.out.println("Launching google chrome with new profile..");
		System.setProperty("webdriver.chrome.driver", "C:\\Work\\Repositories\\Main Projects\\CBMarketplace\\References\\chromedriver.exe");
		String chromProfPath = "C:\\Users\\"+System.getProperty("user.name")+"\\AppData\\Local\\Google\\Chrome\\User Data";
		ChromeOptions chromeOption = new ChromeOptions();
		chromeOption.addArguments("disable-infobars");
		chromeOption.addArguments("--no-sandbox");
		
		/*chromeOption.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		//Test
		chromeOption.setAcceptInsecureCerts(true);
		chromeOption.setUnhandledPromptBehaviour(UnexpectedAlertBehaviour.ACCEPT);*/
		chromeOption.addArguments("user-data-dir="+chromProfPath);
		
		WebDriver driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.navigate().to(appURL);
	return driver;

	}

	private  WebDriver initFirefoxDriver(String appURL) {
		System.out.println("Launching Firefox browser..");
			WebDriver driver = new FirefoxDriver(setBinaryPath("C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe"), setProfile());
			
			try{
				driver.manage().window().maximize();
				driver.manage().deleteAllCookies();
				System.out.println("Cookies deleted");
				System.out.println("URL before pass"+driver.getCurrentUrl());
				System.out.println("Driver : "+driver.toString());
				if(driver.getCurrentUrl().trim().contains("about:blank")){
					System.out.println("URL to pass-->"+appURL);
					System.out.println("Passing URL to browser");
					driver.navigate().to(appURL);
					driver.get(appURL);
				}
				else{
					System.out.println("Unable to pass URL");
					driver.quit();
				}
				
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("Error: "+e.getClass().getName());
		}
		System.out.println("Outside try block driver-->"+driver.toString());
		return driver;
		
	}
	
	/*@Parameters({ "browserType", "appURL" })
	@BeforeClass
	public void initializeTestBaseSetup(String browserType, String appURL) {
		System.out.println("BC in Driversetup");
		try {
			System.out.println("Trying to set the driver");
			setDriver(browserType, appURL);
			System.out.println("Browser :"+browserType+"URL:"+appURL);

		} catch (Exception e) {
			System.out.println("Error....." + e.getStackTrace());
		}
	}*/

}
