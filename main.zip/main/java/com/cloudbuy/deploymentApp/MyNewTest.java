package com.cloudbuy.deploymentApp;

import org.testng.annotations.Test;

public class MyNewTest {
@Test
public void myTest(){
	//Test
	
}
}
