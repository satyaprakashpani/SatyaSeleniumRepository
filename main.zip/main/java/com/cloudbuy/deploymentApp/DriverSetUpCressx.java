package com.cloudbuy.deploymentApp;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.CapabilityType;

public class DriverSetUpCressx {
	
		private WebDriver driver;

			
			public WebDriver getDriver() { 		
		    return driver; 
			}

			public FirefoxProfile setFirefoxProfice(){
				FirefoxProfile firefoxProfile = new FirefoxProfile(); 
				firefoxProfile.setPreference("browser.private.browsing.autostart",true);
				firefoxProfile.setPreference("network.proxy.type", 1);
				firefoxProfile.setPreference("network.proxy.http", "192.168.5.18");
				firefoxProfile.setPreference("network.proxy.http_port", 3128);
				firefoxProfile.setPreference("signon.autologin.proxy", true);
				
				File modifyHder = new File("C:\\Users\\satyaprakash.pani\\Desktop\\"
						+ "modify_headers-0.7.1.1-fx.xpi");
				firefoxProfile.setEnableNativeEvents(false);
				try{
					firefoxProfile.addExtension(modifyHder);
				}catch(IOException IO){
					IO.printStackTrace();
				}
				firefoxProfile.setPreference("modifyheaders.config.active", true);
				firefoxProfile.setPreference("modifyheaders.config.openNewTab", true);
				firefoxProfile.setPreference("modifyheaders.config.alwaysOn", true);
				firefoxProfile.setPreference("modifyheaders.config.start", true);
				firefoxProfile.setPreference("modifyheaders.headers.count", 1);
				firefoxProfile.setPreference("modifyheaders.headers.action1", "Modify");
				firefoxProfile.setPreference("modifyheaders.headers.name0", "X-Forwarded-Proto");
				firefoxProfile.setPreference("modifyheaders.headers.value0", "https");
				firefoxProfile.setPreference("modifyheaders.headers.enabled0", true);
				return firefoxProfile;
			}
			
			public void setDriver(String appURL) {
				if(driver != null){
					
					System.out.println("Already driver instance initialized");
					
				}
					
				else{
							//driver = initFirefoxDriver(appURL);
					driver = initChromeDriver(appURL);
					}  
			   		
			}
			
			public  WebDriver initChromeDriver(String appURL) {
				System.out.println("Launching google chrome with new profile..");
			System.setProperty("webdriver.chrome.driver", "C:\\Work\\Repositories\\Main Projects\\DeploymentApp\\Reference\\chromedriver.exe");
			String chromProfPath = "C:\\Users\\"+System.getProperty("user.name")+"\\AppData\\Local\\Google\\Chrome\\User Data";
			ChromeOptions chromeOption = new ChromeOptions();
			chromeOption.addArguments("disable-infobars");
			chromeOption.addArguments("--no-sandbox");
			
			/*chromeOption.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			//Test
			chromeOption.setAcceptInsecureCerts(true);
			chromeOption.setUnhandledPromptBehaviour(UnexpectedAlertBehaviour.ACCEPT);*/
			chromeOption.addArguments("user-data-dir="+chromProfPath);
			//chromeOption.addExtensions(new File("C:\\Users\\satyaprakash.pani\\Desktop\\Modify-Header-Value-(HTTP-Headers)_v0.1.5.crx"));
			WebDriver driver = new ChromeDriver(chromeOption);
				driver.manage().window().maximize();
				driver.manage().deleteAllCookies();
				
				driver.navigate().to(appURL);
			return driver;

			}

			public  WebDriver initFirefoxDriver(String appURL) {
				System.out.println("Launching Firefox browser..");
				
					WebDriver driver = new FirefoxDriver(setFirefoxProfice());
					
					try{
						System.out.println(driver.manage().getCookies());
						driver.manage().window().maximize();
						driver.manage().deleteAllCookies();
						System.out.println("Cookies deleted");
						System.out.println("URL before pass"+driver.getCurrentUrl());
						System.out.println("Driver : "+driver.toString());
						if(driver.getCurrentUrl().trim().contains("about:blank")){
							System.out.println("URL to pass-->"+appURL);
							driver.navigate().to(appURL);
							driver.get(appURL);
						}
						else{
							System.out.println("Unable to pass URL");
							driver.quit();
						}
						
				}catch(Exception e){
					e.printStackTrace();
					System.out.println("Error: "+e.getClass().getName());
				}
				System.out.println("Outside try block driver-->"+driver.toString());
				return driver;
				
			}
			
		

}
