package com.cloudbuy.deploymentApp;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CommonLib {
String filePath = "C:\\Users\\sandeep.behera\\Desktop\\MyExcel.xlsx";
JFrame frmOpt;
	
	public WebElement WaitForPresenceOfElement(String xPath,WebDriver driver, int timeout){
		WebDriverWait wait = new WebDriverWait( driver, timeout);
		WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xPath)));
		return element;
	}
	
	public void waitAndClickElement(WebDriver driver,WebElement element, int timeout) {
		WebDriverWait wait = new WebDriverWait( driver, timeout);
	    wait.until(ExpectedConditions.elementToBeClickable(element)).click();
	}
	
	public void highlightElement(WebElement element, WebDriver driver) throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
	    String OriginalStyle   = element.getAttribute("style");
	    //String HighlightedStyle = OriginalStyle + "border: 7px solid red;";	 
	    String HighlightedStyle = OriginalStyle + "background: #D88F4E;";
	       js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, 
	    		   HighlightedStyle); 
	       driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		js.executeScript("arguments[0].setAttribute('style','border: solid 2px #D88F4E')", element); 
	}
	
	/*This method is designed to highlight group of elements */
	public void highlightElements(List<WebElement> elements, WebDriver driver) throws 
	InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		for(WebElement element:elements){
			 String OriginalStyle   = element.getAttribute("style");
			    String HighlightedStyle = OriginalStyle + "border: solid 3px #D88F4E";	   
			    js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element,
			    		HighlightedStyle); 
		}
	}
	
	public String getExcelData(String sheetName,int rowNum,int colNum) throws InvalidFormatException, 
	IOException{
		System.out.println("Inside getExcel()");
		FileInputStream fis =new FileInputStream(filePath);
		Workbook wb = WorkbookFactory.create(fis);
		Sheet sh = wb.getSheet(sheetName);
		Row row = sh.getRow(rowNum);
		String data = row.getCell(colNum).getStringCellValue();
		System.out.println("Data-->"+data);
		return data;
	}
	public void writeDataToExcel(String sheetName,int rowNum,int colNum, String data)
			throws InvalidFormatException, IOException{
		FileInputStream fis =new FileInputStream(filePath);
        Workbook wb = WorkbookFactory.create(fis);
        System.out.println("Wb--> "+wb);
        Sheet sh = wb.getSheet(sheetName);
        System.out.println("Sheet= "+sh);
        Row row = sh.getRow(rowNum);
        System.out.println("Row= "+row);
        Cell cell =row.createCell(colNum);

		cell.setCellType(1);
		cell.setCellValue(data);
		FileOutputStream fos = new FileOutputStream(filePath);
		wb.write(fos);
	}
	public int createDialogbox(String dialogHeader ,String msg) {
		
		if (frmOpt==null){
			frmOpt=new JFrame();
		}
		frmOpt.setVisible(true);
		frmOpt.toFront();
		frmOpt.requestFocus();
		frmOpt.setLocationRelativeTo(null);
	    int opcion = JOptionPane.showConfirmDialog(frmOpt, msg, dialogHeader, JOptionPane.PLAIN_MESSAGE);
		if (opcion == 0) { //The ISSUE is here
		   System.out.println("Yes");
		   frmOpt.dispose();
		   return 0;
		} else {
		   System.out.println("no");
		   frmOpt.dispose();
		   return 0;
		}
	}
	
	public void select(String wbXpath,String value, WebDriver driver){
		Select selWb = new Select(driver.findElement(By.xpath(wbXpath)));
		List<WebElement> allOptions=selWb.getOptions();
		for(WebElement wb:allOptions){
			System.out.println(wb.getAttribute("value"));
			if(wb.getAttribute("value").contains(value)){
				selWb.selectByValue(value);
				break;
			}else{
				System.out.println("Option does not matched");
			}
		
		}
		System.out.println("Selected option : "+selWb.getFirstSelectedOption().getText());
	}
	
	
	
	public boolean checkForSelectOptionExistance(String wbXpath,String value, WebDriver driver){
		Select selWb = new Select(driver.findElement(By.xpath(wbXpath)));
		boolean status=false;
		List<WebElement> allOptions=selWb.getOptions();
		for(WebElement wb:allOptions){
			System.out.println("OPTION-->"+wb.getText());
			if(wb.getText().contains(value)){
				System.out.println("Option present");
				status=true;
				break;
			}else{
				System.out.println("Option does not matched");
				status=false;
			}
			
		}
		
		return status;
	}
	
	public void select(String wbXpath, int index, WebDriver driver){
		Select selWb = new Select(driver.findElement(By.xpath(wbXpath)));
		selWb.selectByIndex(index);	
	}
	
	@SuppressWarnings("resource")
	public void CopyAndPasteToHostFile(String source, String dest) throws Exception{
		String content = "";
		FileReader fr = new FileReader(source);
		System.out.println("Source checkout found");
		BufferedReader txtRdr = new BufferedReader(fr);
		
		File file = new File(dest);
		
		if (!file.exists()) {
			file.createNewFile();
		}
		System.out.println("dest Host file found");
		FileWriter fw = new FileWriter(file.getAbsoluteFile());
		System.out.println("fw"+fw.toString());
		BufferedWriter txtWtr = new BufferedWriter(fw);
				
		while((content=txtRdr.readLine() )!= null){
			txtWtr.write(content);
			txtWtr.newLine();
		}	
		txtWtr.flush();
	}
	public void clickElemntByMouseMovement(WebDriver driver, WebElement element){
		Actions actions = new Actions(driver);
		System.out.println(element.getLocation());
		actions.moveToElement(element).click().build().perform();
		//actions.click(element).build().perform(); test
		//Test
	}
	
	public void openURL(WebDriver driver,String url){
		driver.navigate().to(url);
	}
	public void openUrlInNewTab(WebDriver driver, String url){
		Actions action = new Actions(driver);
		action.sendKeys(Keys.chord(Keys.CONTROL,"t")).perform();
		
		driver.navigate().to(url);
	}
	
	public void mousehoverToAnElement(WebDriver driver, WebElement element){
		Actions action = new Actions(driver);
		action.moveToElement(element).perform();
	}
	public void openNewTab(WebDriver driver){
		Actions action = new Actions(driver);
		action.sendKeys(Keys.chord(Keys.CONTROL,"t")).perform();
	}
	
	public void openNewWindow(WebDriver driver){
		Actions action = new Actions(driver);
		action.sendKeys(Keys.chord(Keys.CONTROL,"n")).perform();
		System.out.println("New window opened");
	}
	public void loginToDepllomentApp(WebDriver driver, String uname, String pwd){
		driver.findElement(By.id("login")).click();
		WaitForPresenceOfElement("//input[@id='login']", driver, 20);
		driver.findElement(By.id("login")).sendKeys(uname);
		WaitForPresenceOfElement("//input[@id='passwd']", driver, 20);
		driver.findElement(By.id("passwd")).sendKeys(pwd);
		waitAndClickElement(driver, driver.findElement(By.xpath("//button[contains(text(),"
				+ "'Submit')]")), 10);
	}
	public void clickElemntwithXcoordinate(WebDriver driver, String xpath){
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement elementToClick = driver.findElement(By.xpath(xpath));
		js.executeScript("window.scrollTo(0,"+elementToClick.getLocation().x+")");
		elementToClick.click();
		
		
	}
	public void scrollForElemnt(WebElement element, WebDriver driver) throws InterruptedException{
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
		Thread.sleep(500); 

	}
	
	public void openNewTabJSExecuter(WebDriver driver){
		((JavascriptExecutor)driver).executeScript("window.open()");
	}
	
	public void switchToNewTabByAryLst(WebDriver driver){
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		System.out.println("No of window : "+tabs.size());
	    driver.switchTo().window(tabs.get(tabs.size()-1));
	}
	
	public void switchToParentTabByAryLst(WebDriver driver){
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		System.out.println("No of window : "+tabs.size());
	    driver.switchTo().window(tabs.get(0));
	}
	public void switchToNewWindow(WebDriver driver){
		String windowId = getNewWindowId(driver);
		System.out.println("Window Id to be switched to : "+windowId);
		driver.switchTo().window(windowId);
		
	}
	
	public String getNewWindowId(WebDriver driver){
		String wId="";
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		Set<String> windowIds = driver.getWindowHandles();
		for(String s : windowIds){
			System.out.println(s);
		}
		Iterator<String> itr = windowIds.iterator();
		System.out.println("No of windows: "+windowIds.size());
		System.out.println("WId-->"+itr.next());
		while(itr.hasNext()){
			 wId=itr.next();
			System.out.println("WId-->"+wId);
		}
		return wId;
	}
	
	public String navigateToParentWindow(WebDriver driver){
		Set<String> windowIds = driver.getWindowHandles();
		System.out.println("No of windows: "+windowIds.size());
		Iterator<String> itr = windowIds.iterator();
		String parentWindowId = itr.next();
		System.out.println("parentWindowId--> "+parentWindowId);
		return parentWindowId;
		
		}
	
	public  boolean checkResponseofURL(String URLName){
	    try {
	       // HttpURLConnection.setFollowRedirects(false);
	        HttpURLConnection con = (HttpURLConnection) new URL(URLName).openConnection();
	       // con.setRequestMethod("HEAD");
	        System.out.println("http response-->"+ HttpURLConnection.HTTP_OK);
	        return (con.getResponseCode() == HttpURLConnection.HTTP_OK);
	    }
	    catch (Exception e) {
	        e.printStackTrace();
	        return false;
	    }
	}
	
	/*This method gives the URL response message*/
	public String getURLResponseMsg(String url){
		 String response = "";
		HttpURLConnection http;
		try {
			System.out.println("1");
			URL tempUrl= new URL(url);
			System.out.println("2");
			http = (HttpURLConnection)tempUrl.openConnection();
			System.out.println("3");
			int statusCode = http.getResponseCode();
		    System.out.println("Status code: "+statusCode);
		    response = http.getResponseMessage();
		    System.out.println("response : "+response);
		} catch (IOException e) {
			System.out.println("in hell");
			e.printStackTrace();
		}
		System.out.println(response+"--> response");
		return response;
	    
	}
	
	public boolean checkForOldBuild(String xpath, WebDriver driver, int oldBuild) {
		List<WebElement> allBuild =driver.findElements(By.xpath(xpath)) ;
		boolean status = false;
		System.out.println("No of builds available : "+allBuild.size());
		for(WebElement ele:allBuild){
			System.out.println(ele.getText());
			if(ele.getText().matches(".*[0-9]")){
				if(oldBuild == Integer.valueOf( ele.getText().replaceAll("[^0-9]", ""))){
					System.out.println("-->"+ele.getText().replaceAll("[^0-9]", ""));
					status = true;
					break;
				}
			}
		}
		System.out.println("Status = "+status);
		return status;
		
	}
	
	public void clickOnOldBuild(String oldBuild, WebDriver driver){
		List<WebElement> allBuild = driver.findElements(By.xpath("//td[a[contains(text(),'Cressex')]]"
				+ "/following-sibling::td//span[@class='text']"));
		for(WebElement ele:allBuild){
			if(ele.getText().contains(oldBuild)){
				System.out.println("---"+ele.getText());
				ele.click();
				break;
				/*JavascriptExecutor executor = (JavascriptExecutor)driver;
				executor.executeScript("arguments[0].click()", ele);*/
			}
		}
	}
	
	
}
