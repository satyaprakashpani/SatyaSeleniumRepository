package genericLib;

import java.io.File;
import java.io.FileFilter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebDriverCommonLib {
	public void WaitForPageToLoad(WebDriver driver){
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);	
	}
	public void WaitForPresenceOfElement(String xPath,WebDriver driver){
		WebDriverWait wait = new WebDriverWait( driver, 40);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xPath)));
	}
	
	public void waitAndClickElement(WebDriver driver,WebElement element) {
		WebDriverWait wait = new WebDriverWait( driver, 40);
	    wait.until(ExpectedConditions.elementToBeClickable(element)).click();
	}
	
	public void WaitForWbLinkTextPresent(String linkName,WebDriver driver){
		WebDriverWait wait = new WebDriverWait( driver, 40);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(linkName)));
	}
	public void normalWait(long durationinmillisec) throws InterruptedException{
		Thread.sleep(durationinmillisec);
	}

	/*This method is designed to highlight the element to be operate*/
	public void highlightElement(WebElement element, WebDriver driver) throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
	    String OriginalStyle   = element.getAttribute("style");
	    //String HighlightedStyle = OriginalStyle + "border: 7px solid red;";	 
	    String HighlightedStyle = OriginalStyle + "background: #8A1DDC;";
	       js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, HighlightedStyle); 
	       try 
		{
		Thread.sleep(1000);
		}
		catch (InterruptedException e) {

		System.out.println(e.getMessage());
		}

		js.executeScript("arguments[0].setAttribute('style','border: solid 2px #D88F4E')", element); 
	}


	/*This method is designed to highlight group of elements */
	public void highlightElements(List<WebElement> elements, WebDriver driver) throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		for(WebElement element:elements){
			 String OriginalStyle   = element.getAttribute("style");
			    String HighlightedStyle = OriginalStyle + "background: #8A1DDC;";	   
			    js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, HighlightedStyle); 
		}
	}
	
	
	/*This method is designed to get last modified file name of a folder by providing folder path and extension*/
	public File getLastModifiedFileName(File dir, String extension) {
        File filename = null;
        String lattestModifiedFile="";
        FileFilter fileFilter = new WildcardFileFilter("*." + extension);
        File[] filess = dir.listFiles(fileFilter);

        if (filess.length > 0) {
            /** The newest file comes first **/
            Arrays.sort(filess, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
            filename = filess[0];
            System.out.println(filename);
            lattestModifiedFile = filename.getName();
            System.out.println(lattestModifiedFile);
        }
        return filename;

    }
	
	public List<String> getAllLinks(WebDriver driver, String tagName) {
		List<WebElement> links = driver.findElements(By.tagName(tagName));
		List<String> finalLinkList = new ArrayList<String>();
		System.out.println("No of Link -->"+links.size());
		
		for(int i =0; i<links.size();i++) {
			System.out.println("--"+links.get(i).getAttribute("href"));
			if(links.get(i).getAttribute("href")!=null){
				System.out.println("Not Null");
				finalLinkList.add(links.get(i).getAttribute("href"));
			}else
				System.out.println("null");
			//verifyLink(links.get(i).getAttribute("href"));
		}
		
		System.out.println(finalLinkList.size());
		return finalLinkList;
	}
	
	public  String verifyLink(String urlLink) {
		String status = "";
        try {
        	 
			 URL link = new URL(urlLink);
			 HttpURLConnection httpConn =(HttpURLConnection)link.openConnection();
			 httpConn.setConnectTimeout(70000);
			 httpConn.connect();
			 if(httpConn.getResponseCode()== 200) { 
				 
				 System.out.println(urlLink+" --> "+httpConn.getResponseMessage());
				 status= httpConn.getResponseMessage();
			 }
			 else if(httpConn.getResponseCode()== 404) {
				 System.out.println(urlLink+" --> "+httpConn.getResponseMessage());
				 status= httpConn.getResponseMessage();
			 }else if(httpConn.getResponseCode()== 400) {
				 System.out.println(urlLink+" --> "+httpConn.getResponseMessage());
				 status= httpConn.getResponseMessage();
			 }else if(httpConn.getResponseCode()== 500) {
				 System.out.println(urlLink+" --> "+httpConn.getResponseMessage());
				 status= httpConn.getResponseMessage();
			 }
			 else if(httpConn.getResponseCode()== 401){
				 System.out.println(urlLink+" --> "+httpConn.getResponseMessage());
				 status= httpConn.getResponseMessage();
			 }
 }
 catch (Exception e) {
 e.printStackTrace();
 }
		return status;
    } 

}
