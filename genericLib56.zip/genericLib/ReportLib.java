package genericLib;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;

import com.relevantcodes.extentreports.ExtentReports;

public class ReportLib {
ConfigFileSetUp configFile = new ConfigFileSetUp();
	
	public void getScreenshot(String fileName, WebDriver driver) throws IOException{
		EventFiringWebDriver edriver = new EventFiringWebDriver( driver);
		File srcFile = edriver.getScreenshotAs(OutputType.FILE);
		File dstnFile = new File("C:\\Automation Projects\\Report Files\\Purchasing\\Screenshots\\"+fileName +".Jpeg");
		FileUtils.copyFile(srcFile,dstnFile);
		}
	/*This method is designed to get current date in dd-mm-yyyy HH:mm:ss format*/
	public String getCurrentDateWithTimestamp(){
		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		 Date date = new Date();
		 
		 // Now format the date
		 String date1= dateFormat.format(date);
		 
		 // Print the Date
		 System.out.println(date1);
		return date1;
	}
	/*This method is designed to get current date in dd-mm-yyyy format*/
	public String getCurrentDate(){
		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy ");
		 Date date = new Date();
		 
		 // Now format the date
		 String date1= dateFormat.format(date);
		 
		 // Print the Date
		 System.out.println(date1);
		return date1;
	}
	/*This method initiates ExtentReport and configures the reprt*/
	public ExtentReports initReport(){
		String customStyle = "#topbar { background-color: #444; }" +
		        ".topbar-items-right span { color: white; }" +
		        ".menu span { color: #fff;font-weight:bold; }" +
		        ".logo {background:url(http://static.uk-plc.net/library/cloudbuy/images/site-images/cloudbuylabelblack.png)"
		        + " 0 0 no-repeat;width: 260px;height: 50px;}"	        
		        + "padding-bottom: 0px;background-position: absolute}"+
		        ".logo span {display:none!important;}"+
		        ".menu-item-selected span { border-bottom: 1px solid #0089d2; }" +
		        "#dashboard { background-color: transparent; }" +
		        ".test { border: 1px solid lightseagreen;    background: lightyellow !important; }" + 
		        ".description { background-color: transparent; border-left: 2px solid orange; padding: 2px 15px;}" + 
		        ".name { color: #54B9EF;    font-weight: 600; }" + 
		        ".extent-table { border: 1px solid #bbb; }" + 
		        ".extent-table th { background: none repeat scroll 0 0 olivedrab; color: #fff; }" + 
		        ".menu-items ul{margin-top: 0 !important;}" +
		        "#header{background:#000000;}" +
		        "#title{padding:0 0 15px !important;margin: 15px 35px;}" +
		        "#topbar{position: relative;}" +
		        ".topbar{font-size:14px!important}"+
		        ".topbar-items-right {float: right;}" +
		        ".topbar-items-right span{vertical-align:middle}"+
		        ".topbar-items-right span:first-child{vertical-align: baseline!important;}"+
		        ".topbar-items-right span:nth-child(2){  border-left: none!important; margin-left: 600px!important;}"+
		        ".topbar-items-right span.spend{ font-weight: bold; color: #54B9EF;}"+
		        "   .headline{ left: 0;top: 2px;font-family: Nunito;    font-size: 16px;    font-weight: 300;}"+
		        ".topbar-items-left{display:none!important;}" +
		        ".extent-table td { border-bottom: 1px solid #bbb; }";
			ExtentReports extent = ExtentReports.get(this.getClass());
			System.out.println(this.getClass()+ "-->get Class");
			try{
				System.out.println("Report Initialization starts...");
				extent.init(configFile.getValue("repFilePath")+"PurchasingExecutionReport "+getCurrentDate().trim()+".html", true);
				System.out.println("Report Initialized");
				extent.config().documentTitle("Purchasing Report").reportHeadline (" Automation Report:"
					+ "<span class='purch'>Purchasing</span>").reportTitle("").addCustomStyles(customStyle);
		
			 	extent.config().displayCallerClass(false);
				extent.config().useExtentFooter(false);
			}catch(Exception e){
				System.out.println(e.getStackTrace());
			}
		return extent;
	}

}
