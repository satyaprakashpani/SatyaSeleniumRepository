package genericLib;

import java.io.File;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class SendEmail {
	ReportLib rLib = new ReportLib();
	public boolean sendReportByMail(String from, String password, String to[], String subject, String body, File dir) {
        Properties props = System.getProperties();
        String host = "smtp.internal";
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.ssl.trust", host);
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.user", from);
        props.put("mail.smtp.passwordword", password);
        props.put("mail.smtp.port", "25");
        props.put("mail.smtp.auth", "true");
        
        Authenticator authenticator = new Authenticator () {
            public PasswordAuthentication getPasswordAuthentication(){
                return new PasswordAuthentication(from,password);//userid and password for "from" email address 
            }
        };
        Session session = Session.getDefaultInstance(props,authenticator);
        MimeMessage message = new MimeMessage(session);

        try {
        	//Set from address
            message.setFrom(new InternetAddress(from));
            InternetAddress[] toAddress = new InternetAddress[to.length];
            for(int i=0;i<to.length;i++){
            	toAddress[i] = new InternetAddress(to[i]);
            }
            for(int i=0;i<toAddress.length;i++){
             message.addRecipient(Message.RecipientType.TO, toAddress[i]);
            }
          // Set subject
           message.setSubject(subject);
            message.setText(body);
          
            BodyPart objMessageBodyPart = new MimeBodyPart();
            
           objMessageBodyPart.setText("Greetings,\n\nKindly find attached execution report of Purchasing executed on "
           +rLib.getCurrentDateWithTimestamp()/*+"\n \nSummary : \nWe have run Tests for SpendAnalysis  \nPassed Tests: "+pass+"\nFailed Tests: "+fail
           +"\nSuccess % : "+successRate*/+" \n\n--Test Automation Team ");

            
            Multipart multipart = new MimeMultipart();

            multipart.addBodyPart(objMessageBodyPart);

            objMessageBodyPart = new MimeBodyPart();

           // Set path to the pdf report file
           // String filename = System.getProperty("user.dir")+dir; 
            String fileName = dir.getName();
           // Create data source to attach the file in mail
            DataSource source = new FileDataSource(dir);
            
            objMessageBodyPart.setDataHandler(new DataHandler(source));
            

           objMessageBodyPart.setFileName(fileName);

            multipart.addBodyPart(objMessageBodyPart);

            message.setContent(multipart);
            Transport transport = session.getTransport("smtp");
            transport.connect(host, 25, from, password);
            transport.sendMessage(message, message.getAllRecipients());
            transport.close();
            return true;
        }
        catch (AddressException ae) {
            ae.printStackTrace();
        }
        catch (MessagingException me) {
            me.printStackTrace();
        }
        return false; 
    }

}
