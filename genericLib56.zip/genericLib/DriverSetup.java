package genericLib;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;


public class DriverSetup {
	private WebDriver driver;
	
	
	
	public void setDriver(String appURL) throws InterruptedException {
		
		if(driver != null){
			
			System.out.println("Already driver instance initialized");
			
		}
			
		else{
					//driver = initFirefoxDriver(appURL);
			driver = initChromeDriver(appURL);
			}  
	   		
	}
	
	public WebDriver getDriver() { 		
	    return driver; 
		}
	
	public  WebDriver initChromeDriver(String appURL) throws InterruptedException {
		System.out.println("Launching google chrome with new profile..");
	System.setProperty("webdriver.chrome.driver", "C:\\Work\\Repositories\\Main Projects\\DeploymentApp\\Reference\\chromedriver.exe");
	//String chromProfPath = "C:\\Users\\"+System.getProperty("user.name")+"\\AppData\\Local\\Google\\Chrome\\User Data";
	ChromeOptions chromeOption = new ChromeOptions();
	
	chromeOption.addArguments("disable-infobars");
	chromeOption.addArguments("--no-sandbox");
	chromeOption.addArguments("--disable-notifications");
	chromeOption.addArguments("auth-server-whitelist='http://cloudbuy.com'");
	/*chromeOption.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
	//Test
	chromeOption.setAcceptInsecureCerts(true);
	chromeOption.setUnhandledPromptBehaviour(UnexpectedAlertBehaviour.ACCEPT);*/
	//chromeOption.addArguments("user-data-dir="+chromProfPath);
	//chromeOption.addExtensions(new File("C:\\Users\\satyaprakash.pani\\Desktop\\Modify-Header-Value-(HTTP-Headers)_v0.1.5.crx"));
	WebDriver driver = new ChromeDriver(chromeOption);
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		Thread.sleep(2000);
		
		(new Thread(new Authentication())).start();

			Thread.sleep(2000);
		
		driver.navigate().to(appURL);
	return driver;

	}
	
}
