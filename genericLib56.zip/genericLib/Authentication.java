package genericLib;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

public class Authentication implements Runnable {

	 ConfigFileSetUp conFile = new ConfigFileSetUp();
	@Override
	public void run() {
		try {
			login();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	 public void login() throws Exception {

         //wait - increase this wait period if required
         Thread.sleep(5000);

         //create robot for keyboard operations
         Robot rb = new Robot();

         //Enter user name by ctrl-v
         StringSelection username = new StringSelection(conFile.getValue("AuthUserName"));
         Toolkit.getDefaultToolkit().getSystemClipboard().setContents(username, null);            
         rb.keyPress(KeyEvent.VK_CONTROL);
         rb.keyPress(KeyEvent.VK_V);
         rb.keyRelease(KeyEvent.VK_V);
         rb.keyRelease(KeyEvent.VK_CONTROL);

         //tab to password entry field
         rb.keyPress(KeyEvent.VK_TAB);
         rb.keyRelease(KeyEvent.VK_TAB);
         Thread.sleep(3000);

         //Enter password by ctrl-v
         StringSelection pwd = new StringSelection(conFile.getValue("AuthPassword"));
         Toolkit.getDefaultToolkit().getSystemClipboard().setContents(pwd, null);
         rb.keyPress(KeyEvent.VK_CONTROL);
         rb.keyPress(KeyEvent.VK_V);
         rb.keyRelease(KeyEvent.VK_V);
         rb.keyRelease(KeyEvent.VK_CONTROL);
         Thread.sleep(2000);
         
         //press enter
         rb.keyPress(KeyEvent.VK_ENTER);
         rb.keyRelease(KeyEvent.VK_ENTER);

         //wait
         Thread.sleep(5000);
     }                        
  
	
}
